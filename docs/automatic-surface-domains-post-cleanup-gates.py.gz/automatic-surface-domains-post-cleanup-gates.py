import json,os,subprocess,time,sys
from pathlib import Path
p='/tmp/viboceros-auto-surface-';env=dict(os.environ,CARGO_BUILD_JOBS='8',CMAKE_BUILD_PARALLEL_LEVEL='10')
commands=[('post-cleanup-portable-replay',['cargo','test','-p','viboceros-command','--test','reparameterize_faces']),('post-cleanup-native-replay',['cargo','test','-p','viboceros-command','--features','native-smlib','--test','reparameterize_faces']),('post-cleanup-portable-focused',['cargo','test','-p','viboceros-command','--lib','reparameterize']),('clippy',['cargo','clippy','--workspace','--all-targets','--all-features','--','-D','warnings']),('portable-check',['cargo','check','--workspace','--all-targets']),('fmt',['cargo','fmt','--all','--','--check']),('python',['python3','-m','unittest','tools.rhino_oracle.test_reparameterize_face_probe','tools.rhino_oracle.test_surface_fillet_probe','tools.rhino_oracle.test_structural_sdk'])]
if len(sys.argv)>1:commands=commands[[n for n,args in commands].index(sys.argv[1]):]
for name,args in commands:
 t=time.monotonic()
 with open(p+name+'.log','w')as out:r=subprocess.run(args,env=env,stdout=out,stderr=subprocess.STDOUT)
 Path(p+name+'-runtime.json').write_text(json.dumps(dict(command=args,status=r.returncode,seconds=time.monotonic()-t))+'\n');print(name,r.returncode,flush=True)
 if r.returncode:raise SystemExit(r.returncode)
