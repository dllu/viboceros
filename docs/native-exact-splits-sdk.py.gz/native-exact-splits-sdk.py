import json,math
from pathlib import Path
from tools.rhino_oracle.client import OracleClient
prefix='/tmp/viboceros-exact-split-'
assert int(Path(prefix+'candidate.status').read_text())==0
rows=[json.loads(l)for l in Path(prefix+'candidate.jsonl').read_text().splitlines()]
rows=[r for r in rows if not r.get('invalid')and r['case']in [0,2,4,8,12,14]and r['chart']==1 and r['representation']==2 and r['gauge']==1 and r['path']==0]
assert len(rows)==18
request=dict(protocol_version=1,iterations=1,operations=[]);pairs=[]
def definition(raw,kind):
 controls=[dict(point=[v/h[3]for v in h[:3]],weight=h[3])for h in raw['controls']]
 if not kind:return dict(degree=raw['degree'][0],knots=raw['knots'][0],control_points=controls)
 return dict(degree_u=raw['degree'][0],degree_v=raw['degree'][1],knots_u=raw['knots'][0],knots_v=raw['knots'][1],control_point_count_u=raw['count'][0],control_point_count_v=raw['count'][1],control_points=controls)
for r in rows:
 kind=r['kind'];axis=kind-1 if kind else 0
 for side,out in enumerate(r['actual']):
  p,n=out['degree'][axis],out['count'][axis]
  if n<=p:continue
  low,high=out['knots'][axis][p],out['knots'][axis][n]
  if not high>low:continue
  for station in range(3):
   parameter=low+(high-low)*station/2
   identifier=str(r['case'])+'-'+str(kind)+'-'+str(side)+'-'+str(station);pairs.append((identifier,kind))
   for label,raw in [('source',r['source']),('native',out)]:
    op=dict(op='nurbs_surface_evaluate'if kind else'nurbs_curve_evaluate',id=identifier+'-'+label,**definition(raw,kind))
    if kind:op.update(u=parameter if axis==0 else .75,v=parameter if axis==1 else .75)
    else:op['parameter']=parameter
    request['operations'].append(op)
assert len(pairs)==99 and len(request['operations'])==198
Path(prefix+'sdk-request.json').write_text(json.dumps(request,indent=2)+'\n')
response=OracleClient(settings_scheme='VibocerosOracleExactSplit20261018').run_rhino(request,timeout=180.)
Path(prefix+'sdk-rhino.json').write_text(json.dumps(response,indent=2)+'\n')
assert len(response['results'])==198
values={r['id']:r['value']for r in response['results']};errors={};comparisons=[]
for identifier,kind in pairs:
 a,b=values[identifier+'-source'],values[identifier+'-native'];result=dict(id=identifier,errors={})
 for key in ['point','derivative']if not kind else['point','derivative_u','derivative_v','normal']:
  assert len(a[key])==len(b[key])==3 and all(math.isfinite(x)for x in a[key]+b[key])
  error=max(abs(x-y)for x,y in zip(a[key],b[key]));label=('surface_'if kind else'curve_')+key
  errors[label]=max(errors.get(label,0),error);result['errors'][key]=error
 comparisons.append(result)
report=dict(sdk_evaluations=198,paired_stations=99,curve_stations=33,surface_stations=66,absolute_point_epsilon=1e-10,max_absolute_differences=errors,passed=max(errors['curve_point'],errors['surface_point'])<=1e-10,comparisons=comparisons,
 scope='Public Rhino SDK evaluates complete retained source and native split definitions at identical parameters. Six unit-chart continuous positive-weight families include degree 17, unclamped bases and an active-end clamp. Curve points and surface points determine pass/fail; derivatives and normals remain diagnostics. Empty native outer pieces are excluded from SDK construction. Independent controls separately qualify full-order breaks, inactive padding, extreme charts, all gauges and preallocated buffers. This is sampled locus agreement, not direct Rhino Split definition parity or a continuous bound.')
Path(prefix+'sdk-report.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({k:v for k,v in report.items()if k!='comparisons'}),flush=True);assert report['passed']
