import subprocess
from pathlib import Path
root=Path.cwd();flags=['rustc','--edition=2024','-O','-C','lto=thin','-C','codegen-units=1','/tmp/viboceros-fillet-picks-model-query.rs','-L','dependency=target/release/deps','-L','native=target/release/build/viboceros-smlib-d4f77638f5302455/out/lib']
for name in ['viboceros_geometry','viboceros_smlib','serde_json']:
 path=Path('target/release/deps')/({'viboceros_geometry':'libviboceros_geometry-12e5b757b7138a69.rlib','viboceros_smlib':'libviboceros_smlib-da7380a2aabece70.rlib','serde_json':'libserde_json-623705b0744aab6f.rlib'}[name]);flags+=['--extern',name+'='+str(path)]
flags+=['-o','/tmp/viboceros-fillet-picks-model-query'];subprocess.run(flags,check=True)
with open('/tmp/viboceros-fillet-picks-model-query.jsonl','w')as out:r=subprocess.run(['/tmp/viboceros-fillet-picks-model-query'],stdout=out,check=True)
