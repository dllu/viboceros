from pathlib import Path
import os,subprocess,json,hashlib
p=Path('crates/viboceros-smlib/native/bridge.cpp')
base=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()
assert base=='3fba75ffc22e2adf74b34cde1355debe41515fee'
candidate=p.read_bytes()
Path('/tmp/viboceros-remote-solid-frozen-bridge.cpp').write_bytes(candidate)
cmd=['cargo','test','-p','viboceros-smlib','-p','viboceros-command','--features','viboceros-command/native-smlib','--test','stitch_remote_solid','--test','native_closed_join','--no-fail-fast','--','--nocapture']
try:
 p.write_bytes(subprocess.check_output(['git','show',base+':'+str(p)]))
 with Path('/tmp/viboceros-remote-solid-baseline-final.log').open('w') as log:
  code=subprocess.run(cmd,env=dict(os.environ,CMAKE_BUILD_PARALLEL_LEVEL='10'),stdout=log,stderr=subprocess.STDOUT).returncode
 Path('/tmp/viboceros-remote-solid-baseline-final.status').write_text(str(code)+'\n')
finally:
 p.write_bytes(candidate)
print(json.dumps(dict(baseline=base,exit_code=code,candidate_restored=True,candidate_sha256=hashlib.sha256(candidate).hexdigest())),flush=True)
raise SystemExit(code)
