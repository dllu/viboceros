import subprocess,os,time,json
from pathlib import Path
p='/tmp/viboceros-fillet-parents-';normal=Path('target/release/build/viboceros-smlib-d4f77638f5302455/out/build');asan=Path('/tmp/viboceros-isocurve-pair-asan')
for name,b,flags in [('normal',normal,[]),('asan',asan,['-fsanitize=address','-g','-fno-omit-frame-pointer'])]:
 a=['c++','-std=c++17','-O1','-DNDEBUG','-I','crates/viboceros-smlib/native',*flags,p+'lifetime-order.cpp',str(b/'libviboceros_smlib.a'),str(b/'libSM_API.a'),str(b/'libSMLib.a'),'-ltbb','-ltbbmalloc','-o',p+'lifetime-'+name];start=time.monotonic()
 with open(p+'lifetime-'+name+'-build.log','w')as log:r=subprocess.run(a,stdout=log,stderr=log)
 if r.returncode:raise SystemExit(r.returncode)
 with open(p+'lifetime-'+name+'.jsonl','w')as out,open(p+'lifetime-'+name+'.log','w')as err:r=subprocess.run([p+'lifetime-'+name],stdout=out,stderr=err,env=dict(os.environ,ASAN_OPTIONS='detect_leaks=0:abort_on_error=1'))
 Path(p+'lifetime-'+name+'.status').write_text(str(r.returncode)+'\n');Path(p+'lifetime-'+name+'-runtime.json').write_text(json.dumps(dict(build_command=a,status=r.returncode,seconds=time.monotonic()-start))+'\n');print(name,r.returncode,flush=True)
 if r.returncode:raise SystemExit(r.returncode)
