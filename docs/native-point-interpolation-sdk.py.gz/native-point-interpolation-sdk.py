import json,math
from pathlib import Path
from tools.rhino_oracle.client import OracleClient
prefix='/tmp/viboceros-point-interpolation-'
rows=[json.loads(l)for l in Path(prefix+'candidate.jsonl').read_text().splitlines()]
selected=[r for r in rows if not r.get('invalid')and r['case']in [0,3,5,7,9,10,11,12,13,14]and r['chart']==1 and r['rational']and r['gauge']==1 and r['order']==0 and not r['preallocated']]
assert len(selected)==10
request=dict(protocol_version=1,iterations=1,operations=[])
for r in selected:
 for label,key in [('expected','expected_homogeneous_controls'),('native','actual_homogeneous_controls')]:
  controls=[dict(point=[x/h[3]for x in h[:3]],weight=h[3])for h in r[key]]
  definition=dict(degree=r['degree'],knots=r['knots'],control_points=controls)
  start,end=r['knots'][r['degree']],r['knots'][len(controls)]
  for i in range(9):
   request['operations'].append(dict(op='nurbs_curve_evaluate',id=str(r['case'])+'-'+str(i)+'-'+label,**definition,parameter=start+(end-start)*i/8))
Path(prefix+'sdk-request.json').write_text(json.dumps(request,indent=2)+'\n')
response=OracleClient(settings_scheme='VibocerosOraclePointInterpolation20261018').run_rhino(request,timeout=180.)
Path(prefix+'sdk-rhino.json').write_text(json.dumps(response,indent=2)+'\n')
assert len(response['results'])==180
values={r['id']:r['value']for r in response['results']};comparisons=[];errors=dict(point=0.,derivative=0.)
for row in selected:
 for i in range(9):
  identifier=str(row['case'])+'-'+str(i);a,b=values[identifier+'-expected'],values[identifier+'-native'];station=dict(id=identifier,errors={})
  for key in errors:
   assert all(math.isfinite(x)for x in a[key]+b[key]);difference=max(abs(x-y)for x,y in zip(a[key],b[key]))
   errors[key]=max(errors[key],difference);station['errors'][key]=difference
  comparisons.append(station)
report=dict(sdk_evaluations=180,paired_stations=90,curves=10,absolute_point_epsilon=1e-10,max_absolute_differences=errors,comparisons=comparisons,passed=errors['point']<=1e-10,
 scope='Rhino evaluates retained expected and fitted definitions at identical parameters, using their exact stored knots and controls. Continuous degree 1/2/3/5/17 unit-chart positive-weight fixtures include interior stations, unclamped bases and nonuniform linear sampling. First derivative differences are retained as diagnostics, not the pass criterion. This is sampled locus agreement, not a Rhino interpolation-producer comparison or continuous bound.')
Path(prefix+'sdk-report.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({k:v for k,v in report.items()if k!='comparisons'}),flush=True);assert report['passed']
