import json
from pathlib import Path
from tools.rhino_oracle.client import OracleClient
from tools.rhino_oracle.audit import compare_audit_response
p='/tmp/viboceros-curve-contact-'
read=lambda name:json.loads(Path(name).read_text())
write=lambda name,value:Path(p+name+'.json').write_text(json.dumps(value,indent=2)+'\n')
request=read('tools/rhino_oracle/fixtures/curve_contacts_tolerance.json')
sdk=read('tools/rhino_oracle/observations/curve_contacts_tolerance.json')
old=compare_audit_response(read(p+'baseline-audit.json'),sdk,1e-8,1e-12,request=request)
assert old.matched==2 and old.native_failed==0
write('baseline-report',old.as_dict())
client=OracleClient(native_smlib=True)
native=client.run_viboceros_audit(request,timeout=600.)
write('candidate-audit',native)
report=compare_audit_response(native,sdk,1e-8,1e-12,request=request)
write('candidate-report',report.as_dict())
assert report.passed and report.matched==5 and report.native_failed==0
f_request=read('tools/rhino_oracle/fixtures/surface_fillet.json')
f_sdk=read('tools/rhino_oracle/observations/surface_fillet.json')
f_native=client.run_viboceros_audit(f_request,timeout=600.)
write('fillet-audit',f_native)
f_raw=compare_audit_response(f_native,f_sdk,1e-8,1e-12,request=f_request)
write('fillet-raw-report',f_raw.as_dict())
expected={r['id']:r['value']for r in f_sdk['results']}
failures=[];compared=0;points=0;point_error=0.;bound_error=0.
for outcome in f_native['outcomes']:
 if outcome['status']=='failure':failures.append(outcome);continue
 row=outcome['result'];a=row['value'];b=expected[row['id']]
 assert a['source_unchanged']and b['source_unchanged']
 assert len(a['outputs'])==len(b['outputs'])==1
 a,b=a['outputs'][0],b['outputs'][0];assert a['valid']and b['valid']
 assert len(a['closest_points'])==len(b['closest_points'])==4
 point_error=max(point_error,max(abs(x-y)for q,r in zip(a['closest_points'],b['closest_points'])for x,y in zip(q,r)))
 bound_error=max(bound_error,max(abs(x-y)for q,r in zip(a['bounds'],b['bounds'])for x,y in zip(q,r)))
 points+=4;compared+=1
assert compared==5 and points==20 and point_error<=1e-8 and bound_error<=1e-8
assert len(failures)==1 and failures[0]['id']=='cylinder-True'
summary=dict(command_cases=5,baseline_complete_matches=old.matched,candidate_complete_matches=report.matched,execution_failures=report.native_failed,absolute_epsilon=1e-8,relative_epsilon=1e-12,normalization='None; compare all captured protocol values, including output coordinates, attributes and input selection.',fillet_followup=dict(executed=6,sampled_successes=compared,paired_closest_points=points,maximum_point_difference=point_error,maximum_bounds_difference=bound_error,complete_raw_matches=f_raw.matched,complete_raw_mismatches=f_raw.as_dict()['mismatched'],failures=failures,scope='Retain the actual curved extension failure. Successful samples do not prove continuous global Rhino parity; complete NURBS/topology differences remain in the raw report.'))
write('comparison',summary);print(json.dumps(summary),flush=True)
