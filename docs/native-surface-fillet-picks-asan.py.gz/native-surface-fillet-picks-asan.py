import json,os,subprocess,time
from pathlib import Path
prefix='/tmp/viboceros-fillet-picks-';build=Path('/tmp/viboceros-isocurve-pair-asan');env=dict(os.environ,ASAN_OPTIONS='detect_leaks=0:abort_on_error=1')
for name,args in [('asan-build',['cmake','--build',str(build),'--parallel','5','--target','viboceros_smlib_surface_fillet_probe']),('asan-fillet',[str(build/'viboceros_smlib_surface_fillet_probe')])]:
 start=time.monotonic()
 with open(prefix+name+'.log','w')as log:
  with open(prefix+name+'.jsonl','w')as out:r=subprocess.run(args,stdout=out if name=='asan-fillet'else log,stderr=log,env=env)
 Path(prefix+name+'.status').write_text(str(r.returncode)+'\n');Path(prefix+name+'-runtime.json').write_text(json.dumps(dict(command=args,status=r.returncode,seconds=time.monotonic()-start))+'\n');print(name,r.returncode,flush=True)
 if r.returncode:raise SystemExit(r.returncode)
