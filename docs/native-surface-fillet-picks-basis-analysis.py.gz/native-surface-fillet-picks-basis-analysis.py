import json,decimal,math
from pathlib import Path
from functools import lru_cache
decimal.getcontext().prec=80
D=decimal.Decimal
request=json.loads(Path('/tmp/viboceros-fillet-extension-basis-sdk-basis-request.json').read_text(),parse_float=D)
ops={o['id']:o for o in request['operations']}
def add(a,b):
 out=[D(0)]*max(len(a),len(b))
 for i,v in enumerate(a):out[i]+=v
 for i,v in enumerate(b):out[i]+=v
 return out
def mul(a,b):
 out=[D(0)]*(len(a)+len(b)-1)
 for i,x in enumerate(a):
  for j,y in enumerate(b):out[i+j]+=x*y
 return out
def polys(s,mid,row):
 knots=list(map(D,s['knots_u']));degree=s['degree_u'];count=s['control_point_count_u']
 @lru_cache(None)
 def basis(i,p):
  if p==0:return [D(int(knots[i]<=mid<knots[i+1]))]
  out=[D(0)]
  a=knots[i+p]-knots[i];b=knots[i+p+1]-knots[i+1]
  if a:out=add(out,mul([-knots[i]/a,1/a],basis(i,p-1)))
  if b:out=add(out,mul([knots[i+p+1]/b,-1/b],basis(i+1,p-1)))
  return out
 out=[[D(0)]for _ in range(4)]
 for i,c in enumerate(s['control_points'][row*count:(row+1)*count]):
  h=[D(x)*D(c['weight'])for x in c['point']]+[D(c['weight'])]
  for axis in range(4):out[axis]=add(out[axis],[x*h[axis]for x in basis(i,degree)])
 return out
records=[]
for k in ['0.5','1.0','2.0']:
 base=ops['basis-'+k+'-original']['surfaces'][1]
 for basis in ['elevated3','elevated4','split']:
  s=ops['basis-'+k+'-'+basis]['surfaces'][1];breaks=sorted(set(map(D,base['knots_u']+s['knots_u'])));bound=D(0)
  for low,high in zip(breaks,breaks[1:]):
   for row in range(2):
    a=polys(base,(low+high)/2,row);b=polys(s,(low+high)/2,row)
    errors=[sum(map(abs,add(x,[-v for v in y])))for x,y in zip(a,b)]
    min_w=min(D(c['weight'])for c in base['control_points']);max_xyz=max(abs(D(x))for c in s['control_points']for x in c['point'])
    bound=max(bound,max((errors[i]+max_xyz*errors[3])/min_w for i in range(3)))
  assert bound<D('1e-12'),(k,basis,bound)
  records.append(dict(mobius=k,basis=basis,maximum_coordinate_bound=float(bound)))
record=dict(method='Independent 80-digit Decimal Cox-de Boor power-polynomial expansion on every knot span. Compare all homogeneous coefficients for both V rows against the original degree-two chart. Sum absolute coefficient differences on [0,1], divide by the positive source weight lower bound, and bound Cartesian denominator perturbations using the target control hull. Bounds include decimal JSON coefficient rounding; tensor V blending preserves them.',records=records,maximum_coordinate_bound=max(r['maximum_coordinate_bound']for r in records),scope='A complete same-parameter image equivalence bound for these finite JSON input recipes. It does not certify a general extension algorithm or output surfaces.')
Path('/tmp/viboceros-fillet-picks-basis-analysis.json').write_text(json.dumps(record,indent=2)+'\n');print(json.dumps(record))
