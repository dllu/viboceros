import json,os,subprocess
from pathlib import Path
p='/tmp/viboceros-drop-accuracy-'
for label,build in [('normal',Path('target/debug/build/viboceros-smlib-e982af202de3f65b/out/build')),('asan',Path('/tmp/viboceros-isocurve-pair-asan'))]:
 with open(p+'fillet-'+label+'-build.log','w')as log:r=subprocess.run(['cmake','--build',str(build),'--target','viboceros_smlib_surface_fillet_probe','-j10'],stdout=log,stderr=subprocess.STDOUT)
 assert r.returncode==0
 with open(p+'fillet-'+label+'.jsonl','w')as out,open(p+'fillet-'+label+'.stderr','w')as err:r=subprocess.run([str(build/'viboceros_smlib_surface_fillet_probe')],stdout=out,stderr=err,timeout=600,env=dict(os.environ,ASAN_OPTIONS='detect_leaks=0:halt_on_error=1'))
 Path(p+'fillet-'+label+'.status').write_text(str(r.returncode)+'\n')
 rows=[json.loads(x)for x in Path(p+'fillet-'+label+'.jsonl').read_text().splitlines()]
 assert len(rows)==66 and all(x['passed']for x in rows)and r.returncode==0
 print(label,len(rows),r.returncode,flush=True)

flags=Path('/tmp/viboceros-isocurve-pair-asan/CMakeFiles/viboceros_smlib_surface_fillet_probe.dir/flags.make').read_text()
assert '-fsanitize=address' in flags
