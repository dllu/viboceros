use viboceros_geometry::{NurbsSurface,Point3,WeightedPoint3,Tolerance};
use viboceros_smlib::{SurfaceFilletOptions,fillet_surfaces};
use serde_json::{Value,json};
fn main(){
 let request:Value=serde_json::from_slice(&std::fs::read("tools/rhino_oracle/fixtures/surface_fillet_picks.json").unwrap()).unwrap();
 let sdk:Value=serde_json::from_slice(&std::fs::read("tools/rhino_oracle/observations/surface_fillet_picks.json").unwrap()).unwrap();
 let tol=Tolerance::try_new(1e-8,1e-12,1e-8).unwrap();
 for op in request["operations"].as_array().unwrap(){
  if op["id"]!="cylinder--6.0-0.2"{continue;}
  let surfaces=op["surfaces"].as_array().unwrap().iter().map(|s|{
   let points=s["control_points"].as_array().unwrap().iter().map(|p|WeightedPoint3::try_new(Point3::try_new(p["point"][0].as_f64().unwrap(),p["point"][1].as_f64().unwrap(),p["point"][2].as_f64().unwrap()).unwrap(),p["weight"].as_f64().unwrap()).unwrap()).collect();
   let knots=|key:&str|s[key].as_array().unwrap().iter().map(|k|k.as_f64().unwrap()).collect();
   NurbsSurface::try_new_rational(s["degree_u"].as_u64().unwrap()as usize,s["degree_v"].as_u64().unwrap()as usize,s["control_point_count_u"].as_u64().unwrap()as usize,s["control_point_count_v"].as_u64().unwrap()as usize,points,knots("knots_u"),knots("knots_v")).unwrap()
  }).collect::<Vec<_>>();
  let picks=std::array::from_fn(|i|std::array::from_fn(|j|op["picks"][i][j].as_f64().unwrap()));
  let options=SurfaceFilletOptions::try_from_picks(&surfaces[0],&surfaces[1],picks,0.75,false,tol).unwrap();
  let b=fillet_surfaces(&surfaces[0],&surfaces[1],options,tol).unwrap().unwrap();
  let expected=&sdk["results"].as_array().unwrap().iter().find(|r|r["id"]==op["id"]).unwrap()["value"]["outputs"][0]["closest_points"];
  for (i,q)in op["queries"].as_array().unwrap().iter().enumerate(){
   let q=Point3::try_new(q[0].as_f64().unwrap(),q[1].as_f64().unwrap(),q[2].as_f64().unwrap()).unwrap();
   let beta=(q.x().hypot(q.y())-4.25).atan2(q.z()+0.75).clamp(0.,std::f64::consts::FRAC_PI_2);
   let theta=q.y().atan2(q.x());let r=4.25+0.75*beta.sin();let analytic=Point3::try_new(r*theta.cos(),r*theta.sin(),-0.75+0.75*beta.cos()).unwrap();
   for accuracy in [1e-8,1e-9,1e-10,1e-11]{
    let t=Tolerance::try_new(accuracy,1e-14,1e-10).unwrap();let(face,u,v)=b.closest_face_parameters(q,t).unwrap().unwrap();let p=b.faces()[face].surface().evaluate(u,v).unwrap();
    println!("{}",json!({"i":i,"accuracy":accuracy,"point":p.to_array(),"analytic":analytic.to_array(),"sdk":expected[i],"analytic_gap":p.distance_to(analytic).unwrap()}));
   }
  }
 }
}
