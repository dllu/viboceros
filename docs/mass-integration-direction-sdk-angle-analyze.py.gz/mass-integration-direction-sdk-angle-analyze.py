import json,math
from pathlib import Path
request=json.loads(Path('/tmp/viboceros-fillet-extension-shape-sdk-request.json').read_text())
result=json.loads(Path('/tmp/viboceros-fillet-extension-shape-sdk-response.json').read_text())
ops={o['id']:o for o in request['operations']};summary=[]
def parameter(theta,total,k):
 q=math.cos(total/2)
 def angle(t):
  d=(1-t)**2+2*q*k*t*(1-t)+(k*t)**2
  x=((1-t)**2+2*q*k*t*(1-t)+(k*t)**2*math.cos(total))/d
  y=(2*q*k*t*(1-t)*math.tan(total/2)+(k*t)**2*math.sin(total))/d
  return math.atan2(y,x)
 lo=-.24;hi=1.24
 for _ in range(100):
  mid=(lo+hi)/2
  if angle(mid)<theta:lo=mid
  else:hi=mid
 return (lo+hi)/2
for row in result['results']:
 op=ops[row['id']];total=math.radians(float(row['id'].split('-')[1]))if row['id'].startswith('angle-')else math.pi/2
 k=float(row['id'].split('-')[1])if row['id'].startswith('mobius-')else 1.
 records=[]
 for output in row['value']['outputs']:
  points=[v['point']for v in output['geometry']['vertices']if abs(v['point'][2])<1e-6]
  angles=sorted(math.atan2(p[1],p[0])for p in points)
  ts=[parameter(t,total,k)for t in angles]
  s=output['geometry']['faces'][0]['definition']
  records.append(dict(angles=angles,original_parameters=ts,angular_extension=[-angles[0],angles[-1]-total],area=output['area'],u_domain=s['domain_u']))
 summary.append(dict(id=row['id'],extend=op['extend'],outputs=records,elapsed_ns=row['elapsed_ns']))
 print(row['id'],records,flush=True)
Path('/tmp/viboceros-fillet-extension-shape-analysis.json').write_text(json.dumps(summary,indent=2)+'\n')
