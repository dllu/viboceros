import json
from pathlib import Path
from tools.rhino_oracle.client import OracleClient
prefix='/tmp/viboceros-tensor-bezier-'
class RecordingClient(OracleClient):
 def run_viboceros_audit(self,request,timeout=180.):
  self.response=super().run_viboceros_audit(request,timeout)
  return self.response
client=RecordingClient(native_smlib=True)
for stem,count in [('bezier_conversion',44),('single_span_conversion',78)]:
 request=json.loads(Path('tools/rhino_oracle/fixtures/'+stem+'.json').read_text())
 reference=json.loads(Path('tools/rhino_oracle/observations/'+stem+'.json').read_text())
 report=client.replay(request,reference,absolute_epsilon=1e-8,relative_epsilon=1e-12,timeout=1800.)
 Path(prefix+stem+'-audit.json').write_text(json.dumps(client.response,indent=2)+'\n')
 Path(prefix+stem+'-report.json').write_text(json.dumps(report.as_dict(),indent=2)+'\n')
 print(json.dumps(dict(fixture=stem,executed=count,matches=report.matched,execution_errors=report.native_failed)),flush=True)
 assert report.matched==count and report.native_failed==0
