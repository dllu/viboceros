import gzip,json,math,subprocess,time
from pathlib import Path
from tools.rhino_oracle.audit import compare_audit_response
p='/tmp/viboceros-fillet-charts-';start=time.monotonic()
def read(path):return json.loads(Path(path).read_text())
def values(response):
 assert all(r['status']=='success'for r in response['outcomes'])
 return {r['result']['id']:r['result']['value']for r in response['outcomes']}
def gap(a,b,key):return max(abs(x-y)for x,y in zip((x for row in a[key]for x in row),(x for row in b[key]for x in row)))
request=read(p+'baseline-request.json');subprocess.run(['target/release/viboceros-oracle','--audit',p+'baseline-request.json',p+'candidate-audit.json'],check=True,timeout=600.)
candidate=read(p+'candidate-audit.json');a=values(candidate);before=values(read(p+'baseline-audit.json'))
new=read('tools/rhino_oracle/fixtures/surface_fillet_charts.json');sdk=read('tools/rhino_oracle/observations/surface_fillet_charts.json');expected={r['id']:r['value']for r in sdk['results']}
# Compare complete raw new-case values, without removing fields, reordering
# results or normalizing coefficients; numerical geometry checks follow below.
subset=dict(candidate,outcomes=[r for r in candidate['outcomes']if r['result']['id']in expected]);raw=compare_audit_response(subset,sdk,1e-8,1e-12,request=new)
Path(p+'raw-report.json').write_text(json.dumps(raw.as_dict(),indent=2)+'\n')
old_ids=set(before)-set(expected);assert len(old_ids)==32;assert all(a[k]==before[k]for k in old_ids)
canonical={r['id']:r['value']for r in read('tools/rhino_oracle/observations/surface_fillet_parents.json')['results']};rows=[];parents=0;baseline_domains=0;literal_failures=[]
for op in new['operations']:
 id=op['id'];actual=a[id];base=before[id];primary=expected[id]
 bodies=primary['outputs']+sum(primary['parents'],[]);largest=max(part['tolerance']for body in bodies for table in ['vertices','edges']for part in body['geometry'][table])
 unreliable=gap(actual['outputs'][0],primary['outputs'][0],'bounds')>1e-8;e=canonical[id.rsplit('-',1)[0]]if unreliable else primary
 if unreliable:
  assert largest>1e-8 and primary['outputs'][0]['geometry']['faces'][0]['definition']['control_count']==[7,3]
  literal_failures.append(dict(id=id,largest_component_tolerance=largest,fillet_bounds_difference=gap(actual['outputs'][0],primary['outputs'][0],'bounds')))
 assert actual['source_unchanged']and e['source_unchanged']and len(actual['outputs'])==len(e['outputs'])==1
 assert actual['outputs']==base['outputs'],id
 assert actual['outputs']==a[id.rsplit('-',1)[0]]['outputs'],(id,'canonical native fillet invariance')
 bounds=gap(actual['outputs'][0],e['outputs'][0],'bounds');assert bounds<=1e-8,(id,bounds)
 groups=[]
 for i,(ag,eg,bg)in enumerate(zip(actual['parents'],e['parents'],base['parents'])):
  assert len(ag)==len(eg)==len(bg);unused=set(range(len(eg)));out=[]
  for aa,bb in zip(ag,bg):
   j=min(unused,key=lambda j:gap(aa,eg[j],'bounds'));unused.remove(j);ee=eg[j];parents+=1
   assert aa['geometry']['vertices']==bb['geometry']['vertices']and aa['geometry']['edges']==bb['geometry']['edges'],(id,'spatial tables')
   ad=aa['geometry']['faces'][0]['definition'];bd=bb['geometry']['faces'][0]['definition'];ed=ee['geometry']['faces'][0]['definition']
   assert ad['control_points']==bd['control_points'],(id,'surface controls')
   fresh=primary['parents'][i][0]['geometry']['faces'][0]['definition'];assert all(ad[k]==fresh[k]for k in ['domain_u','domain_v']),(id,'domain')
   baseline_domains+=any(bd[k]!=fresh[k]for k in ['domain_u','domain_v'])
   bounds_error=gap(aa,ee,'bounds');distance_error=max(abs(math.dist(q,ap)-math.dist(q,ep))for q,ap,ep in zip(op['queries'],aa['closest_points'],ee['closest_points']))
   assert bounds_error<=1e-8 and distance_error<=1e-8,(id,i,bounds_error,distance_error)
   out.append(dict(sdk_index=j,bounds_error=bounds_error,closest_distance_error=distance_error,area_error=abs(aa['area']-ee['area']),spatial_tables_unchanged=True,domain_matches=True))
  groups.append(out)
 rows.append(dict(id=id,fillet_complete_value_unchanged=True,fillet_bounds_error=bounds,parents=groups))
# Preserve all 22 existing fillet-only protocol values as well.
contracts=[]
for fixture,label in [('surface_fillet.json','original-six'),('surface_fillet_picks.json','original-picks')]:
 req='tools/rhino_oracle/fixtures/'+fixture
 for executable,version in [(p+'baseline-oracle','baseline'),('target/release/viboceros-oracle','candidate')]:
  out=p+label+'-'+version+'-audit.json';subprocess.run([executable,'--audit',req,out],check=True,timeout=600.)
 old=values(read(p+label+'-baseline-audit.json'));newer=values(read(p+label+'-candidate-audit.json'));assert old==newer,label;contracts.append(dict(fixture=fixture,complete_values_unchanged=len(old)))
assert len(literal_failures)==8
summary=dict(literal_sdk_geometry_failures=literal_failures,same_request_sdk_geometry_matches=24,canonical_sdk_geometry_matches=32,recipes=32,parent_bodies=parents,baseline_parent_domain_mismatches=baseline_domains,candidate_parent_domain_matches=parents,old_parent_complete_values_unchanged=len(old_ids),fillet_only_contracts=contracts,raw_matches=raw.matched,raw_mismatches=raw.as_dict()['mismatched'],absolute_epsilon=1e-8,relative_epsilon=1e-12,records=rows,seconds=time.monotonic()-start,scope='Full raw protocol values remain unnormalized. All 32 match fresh SDK domain endpoints. Eight literal SDK conditioning failures remain negative controls; geometry is compared with exact canonical-input SDK references for those cases. Bounds, query distances and unchanged-spatial-table checks qualify this scope; integrated oracle tests additionally check sampled interiors/boundaries and analytic radii. No global continuous Rhino equality or arbitrary trim-loop qualification is claimed.')
Path(p+'comparison.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps({k:v for k,v in summary.items()if k!='records'},indent=2),flush=True)
