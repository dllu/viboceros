import json
from pathlib import Path
old=Path('/tmp/viboceros-surface-fillets-axis-baseline');new=Path('/tmp/viboceros-surface-fillets-axis-candidate');rows=[]
for name in ['cylinder-false','cylinder-true']:
 a=json.loads((old/(name+'.json')).read_text());b=json.loads((new/(name+'.json')).read_text())
 for key in ['vertices','faces','closest','extend']:
  assert a[key]==b[key],(name,key)
 assert a['area_swapped']==b['area_swapped']
 if name=='cylinder-true':
  assert a['area']=='Err(NumericalIntegrationDidNotConverge)'and a['area_mass_properties']=='Err(NumericalIntegrationDidNotConverge)'
  assert b['area']=='Ok(28.941496050285952)'and b['area_mass_properties'].startswith('Ok(')
  assert b['area']==b['area_swapped']
 rows.append(dict(id=name,previous_area=a['area'],repaired_area=b['area'],uv_swapped_reference=b['area_swapped'],captured_vertices_surface_metrics_trim_definitions_and_closest_points_unchanged=True,previous_area_mass_properties_success=a['area_mass_properties'].startswith('Ok('),repaired_area_mass_properties_success=b['area_mass_properties'].startswith('Ok(')))
Path('/tmp/viboceros-trim-axis-example-comparison.json').write_text(json.dumps(rows,indent=2)+'\n');print(json.dumps(rows),flush=True)
