import hashlib,json,subprocess
from pathlib import Path
from tools.verify_provenance import verify
base=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()
assert base == 'd6c1a82d1c90433323b55e947676f3fa4e889c14'
cache={}
def blob(ref):
 if ref not in cache:
  r=subprocess.run(['git','cat-file','blob',ref],capture_output=True);cache[ref]=r.stdout if r.returncode==0 else None
 return cache[ref]
def maps(r):return [(k,v)for k,v in r.items()if(k=='sha256'or k.endswith('_sha256'))and isinstance(v,dict)]
def nonsha(r):return {k:v for k,v in r.items()if not(k=='sha256'or k.endswith('_sha256'))}
def valid(r):
 for k,v in maps(r):
  for p,want in v.items():
   data=blob(p if k=='git_sha256'or k.endswith('_git_sha256')else base+':'+p)
   if data is None:
    try:data=Path(p).read_bytes()
    except (OSError,ValueError):return False
   if hashlib.sha256(data).hexdigest()!=want:return False
 return True
records={};skipped=0
for p in subprocess.check_output(['git','ls-files','docs/*.json'],text=True).splitlines():
 original=json.loads(blob(base+':'+p))
 if not isinstance(original,dict)or not maps(original):continue
 if not valid(original):skipped+=1;continue
 current=json.loads(Path(p).read_text());assert nonsha(current)==nonsha(original),p
 records[p]=(original,current)
changed=set(subprocess.check_output(['git','diff','HEAD','--name-only'],text=True).splitlines())-{'AGENTS.md'}
saved=Path('/tmp/viboceros-reparameterize-input-provenance-records.json')
modified=set(json.loads(saved.read_text()))if saved.exists()else set();entries=0
while True:
 moved=0
 for filename,(original,r)in records.items():
  for key,values in maps(r):
   if key=='git_sha256'or key.endswith('_git_sha256'):continue
   for p,want in list(values.items()):
    if p not in changed:continue
    if Path(p).is_file()and hashlib.sha256(Path(p).read_bytes()).hexdigest()==want:continue
    data=blob(base+':'+p);assert data is not None and hashlib.sha256(data).hexdigest()==want,(filename,p)
    target='git_sha256'if key=='sha256'else key[:-7]+'_git_sha256'
    r.setdefault(target,{})[base+':'+p]=values.pop(p);moved+=1;entries+=1;modified.add(filename);changed.add(filename)
  if filename in modified:Path(filename).write_text(json.dumps(r,indent=2,ensure_ascii=blob(base+':'+filename).isascii())+'\n')
 if not moved:break
for p in modified:verify(records[p][1])
Path('/tmp/viboceros-reparameterize-input-provenance-records.json').write_text(json.dumps(sorted(modified)))
print(json.dumps(dict(preserved_entries=sum(sum(p.startswith(base+':')for p in v)for name in modified for k,v in maps(records[name][1])if k=='git_sha256'or k.endswith('_git_sha256')),records=len(modified),preexisting_unverifiable_unchanged=skipped)))
