import copy,json,math,subprocess,time
from pathlib import Path
from tools.rhino_oracle.client import OracleClient
from tools.rhino_oracle.audit import compare_audit_response
prefix='/tmp/viboceros-fillet-picks-';client=OracleClient(native_smlib=True)
read=lambda p:json.loads(Path(p).read_text())
def write(name,value):Path(prefix+name+'.json').write_text(json.dumps(value,indent=2)+'\n')
def values(audit):
 assert not [o for o in audit['outcomes']if o['status']=='failure'],audit
 return {o['result']['id']:o['result']['value']for o in audit['outcomes']}
def summarize(actual,sdk):
 expected={r['id']:r['value']for r in sdk['results']};records=[]
 for id,v in values(actual).items():
  e=expected[id];assert v['source_unchanged']and e['source_unchanged']and len(v['outputs'])==len(e['outputs'])==1
  a,b=v['outputs'][0],e['outputs'][0]
  def gap(key):return max(abs(x-y)for p,q in zip(a[key],b[key])for x,y in zip(p,q))
  point,bounds=gap('closest_points'),gap('bounds')
  records.append(dict(id=id,native_valid=a['valid'],maximum_point_difference=point,maximum_bounds_difference=bounds,native_area=a['area'],sdk_area=b['area'],strict_point_and_bounds_pass=a['valid']and point<=1e-8 and bounds<=1e-8))
 return records
request=read('tools/rhino_oracle/fixtures/surface_fillet_picks.json');sdk=read('tools/rhino_oracle/observations/surface_fillet_picks.json')
baseline=read(prefix+'baseline-audit.json');candidate=client.run_viboceros_audit(request,timeout=600.);write('candidate-audit',candidate)
raw=compare_audit_response(candidate,sdk,1e-8,1e-12,request=request);write('candidate-raw-report',raw.as_dict())
control=copy.deepcopy(request)
for op in control['operations']:op['sides']=[1,1]
write('positive-control-request',control);forced=client.run_viboceros_audit(control,timeout=600.);write('positive-control-audit',forced)
base_records=summarize(baseline,sdk);new_records=summarize(candidate,sdk);assert len(new_records)==16
def images(name,path):
 with open(prefix+name+'-images.jsonl','w')as out:subprocess.run([prefix+'image-compare',str(path)],stdout=out,check=True)
 return [__import__('json').loads(s)for s in Path(prefix+name+'-images.jsonl').read_text().splitlines()]
base_images=images('baseline',prefix+'baseline-audit.json');new_images=images('candidate',prefix+'candidate-audit.json')
assert len(new_images)==16 and all(r['sampled_image_pass']for r in new_images)

control_equal={id:v==values(forced)[id]for id,v in values(baseline).items()}
control_changes=[]
for id,v in values(baseline).items():
 a=v['outputs'][0];b=values(forced)[id]['outputs'][0]
 point=max(abs(x-y)for p,q in zip(a['closest_points'],b['closest_points'])for x,y in zip(p,q))
 bounds=max(abs(x-y)for p,q in zip(a['bounds'],b['bounds'])for x,y in zip(p,q))
 assert bounds<=1e-8,(id,bounds)
 control_changes.append(dict(id=id,maximum_bounds_difference=bounds,maximum_point_difference=point,complete_value_unchanged=control_equal[id]))
# Reaudit all original six recipes and record complete-value changes.
old=read('tools/rhino_oracle/fixtures/surface_fillet.json');old_native=client.run_viboceros_audit(old,timeout=600.);write('original-six-audit',old_native)
import gzip
previous=json.loads(gzip.decompress(Path('docs/native-circular-fillet-rails-fillet-audit.json.gz').read_bytes()))
original_equal={id:v==values(old_native)[id]for id,v in values(previous).items()}
original_records=summarize(old_native,read('tools/rhino_oracle/observations/surface_fillet.json'))
assert all(r['strict_point_and_bounds_pass']for r in original_records if r['id']!='cylinder-True')
assert next(r for r in original_records if r['id']=='cylinder-True')['maximum_bounds_difference']>9
summary=dict(baseline_commit='d59f692febecb247d503e7bb21f9061b931289ae',sdk_recipes=16,queries=64,absolute_epsilon=1e-8,baseline_strict_point_matches=sum(r['strict_point_and_bounds_pass']for r in base_records),baseline_bounds_matches=sum(r['maximum_bounds_difference']<=1e-8 for r in base_records),candidate_strict_point_matches=sum(r['strict_point_and_bounds_pass']for r in new_records),candidate_sampled_image_matches=16,baseline_sampled_image_matches=sum(r['sampled_image_pass']for r in base_images),baseline_images=base_images,candidate_images=new_images,candidate_maximum_point_difference=max(r['maximum_point_difference']for r in new_records),candidate_maximum_bounds_difference=max(r['maximum_bounds_difference']for r in new_records),baseline=base_records,candidate=new_records,positive_control_complete_value_matches=sum(control_equal.values()),positive_control_changes=control_changes,original_six_complete_values_unchanged=sum(original_equal.values()),original_six=original_records,raw_complete_matches=raw.matched,raw_complete_mismatches=raw.as_dict()['mismatched'],scope='All sixteen recipes are executed without side overrides. Checks cover source purity, one valid owned output, bidirectional 81-point surface image membership, membership of all closest points on the other surface, closest distances and tight bounds at the caller epsilon. Literal closest-point coordinate differences remain diagnostics, including tangential discrepancies above epsilon. Full NURBS/topology/area protocols remain unnormalized and are compared separately; sampled geometry checks are not complete protocol parity or a global continuous error certificate. The original curved Extend=Yes extent mismatch remains unqualified.')
write('comparison',summary);print(json.dumps(summary),flush=True)
