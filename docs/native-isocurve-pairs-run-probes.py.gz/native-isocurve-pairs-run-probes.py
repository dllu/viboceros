from pathlib import Path
import os,subprocess,json
root=Path('/home/dllu/proj/viboceros')
binaries=list((root/'target/debug/build').glob('viboceros-smlib-*/out/build/viboceros_smlib_isocurve_pair_probe'))
regular=max(binaries,key=lambda p:p.stat().st_mtime)
for label,binary in [('candidate',regular),('asan',Path('/tmp/viboceros-isocurve-pair-asan/viboceros_smlib_isocurve_pair_probe'))]:
 receipts=[]
 with Path('/tmp/viboceros-isocurve-pair-'+label+'.jsonl').open('w') as out, Path('/tmp/viboceros-isocurve-pair-'+label+'.stderr').open('w') as err:
  for args in [[],['--discontinuity']]:
   env=dict(os.environ,ASAN_OPTIONS='detect_leaks=0:halt_on_error=1')
   code=subprocess.run([str(binary),*args],env=env,stdout=out,stderr=err).returncode
   receipts.append(dict(args=args,exit_code=code))
 Path('/tmp/viboceros-isocurve-pair-'+label+'.status').write_text(str(0 if all(r['exit_code']==0 for r in receipts)else 1)+'\n')
 print(json.dumps(dict(label=label,binary=str(binary),runs=receipts)),flush=True)
 if any(r['exit_code']!=0 for r in receipts):raise SystemExit(1)
