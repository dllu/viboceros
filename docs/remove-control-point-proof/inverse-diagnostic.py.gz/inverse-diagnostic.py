import json
from tools.rhino_oracle.client import OracleClient
rows={x['id']:x['value'] for x in json.load(open('tools/rhino_oracle/observations/remove_control_point_command.json'))['results']}
d=rows['surface_U']['before'][0]['geometry']['surfaces'][0]
s=dict(degree_u=d['degree'][0],degree_v=d['degree'][1],control_point_count_u=d['control_count'][0],control_point_count_v=d['control_count'][1],control_points=d['control_points'],knots_u=d['knots_u'],knots_v=d['knots_v'])
names=['surface_grid_U_1_2','surface_grid_U_2_3','surface_grid_V_1_1','surface_grid_V_2_1','surface_grid_U_1_1','surface_grid_V_1_2']
q=dict(protocol_version=1,iterations=1,operations=[dict(op='surface_closest_point',id='inverse',surface=s,points=[rows[n]['picks'][0] for n in names])])
r=OracleClient(settings_scheme='VibocerosOracleControlInverse20261019').run_rhino(q,timeout=180.)
json.dump(dict(names=names,response=r),open('/tmp/viboceros-remove-control-inverse.json','w'),indent=2)
print(r['results'])
