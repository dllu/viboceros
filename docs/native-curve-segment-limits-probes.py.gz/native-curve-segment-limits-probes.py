import json,os,subprocess
from pathlib import Path
root=Path('/home/dllu/proj/viboceros')
binaries=list((root/'target/debug/build').glob('viboceros-smlib-*/out/build/viboceros_smlib_curve_segment_probe'))
build=max(binaries,key=lambda p:p.stat().st_mtime).parent
Path('/tmp/viboceros-curve-segment-limits-build-path').write_text(str(build))
with open('/tmp/viboceros-curve-segment-limits-baseline-build.log','w')as log:
 r=subprocess.run(['cmake','--build',str(build),'--target','viboceros_smlib_curve_segment_probe','viboceros_smlib_curve_segment_baseline','-j10'],stdout=log,stderr=subprocess.STDOUT)
Path('/tmp/viboceros-curve-segment-limits-baseline-build.status').write_text(str(r.returncode)+'\n')
if r.returncode:raise SystemExit(r.returncode)
asan=Path('/tmp/viboceros-isocurve-pair-asan')
with open('/tmp/viboceros-curve-segment-limits-asan-build.log','w')as log:
 r=subprocess.run(['cmake','-S',str(root/'crates/viboceros-smlib/native'),'-B',str(asan),'-DUSD_BREP_ROOT='+str(root/'third_party/usd-brep'),'-DVIBOCEROS_SMLIB_ASAN=ON','-DCMAKE_BUILD_TYPE=Release'],stdout=log,stderr=subprocess.STDOUT)
 if not r.returncode:r=subprocess.run(['cmake','--build',str(asan),'--target','viboceros_smlib_curve_segment_probe','viboceros_smlib','-j10'],stdout=log,stderr=subprocess.STDOUT)
Path('/tmp/viboceros-curve-segment-limits-asan-build.status').write_text(str(r.returncode)+'\n')
if r.returncode:raise SystemExit(r.returncode)
with open('/tmp/viboceros-curve-segment-limits-asan-flags.txt','w')as log:
 for name in ['SMLib','SM_API','viboceros_smlib','viboceros_smlib_curve_segment_probe']:
  s=(asan/'CMakeFiles'/(name+'.dir')/'flags.make').read_text();assert '-fsanitize=address' in s
  log.write(name+'\n'+s+'\n')
for label,binary,expected in [('baseline',build/'viboceros_smlib_curve_segment_baseline',1),('candidate',build/'viboceros_smlib_curve_segment_probe',0),('asan',asan/'viboceros_smlib_curve_segment_probe',0)]:
 with open('/tmp/viboceros-curve-segment-limits-'+label+'.jsonl','w')as log,open('/tmp/viboceros-curve-segment-limits-'+label+'.stderr','w')as err:
  r=subprocess.run([str(binary)],stdout=log,stderr=err,env=dict(os.environ,ASAN_OPTIONS='detect_leaks=0:halt_on_error=1'))
 Path('/tmp/viboceros-curve-segment-limits-'+label+'.status').write_text(str(r.returncode)+'\n')
 print(json.dumps(dict(label=label,binary=str(binary),exit_code=r.returncode)),flush=True)
 assert r.returncode==expected
