//! Object picking and confirmation are prompt phases, not model transactions.
use super::*;
use std::collections::BTreeSet;
use viboceros_command::{ObjectSelectionFilter, ObjectSelectionPrompt, ObjectSelectionWorkflow};
use viboceros_document::{Geometry, ObjectId, SelectionMode};
#[cfg(test)]
mod control_polygon_tests;
mod divide;
#[cfg(test)]
#[allow(dead_code)]
#[path = "../../crates/viboceros-command/tests/support/frozen_scene.rs"]
mod frozen_scene;
mod merge_surfaces;
#[cfg(test)]
mod mesh_boolean_tests;
mod mesh_conversion;
mod mesh_from_lines;
#[cfg(test)]
mod mesh_intersect_tests;
#[cfg(test)]
mod mesh_outline_tests;
mod mesh_patch;
#[cfg(test)]
mod mesh_polyline_tests;
#[cfg(test)]
#[allow(dead_code)]
#[path = "../../crates/viboceros-geometry/tests/support/mesh_outline.rs"]
mod mesh_reference;
#[cfg(test)]
mod mesh_self_intersect_tests;
#[cfg(test)]
mod mesh_split_tests;
#[cfg(test)]
mod mesh_trim_tests;
mod modify_radius;
#[cfg(test)]
mod planar_mesh_tests;
#[cfg(test)]
mod rebuild_mesh_tests;
#[cfg(test)]
mod rebuild_normals_tests;
mod reduce_polyline;
#[cfg(test)]
mod sweep_tests;
#[cfg(test)]
mod triangulate_tests;
#[cfg(test)]
mod unify_normals_tests;

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub(super) enum ObjectPromptPhase {
    Selecting,
    Options,
    Menu(usize),
    Choice(usize),
    MenuChoice { menu: usize, choice: usize },
    SmoothFactor,
    SmoothSteps,
    RebuildValue(&'static str),
    MergeSurfaceValue(&'static str),
}

#[derive(Clone, Debug, PartialEq)]
pub(super) struct PendingObjectCommand {
    pub(super) description: ObjectSelectionPrompt,
    pub(super) phase: ObjectPromptPhase,
    pub(super) postselected: bool,
    pub(super) subcurve_measurement: bool,
    pub(super) measurement_display_units: Option<&'static str>,
    pub(super) command_override: Option<String>,
    pub(super) excluded_object: Option<ObjectId>,
    pub(super) selection_before: Option<Vec<ObjectId>>,
    pub(super) cloud_removal: Option<PendingCloudRemoval>,
    pub(super) cloud_action_target: Option<ObjectId>,
    pub(super) special_selection: Option<BTreeSet<ObjectId>>,
    pub(super) divide: Option<divide::Session>,
    pub(super) modify_radius: Option<modify_radius::Session>,
    pub(super) reduce_polyline: Option<reduce_polyline::Session>,
    pub(super) mesh_conversion: Option<mesh_conversion::Session>,
    pub(super) mesh_patch: Option<mesh_patch::Session>,
    pub(super) mesh_from_lines: Option<mesh_from_lines::Session>,
    pub(super) to_subd: Option<super::to_subd::Session>,
    pub(super) to_nurbs: Option<super::nurbs_conversion::Session>,
}

#[derive(Clone, Debug, PartialEq, Eq)]
pub(super) struct PendingCloudRemoval {
    pub(super) target: ObjectId,
    pub(super) indices: BTreeSet<usize>,
    pub(super) output_cloud: bool,
}

impl PendingObjectCommand {
    pub(super) fn selecting(description: ObjectSelectionPrompt) -> Self {
        Self {
            description,
            phase: ObjectPromptPhase::Selecting,
            postselected: true,
            subcurve_measurement: false,
            measurement_display_units: None,
            command_override: None,
            excluded_object: None,
            selection_before: None,
            cloud_removal: None,
            cloud_action_target: None,
            special_selection: None,
            divide: None,
            modify_radius: None,
            reduce_polyline: None,
            mesh_conversion: None,
            mesh_patch: None,
            mesh_from_lines: None,
            to_subd: None,
            to_nurbs: None,
        }
    }
    pub(super) fn selection_filter(&self) -> Option<ObjectSelectionFilter> {
        (self.phase == ObjectPromptPhase::Selecting
            && self.cloud_removal.is_none()
            && self.cloud_action_target.is_none())
        .then_some(self.description.filter)
    }

    pub(super) fn label(&self) -> &'static str {
        if let Some(session) = &self.mesh_conversion {
            return session.label();
        }
        if let Some(session) = &self.mesh_from_lines {
            return session.label();
        }
        if let Some(session) = &self.mesh_patch {
            return session.label();
        }
        if let Some(session) = &self.divide {
            return session.prompt.label();
        }
        match self.phase {
            ObjectPromptPhase::Menu(index) => self.description.menus[index].name,
            ObjectPromptPhase::Choice(index) => self.description.choices[index].name,
            ObjectPromptPhase::MenuChoice { menu, choice } => {
                self.description.menus[menu].choices[choice].name
            }
            ObjectPromptPhase::SmoothFactor => "SmoothFactor",
            ObjectPromptPhase::SmoothSteps => "Steps",
            ObjectPromptPhase::RebuildValue(name) | ObjectPromptPhase::MergeSurfaceValue(name) => {
                name
            }
            _ => self.description.command,
        }
    }

    pub(super) fn hint(&self) -> &'static str {
        if self.description.command == "MergeSrf" {
            return if matches!(self.phase, ObjectPromptPhase::MergeSurfaceValue(_)) {
                "Enter an option value; Enter keeps it, Esc cancels MergeSrf"
            } else {
                "Select a pair of surfaces; the second pick merges; Smooth/Tolerance/Roundness; Esc cancels"
            };
        }
        if self.description.command == "Length"
            && self.phase == ObjectPromptPhase::Selecting
            && !self.subcurve_measurement
        {
            return "Select curves or edge components; SelChain selects connected inputs; Units=name changes display units; Enter measures, Esc cancels";
        }
        if let Some(session) = &self.mesh_conversion {
            return session.hint(self.phase);
        }
        if let Some(session) = &self.mesh_from_lines {
            return session.hint();
        }
        if let Some(session) = &self.mesh_patch {
            return session.hint();
        }
        if self.description.command == "ReducePolyline" {
            return if self.phase == ObjectPromptPhase::Selecting {
                "Select polylines; Enter specifies the reduction tolerance, Esc cancels"
            } else {
                "Enter a positive reduction tolerance, Copy=Yes|No; Enter uses the shown tolerance, Esc cancels"
            };
        }
        if self.description.command == "ModifyRadius" {
            return if self.phase == ObjectPromptPhase::Selecting {
                "Select arcs or circles; Enter specifies a radius, Esc cancels"
            } else {
                "Enter a positive size; Radius, Diameter, Area, Circumference, Copy=Yes|No; Esc cancels"
            };
        }
        if self.description.command == "CrvDeviation" {
            return "Select exactly two curves; SubCrv picks a portion; Enter measures, Esc cancels";
        }
        if self.description.command == "CurvatureGraph" {
            return "Select curves, surfaces or polysurfaces; Enter displays curvature graphs, Esc cancels";
        }
        if self.description.command == "ExtractCurvatureGraph" {
            return "Select curves with curvature graphs; Enter extracts outlines, Esc cancels";
        }
        if self.description.command == "RailRevolve" {
            return "Select the profile first, then the rail; Enter picks the axis; Esc cancels";
        }
        if self.description.command == "Sweep1" {
            if self.command_override.as_ref().is_some_and(|input| {
                input.split_whitespace().any(|word| {
                    let name = word
                        .split('=')
                        .next()
                        .unwrap()
                        .trim_start_matches(['_', '-']);
                    name.eq_ignore_ascii_case("RailName") || name.eq_ignore_ascii_case("RailId")
                })
            }) {
                return "Select profiles in order; Point/StartPoint/EndPoint/Undo; Enter sweeps along the specified rail, Esc cancels";
            }
            if self.command_override.as_ref().is_some_and(|input| {
                input.split_whitespace().any(|word| {
                    word.split('=')
                        .next()
                        .unwrap()
                        .trim_start_matches(['_', '-'])
                        .eq_ignore_ascii_case("Parameters")
                })
            }) {
                return "Select profiles in parameter order, then the rail last; Point/StartPoint/EndPoint/Undo; Enter sweeps, Esc cancels";
            }
            return "Select the rail first, then profiles in order (or only profiles for a named rail); Point/StartPoint/EndPoint/Undo; Enter sweeps, Esc cancels";
        }
        if self.description.command == "Divide" {
            return if self.phase == ObjectPromptPhase::Selecting {
                if self.description.workflow == ObjectSelectionWorkflow::OptionsDuringSelection {
                    "Select curves; Enter divides, Esc cancels"
                } else {
                    "Select curves; Enter opens division options, Esc cancels"
                }
            } else {
                "Enter a number or choose Length, EqualChordLength, NumberSegments or output options; Enter creates the previewed result, Esc cancels"
            };
        }
        if self.description.command == "BooleanUnion" {
            return "Select at least two surfaces or polysurfaces, or type options; Enter unions, Esc cancels";
        }
        if self.description.command == "MeshSelfIntersect" {
            return "Select meshes, surfaces or polysurfaces; Enter finds self-intersections, Esc cancels";
        }
        if self.description.command == "MeshIntersect" {
            return "Select at least two meshes, surfaces or polysurfaces; Enter intersects, Esc cancels";
        }
        if self.description.command == "MeshBooleanUnion" {
            return "Select at least two meshes, surfaces or polysurfaces; Enter unions, Esc cancels";
        }
        if self.description.command == "Smooth" {
            return match self.phase {
                ObjectPromptPhase::Selecting => {
                    "Select curves, surfaces, meshes, or control points; Enter opens options, Esc cancels"
                }
                ObjectPromptPhase::SmoothFactor => {
                    "Enter a smoothing factor; Enter keeps the shown value, Esc cancels"
                }
                ObjectPromptPhase::SmoothSteps => {
                    "Enter a positive step count; Enter keeps the shown value, Esc cancels"
                }
                _ => "Choose Smooth options; Enter applies, Esc cancels",
            };
        }
        if self.description.command == "Rebuild" && self.phase != ObjectPromptPhase::Selecting {
            return if matches!(self.phase, ObjectPromptPhase::RebuildValue(_)) {
                "Enter an option value; Enter keeps it, Esc cancels"
            } else {
                "Edit counts, degrees or output options; Enter rebuilds, Esc cancels"
            };
        }
        if self.description.command == "Sphere FitPoints" {
            return "Select at least three points or grips; Enter fits a sphere, Esc cancels";
        }
        if self.description.command == "LineThroughPt" {
            return "Select at least two points, cloud points, meshes or grips; Enter fits a line, Esc cancels";
        }
        if self.description.command == "Weight" {
            return if self.phase == ObjectPromptPhase::Selecting {
                "Select curve or surface control points; Enter continues, Esc cancels"
            } else {
                "Enter a positive control point weight; Enter uses the default, Esc cancels"
            };
        }
        if self.description.command == "HidePt" {
            return "Select control or edit points to hide; Enter hides, Esc cancels";
        }
        if self.description.command == "PlaneThroughPt" {
            return "Select at least three points, cloud points or control points; Enter fits a plane, Esc cancels";
        }
        if self.description.command == "SubDSphere FitPoints" {
            return "Select at least three points or control points; Enter fits the sphere, Esc cancels";
        }
        if matches!(
            self.description.command,
            "Circle FitPoints"
                | "SubDCylinder FitPoints"
                | "SubDCone FitPoints"
                | "SubDTruncatedCone FitPoints"
                | "SubDTorus FitPoints"
                | "SubDSphere FitPoints"
        ) {
            return "Select at least three points or control points; Enter fits the circle, Esc cancels";
        }
        if self.description.command == "ShrinkTrimmedSrf"
            && self.phase == ObjectPromptPhase::Selecting
        {
            return "Select surfaces or polysurfaces; Ctrl/Command+Shift selects faces; Enter applies, Esc cancels";
        }
        if self.special_selection.is_some() {
            return "Select objects; SelAll or SelNone adjusts selection; Enter finishes, Esc cancels";
        }
        if self.description.command == "ReducePointCloud"
            && self.phase == ObjectPromptPhase::Options
        {
            return "Enter number to remove or Percent=n; Esc cancels";
        }
        if self.cloud_action_target.is_some() {
            return "Selected point cloud: type Add or Remove; Esc cancels";
        }
        if self.cloud_removal.is_some() {
            return "Pick cloud points or drag a window; Output=Points|PointCloud; Enter removes, Esc cancels";
        }
        if self.phase == ObjectPromptPhase::Selecting
            && self.description.allows_selection_options()
            && matches!(
                self.description.workflow,
                ObjectSelectionWorkflow::QuestionAfterSelection { .. }
            )
        {
            return "Select objects or type options; Enter finishes, Esc cancels";
        }
        match self.phase {
            ObjectPromptPhase::RebuildValue(_) | ObjectPromptPhase::MergeSurfaceValue(_) => {
                "Enter an option value; Enter keeps it, Esc cancels"
            }
            ObjectPromptPhase::Selecting if self.description.command == "OffsetSubD" => {
                "Select SubD objects; Enter opens offset options, Esc cancels"
            }
            ObjectPromptPhase::Selecting => match self.description.workflow {
                ObjectSelectionWorkflow::OptionsDuringSelection
                | ObjectSelectionWorkflow::QuestionOnPreselection { .. } => {
                    if self.description.filter == ObjectSelectionFilter::Grouped {
                        "Select grouped objects or type options; Enter finishes, Esc cancels"
                    } else {
                        "Select objects or type options; Enter finishes, Esc cancels"
                    }
                }
                ObjectSelectionWorkflow::ConfirmAfterSelection => {
                    "Select objects; Enter opens conversion options, Esc cancels"
                }
                ObjectSelectionWorkflow::ChooseBooleanAfterSelection => {
                    "Select curves and surfaces; Enter opens the deletion question, Esc cancels"
                }
                ObjectSelectionWorkflow::QuestionAfterSelection { .. } => {
                    "Select objects; Enter continues, Esc cancels selection"
                }
                ObjectSelectionWorkflow::PointInputAfterSelection => {
                    "Select objects; Enter continues to transform points, Esc cancels"
                }
            },
            ObjectPromptPhase::Options
                if self.description.workflow
                    == ObjectSelectionWorkflow::ChooseBooleanAfterSelection =>
            {
                "Delete input? Yes or No converts; Enter uses the shown choice, Esc cancels"
            }
            ObjectPromptPhase::Options
                if matches!(
                    self.description.workflow,
                    ObjectSelectionWorkflow::QuestionAfterSelection { .. }
                        | ObjectSelectionWorkflow::QuestionOnPreselection { .. }
                ) =>
            {
                match self.description.workflow {
                    ObjectSelectionWorkflow::QuestionAfterSelection { message, .. }
                    | ObjectSelectionWorkflow::QuestionOnPreselection { message } => message,
                    _ => unreachable!(),
                }
            }
            ObjectPromptPhase::Options => "Set conversion options; Enter converts, Esc cancels",
            ObjectPromptPhase::Menu(_) => {
                "Set options; Enter returns to conversion options, Esc cancels"
            }
            ObjectPromptPhase::Choice(_) | ObjectPromptPhase::MenuChoice { .. } => {
                "Choose a value; Enter keeps the shown choice, Esc cancels"
            }
            ObjectPromptPhase::SmoothFactor | ObjectPromptPhase::SmoothSteps => {
                unreachable!("Smooth hints handled above")
            }
        }
    }
}

impl VibocerosApp {
    pub(super) fn try_select_prompt_points(&mut self, input: &str) -> bool {
        let pending = self.object_prompt.as_ref().filter(|p| {
            p.phase == ObjectPromptPhase::Selecting
                && (matches!(
                    p.description.command,
                    "Circle FitPoints"
                        | "SubDCylinder FitPoints"
                        | "SubDCone FitPoints"
                        | "SubDTruncatedCone FitPoints"
                        | "SubDTorus FitPoints"
                        | "SubDSphere FitPoints"
                        | "PlaneThroughPt"
                        | "LineThroughPt"
                        | "Sphere FitPoints"
                        | "Smooth"
                        | "HidePt"
                        | "ExtractPt"
                        | "Weight"
                ) || (p.description.workflow
                    == ObjectSelectionWorkflow::PointInputAfterSelection
                    && super::transform_sources::allows_grips(p.description.command)))
        });
        let (filter, excluded) = if let Some(pending) = pending {
            (pending.description.filter, pending.excluded_object)
        } else if self.intersection_prompt.as_ref().is_some_and(|p| {
            p.curve_extraction.is_some()
                && p.name() == "ExtractPt"
                && p.uv_subcurves.pending.is_none()
        }) {
            (ObjectSelectionFilter::ExtractPoints, None)
        } else {
            return false;
        };
        let action =
            match viboceros_command::point_selection::PointSelectionAction::from_input(input) {
                Ok(Some(action)) => action,
                Ok(None) => return false,
                Err(error) => {
                    self.push_log(format!("Error: {error}"));
                    self.command_input.clear();
                    return true;
                }
            };
        match action.apply(&mut self.document, |o| {
            Some(o.id()) != excluded && filter.accepts_object(o)
        }) {
            Ok(message) => self.push_log(message),
            Err(error) => self.push_log(format!("Error: {error}")),
        }
        self.command_input.clear();
        true
    }

    fn point_cloud_prompt_target(&self, input: &str) -> Option<ObjectId> {
        let explicit = input
            .split_whitespace()
            .skip(2)
            .filter_map(|argument| argument.split_once('='))
            .find(|(name, _)| name.trim_start_matches('_').eq_ignore_ascii_case("Target"))
            .and_then(|(_, value)| value.parse::<ObjectId>().ok());
        let target = explicit.or_else(|| {
            let mut clouds = self
                .document
                .selected_objects()
                .filter(|object| matches!(object.geometry(), Geometry::PointCloud(_)));
            let first = clouds.next()?.id();
            clouds.next().is_none().then_some(first)
        })?;
        self.document
            .object(target)
            .filter(|object| matches!(object.geometry(), Geometry::PointCloud(_)))
            .map(|_| target)
    }

    pub(super) fn viewport_object_filter(&self) -> Option<ObjectSelectionFilter> {
        if self.chain_prompt.is_some() || self.edge_pattern_prompt.is_some() {
            return None;
        }
        if self.picking_draft_pull_curve() {
            return Some(ObjectSelectionFilter::Curves);
        }
        if self.direction_session.is_some() {
            return None;
        }
        if self.picking_splop_fit_points() {
            return Some(ObjectSelectionFilter::Points);
        }
        if self.picking_splop_reference_curve() {
            return Some(ObjectSelectionFilter::Curves);
        }
        if let Some(prompt) = &self.refinement_prompt {
            return prompt
                .selecting()
                .then_some(ObjectSelectionFilter::Parametric);
        }
        if let Some(prompt) = &self.reparameterize_prompt {
            return prompt
                .selecting()
                .then_some(ObjectSelectionFilter::Parametric);
        }
        if self.picking_curve_chamfer() || self.picking_curve_fillet() {
            return Some(ObjectSelectionFilter::Curves);
        }
        if self.picking_line_curve()
            || self.picking_arc_extension_curve()
            || self.picking_tangent_curve()
            || self.picking_spiral_rail()
            || self.picking_conic_curve()
            || self.picking_rectangle_curve()
        {
            return Some(ObjectSelectionFilter::Curves);
        }
        if self.orient_surface_session.is_some() {
            return self
                .picking_orient_surface()
                .then_some(ObjectSelectionFilter::SurfaceComponents);
        }
        if self.surface_flow_session.is_some() {
            return self
                .picking_surface_flow()
                .then_some(ObjectSelectionFilter::SurfaceComponents);
        }
        if self.flow_session.is_some() {
            if self.picking_flow_surface() {
                return Some(ObjectSelectionFilter::SurfaceComponents);
            }
            return self
                .picking_flow_guide()
                .then_some(ObjectSelectionFilter::Curves);
        }
        if self.curve_array_session.is_some() {
            return self
                .picking_curve_array()
                .then_some(ObjectSelectionFilter::Curves);
        }
        if self.array_surface_session.is_some() {
            return self
                .picking_surface_array()
                .then_some(ObjectSelectionFilter::SurfaceComponents);
        }
        if self.array_curve_surface_session.is_some() {
            return if self.picking_array_surface() {
                Some(ObjectSelectionFilter::SurfaceComponents)
            } else {
                self.picking_array_curve()
                    .then_some(ObjectSelectionFilter::Curves)
            };
        }
        if self.surface_offset_session.is_some() {
            return if self.picking_surface_offset_face() {
                Some(ObjectSelectionFilter::SurfaceComponents)
            } else {
                self.picking_surface_offset_curve()
                    .then_some(ObjectSelectionFilter::Curves)
            };
        }
        if self.orient_edge_session.is_some() {
            return self
                .picking_orient_edge()
                .then_some(ObjectSelectionFilter::Curves);
        }
        if self.picking_orient_curve() {
            return Some(ObjectSelectionFilter::Curves);
        }
        if self.picking_project_direction() || self.picking_project_plane_points() {
            return None;
        }
        if let Some(p) = &self.curve_boolean_prompt {
            return (p.selecting() && !p.wants_point()).then_some(ObjectSelectionFilter::Curves);
        }
        if self.blend_surface_prompt.is_some() || self.fillet_surface_prompt.is_some() {
            return None;
        }
        if self.picking_block_edit_sources() {
            return Some(ObjectSelectionFilter::BlockEditSources);
        }
        if self.adding_to_block() {
            return Some(if self.picking_block_add_target() {
                ObjectSelectionFilter::Blocks
            } else {
                ObjectSelectionFilter::Any
            });
        }
        if self.replacing_block() {
            return self
                .picking_replace_block()
                .then_some(ObjectSelectionFilter::Blocks);
        }
        if let Some(p) = &self.sweep_session {
            return p.selecting().then_some(ObjectSelectionFilter::Curves);
        }
        if let Some(p) = &self.loft_prompt {
            return p.selecting().then_some(ObjectSelectionFilter::Curves);
        }
        if let Some(p) = &self.tween_surfaces_prompt {
            return p.selecting().then_some(ObjectSelectionFilter::Surfaces);
        }
        if self.planar_boolean_prompt.is_some() {
            return Some(ObjectSelectionFilter::Surfaces);
        }
        if let Some(p) = &self.boolean_two_prompt {
            return (!p.cycling()).then_some(ObjectSelectionFilter::SurfaceComponents);
        }
        if self.subcurve_prompt.is_some() {
            return Some(ObjectSelectionFilter::Curves);
        }
        if self.picking_scale_by_plane_object() {
            return Some(ObjectSelectionFilter::Any);
        }
        if self.picking_mirror_object() {
            return Some(ObjectSelectionFilter::SurfaceComponents);
        }
        if self.set_view_prompt.is_some()
            && !self
                .plane_prompt
                .as_ref()
                .is_some_and(construction_plane::PlanePrompt::requests_object)
        {
            return None;
        }
        if self.edge_prompt.is_some()
            || self.hole_prompt.is_some()
            || self.unjoin_prompt.is_some()
            || self.edge_fillet_prompt.is_some()
            || self.crease_prompt.is_some()
            || self.soft_crease_prompt.is_some()
        {
            return None;
        }
        if self.picking_alignment_curve() {
            return Some(ObjectSelectionFilter::Curves);
        }
        if self.group_prompt == Some(group_prompt::GroupPrompt::Target) {
            return Some(ObjectSelectionFilter::Grouped);
        }
        if let Some(prompt) = &self.intersection_prompt {
            return Some(prompt.filter());
        }
        self.object_prompt
            .as_ref()
            .map_or(Some(ObjectSelectionFilter::Any), |prompt| {
                prompt.selection_filter()
            })
    }

    pub(super) fn try_start_object_prompt(&mut self, input: &str) -> bool {
        // Move's Normal descriptor describes its later read-only reference
        // prompt. Source selection must still use the transform workflow.
        let words = input.split_whitespace().collect::<Vec<_>>();
        if words.first().is_some_and(|name| {
            matches!(
                name.trim_start_matches(['_', '-'])
                    .to_ascii_lowercase()
                    .as_str(),
                "move" | "m"
            )
        }) && words.iter().skip(1).any(|word| {
            word.trim_start_matches(['_', '-'])
                .eq_ignore_ascii_case("Normal")
        }) {
            if self.document.selected_object_count() != 0 {
                return false;
            }
            // Native command-first inline base options are consumed during
            // source selection; the user chooses Normal again after Enter.
            return self.try_start_object_prompt("Move");
        }
        if input.split_whitespace().next().is_some_and(|n| {
            n.trim_start_matches(['_', '-'])
                .eq_ignore_ascii_case("Weight")
        }) && self.document.selected_control_points().next().is_some()
            && self
                .document
                .selected_weight_control_points()
                .next()
                .is_none()
        {
            return false;
        }
        let description = match self.commands.object_selection_prompt(input) {
            Ok(Some(prompt)) => prompt,
            Ok(None) => return false,
            Err(error) => {
                self.push_log(format!("Error: {error}"));
                self.command_input = input.into();
                return true;
            }
        };
        if description.command == "MeshFromLines" {
            return self.start_mesh_from_lines_prompt(input, description);
        }
        if description.command == "MeshPatch" {
            return self.start_mesh_patch_prompt(input, description);
        }
        // Starting selection is a command start even if the user later cancels.
        // The shared Copy policy resets saved defaults here when disabled.
        self.commands.begin_copy_options(description.command);
        if matches!(
            description.filter,
            ObjectSelectionFilter::HiddenObjects | ObjectSelectionFilter::LockedObjects
        ) {
            self.cancel_interactive_command(false);
            self.object_prompt = Some(PendingObjectCommand {
                description,
                phase: ObjectPromptPhase::Selecting,
                postselected: false,
                subcurve_measurement: false,
                measurement_display_units: None,
                command_override: None,
                excluded_object: None,
                selection_before: None,
                cloud_removal: None,
                cloud_action_target: None,
                special_selection: Some(BTreeSet::new()),
                divide: None,
                modify_radius: None,
                reduce_polyline: None,
                mesh_conversion: None,
                mesh_patch: None,
                mesh_from_lines: None,
                to_subd: None,
                to_nurbs: None,
            });
            self.command_input.clear();
            self.push_log(format!("> {input}"));
            self.log_object_prompt();
            return true;
        }
        let subcurve_measurement = matches!(description.command, "Domain" | "Length")
            && input.split_whitespace().nth(1).is_some_and(|option| {
                option
                    .trim_start_matches('_')
                    .eq_ignore_ascii_case("SubCrv")
            });
        let measurement_display_units = matches!(description.command, "Length" | "Area")
            .then(|| {
                input
                    .split_whitespace()
                    .skip(1)
                    .filter_map(|argument| argument.split_once('='))
                    .find(|(name, _)| name.trim_start_matches('_').eq_ignore_ascii_case("Units"))
                    .and_then(|(_, value)| viboceros_command::distance_display_units(value).ok())
                    .flatten()
            })
            .flatten();
        let sole_selected_cloud = (self.document.selected_object_count() == 1)
            .then(|| {
                self.document.selected_objects().next().and_then(|object| {
                    matches!(object.geometry(), Geometry::PointCloud(_)).then_some(object.id())
                })
            })
            .flatten();
        if description.filter == ObjectSelectionFilter::PointCloudSources
            && let Some(target) = sole_selected_cloud
        {
            self.cancel_interactive_command(false);
            self.object_prompt = Some(PendingObjectCommand {
                description,
                phase: ObjectPromptPhase::Options,
                postselected: false,
                subcurve_measurement: false,
                measurement_display_units: None,
                command_override: None,
                excluded_object: None,
                selection_before: None,
                cloud_removal: None,
                cloud_action_target: Some(target),
                special_selection: None,
                divide: None,
                modify_radius: None,
                reduce_polyline: None,
                mesh_conversion: None,
                mesh_patch: None,
                mesh_from_lines: None,
                to_subd: None,
                to_nurbs: None,
            });
            self.command_input.clear();
            self.push_log(format!("> {input}"));
            self.log_object_prompt();
            return true;
        }
        if description.filter == ObjectSelectionFilter::PointCloudAddSources {
            let Some(target) = self.point_cloud_prompt_target(input) else {
                return false;
            };
            if self
                .document
                .selected_objects()
                .any(|object| object.id() != target && description.filter.accepts_object(object))
            {
                return false;
            }
            let selection_before = self.document.selected_object_ids().collect();
            self.cancel_interactive_command(false);
            self.object_prompt = Some(PendingObjectCommand {
                description,
                phase: ObjectPromptPhase::Selecting,
                postselected: false,
                subcurve_measurement: false,
                measurement_display_units: None,
                command_override: Some(format!("PointCloud Add Target={target}")),
                excluded_object: Some(target),
                selection_before: Some(selection_before),
                cloud_removal: None,
                cloud_action_target: None,
                special_selection: None,
                divide: None,
                modify_radius: None,
                reduce_polyline: None,
                mesh_conversion: None,
                mesh_patch: None,
                mesh_from_lines: None,
                to_subd: None,
                to_nurbs: None,
            });
            self.command_input.clear();
            self.push_log(format!("> {input}"));
            self.log_object_prompt();
            return true;
        }
        if description.filter == ObjectSelectionFilter::PointCloudRemoveTarget {
            let Some(target) = self.point_cloud_prompt_target(input) else {
                return false;
            };
            let output_cloud = input
                .split_whitespace()
                .skip(2)
                .filter_map(|argument| argument.split_once('='))
                .find(|(name, _)| name.trim_start_matches('_').eq_ignore_ascii_case("Output"))
                .is_some_and(|(_, value)| value.eq_ignore_ascii_case("PointCloud"));
            self.cancel_interactive_command(false);
            self.object_prompt = Some(PendingObjectCommand {
                description,
                phase: ObjectPromptPhase::Selecting,
                postselected: false,
                subcurve_measurement: false,
                measurement_display_units: None,
                command_override: Some(format!(
                    "PointCloud Remove Target={target} Output={}",
                    if output_cloud { "PointCloud" } else { "Points" }
                )),
                excluded_object: None,
                selection_before: None,
                cloud_removal: Some(PendingCloudRemoval {
                    target,
                    indices: BTreeSet::new(),
                    output_cloud,
                }),
                cloud_action_target: None,
                special_selection: None,
                divide: None,
                modify_radius: None,
                reduce_polyline: None,
                mesh_conversion: None,
                mesh_patch: None,
                mesh_from_lines: None,
                to_subd: None,
                to_nurbs: None,
            });
            self.command_input.clear();
            self.push_log(format!("> {input}"));
            self.log_object_prompt();
            return true;
        }
        let required = match description.command {
            "RailRevolve" | "Sweep1" => {
                if words.iter().skip(1).any(|w| {
                    let name = w.split('=').next().unwrap().trim_start_matches(['_', '-']);
                    name.eq_ignore_ascii_case("RailName") || name.eq_ignore_ascii_case("RailId")
                }) {
                    1
                } else {
                    2
                }
            }
            "Circle FitPoints"
            | "SubDCylinder FitPoints"
            | "SubDCone FitPoints"
            | "SubDTruncatedCone FitPoints"
            | "SubDTorus FitPoints"
            | "SubDSphere FitPoints"
            | "PlaneThroughPt"
            | "Sphere FitPoints" => 3,
            "BooleanUnion" | "MeshBooleanUnion" | "MeshIntersect" | "PlanarUnion"
            | "TweenSurfaces" | "LineThroughPt" | "CrvDeviation" | "MergeSrf" => 2,
            _ => 1,
        };
        let graph_allowed = self.curvature_graph_selection_ids(description.command);
        let selected_objects = self
            .document
            .selected_objects()
            .filter(|o| description.filter.accepts_object(o))
            .filter(|o| {
                graph_allowed
                    .as_ref()
                    .is_none_or(|ids| ids.contains(&o.id()))
            })
            .take(required)
            .count();
        let selected_grips = if matches!(
            description.command,
            "Circle FitPoints"
                | "SubDCylinder FitPoints"
                | "SubDCone FitPoints"
                | "SubDTruncatedCone FitPoints"
                | "SubDTorus FitPoints"
                | "SubDSphere FitPoints"
                | "PlaneThroughPt"
                | "LineThroughPt"
                | "Sphere FitPoints"
                | "Smooth"
                | "HidePt"
                | "ExtractPt"
                | "Weight"
        ) {
            self.document
                .selected_control_points()
                .filter(|(p, _)| {
                    (description.command != "HidePt"
                        || self.document.is_control_point_selectable(*p))
                        && (description.command != "Weight"
                            || self.document.control_point_weight(*p).is_some())
                        && (description.command != "Smooth"
                            || self
                                .document
                                .object(p.object)
                                .is_some_and(|o| o.geometry().supports_smoothing()))
                })
                .take(required)
                .count()
        } else {
            0
        };
        let length_edges =
            description.command == "Length" && !subcurve_measurement && self.has_length_edges();
        let preselected = if let Some(kind) =
            viboceros_command::point_fitting::PointFitKind::from_command(description.command)
        {
            kind.selected_point_count(&self.document) >= kind.minimum_points()
        } else if description.command == "MergeSrf" {
            self.document
                .selected_objects()
                .filter(|o| description.filter.accepts_object(o))
                .count()
                == 2
        } else {
            selected_objects + selected_grips >= required || length_edges
        };
        if description.command == "Smooth"
            && preselected
            && words
                .last()
                .is_some_and(|v| v.trim_start_matches('_').eq_ignore_ascii_case("Enter"))
        {
            return false;
        }
        if preselected {
            if matches!(
                description.command,
                "QuadrangulateMesh" | "TriangulateNonPlanarQuads"
            ) && words.len() > 1
            {
                return false;
            }
            if description.command == "ReducePolyline"
                && viboceros_command::reduce_polyline::parse(&words[1..], Default::default())
                    .is_ok_and(|i| i.tolerance.is_some())
            {
                return false;
            }
            if description.command == "ModifyRadius"
                && viboceros_command::modify_radius::parse(&words[1..], Default::default())
                    .is_ok_and(|i| i.value.is_some())
            {
                return false;
            }
            if description.command == "Rebuild" && input.split_whitespace().nth(1).is_some() {
                return false;
            }
            if description.workflow == ObjectSelectionWorkflow::OptionsDuringSelection {
                return false;
            }
            // An explicit answer in a complete preselected invocation executes
            // directly. The bare command still asks its Yes/No question.
            if description.workflow.answers_immediately()
                && input.split_whitespace().nth(1).is_some()
            {
                return false;
            }
            match self
                .commands
                .object_selection_confirmation(&self.document, &description)
            {
                Ok(Some(description)) => {
                    if let Err(error) = self.commands.accept_object_selection_options(&description)
                    {
                        self.push_log(format!("Error: {error}"));
                        return true;
                    }
                    self.cancel_interactive_command(false);
                    self.object_prompt = Some(PendingObjectCommand {
                        description,
                        phase: ObjectPromptPhase::Options,
                        postselected: false,
                        subcurve_measurement,
                        measurement_display_units,
                        command_override: None,
                        excluded_object: None,
                        selection_before: None,
                        cloud_removal: None,
                        cloud_action_target: None,
                        special_selection: None,
                        divide: None,
                        modify_radius: None,
                        reduce_polyline: None,
                        mesh_conversion: None,
                        mesh_patch: None,
                        mesh_from_lines: None,
                        to_subd: None,
                        to_nurbs: None,
                    });
                }
                Ok(None) => return false,
                Err(error) => {
                    self.push_log(format!("Error: {error}"));
                    self.command_input = input.into();
                    return true;
                }
            }
        } else {
            self.cancel_interactive_command(false);
            if description.allows_selection_options()
                && let Err(error) = self.commands.accept_object_selection_options(&description)
            {
                self.push_log(format!("Error: {error}"));
                return true;
            }
            let selection_before = matches!(description.command, "Sweep1" | "Dir")
                .then(|| self.document.selected_object_ids().collect::<Vec<_>>());
            let rail_revolve_partial = matches!(description.command, "RailRevolve" | "Sweep1")
                .then(|| {
                    self.document
                        .selected_objects()
                        .filter(|o| description.filter.accepts_object(o))
                        .map(|o| o.id())
                        .collect::<Vec<_>>()
                });
            if matches!(description.command, "Sweep1" | "Dir") {
                let _ = self
                    .document
                    .set_transient_selection(rail_revolve_partial.unwrap_or_default());
            } else {
                self.document.clear_selection();
                if let Some(ids) = rail_revolve_partial {
                    let _ = self
                        .document
                        .select_objects_direct(ids, SelectionMode::Replace);
                }
            }
            let command_override = (matches!(
                description.command,
                "ModifyRadius"
                    | "Dir"
                    | "ShowDir"
                    | "DraftAngleAnalysis"
                    | "CurvatureAnalysis"
                    | "TweenSurfaces"
                    | "OffsetSrf"
                    | "Ribbon"
                    | "OffsetSubD"
                    | "Rebuild"
                    | "ShowEdges"
                    | "CurvatureGraph"
                    | "ZoomNaked"
                    | "ZoomNonManifold"
                    | "Divide"
                    | "ExtrudeCrvTapered"
                    | "ExtrudeSrf"
                    | "ExtrudeSrfAlongCrv"
                    | "ExtrudeSrfToPoint"
                    | "ExtrudeSrfTapered"
                    | "RailRevolve"
                    | "Sweep1"
                    | "Circle FitPoints"
                    | "SubDCylinder FitPoints"
                    | "SubDCone FitPoints"
                    | "SubDTruncatedCone FitPoints"
                    | "SubDTorus FitPoints"
                    | "SubDSphere FitPoints"
            ) || description.command == "ReducePointCloud"
                && input.split_whitespace().nth(1).is_some())
            .then(|| input.to_owned());
            self.object_prompt = Some(PendingObjectCommand {
                description,
                phase: ObjectPromptPhase::Selecting,
                postselected: true,
                subcurve_measurement,
                measurement_display_units,
                command_override,
                excluded_object: None,
                selection_before,
                cloud_removal: None,
                cloud_action_target: None,
                special_selection: None,
                divide: None,
                modify_radius: None,
                reduce_polyline: None,
                mesh_conversion: None,
                mesh_patch: None,
                mesh_from_lines: None,
                to_subd: None,
                to_nurbs: None,
            });
        }
        self.command_input.clear();
        self.initialize_smooth_options(input, preselected);
        self.initialize_merge_surface_options(input);
        self.initialize_rebuild_options();
        self.initialize_divide_prompt();
        self.initialize_modify_radius(input);
        self.initialize_reduce_polyline(input);
        self.initialize_mesh_conversion(input);
        self.initialize_weight_prompt(input);
        self.initialize_sweep_prompt(input);
        self.push_log(format!("> {input}"));
        self.log_object_prompt();
        true
    }

    pub(super) fn log_object_prompt(&mut self) {
        if let Some(pending) = &self.object_prompt {
            let command = pending
                .command_override
                .clone()
                .unwrap_or_else(|| pending.description.display_command_line());
            let mut message = format!("{}. {}", pending.hint(), command);
            let (choices, selected) = match pending.phase {
                ObjectPromptPhase::Menu(menu) => (&pending.description.menus[menu].choices, None),
                ObjectPromptPhase::MenuChoice { menu, choice } => {
                    (&pending.description.menus[menu].choices, Some(choice))
                }
                ObjectPromptPhase::Choice(choice) => (&pending.description.choices, Some(choice)),
                _ => (&pending.description.choices, None),
            };
            for (index, choice) in choices.iter().enumerate() {
                if pending.phase == ObjectPromptPhase::Selecting
                    || selected.is_some_and(|selected| selected != index)
                {
                    continue;
                }
                message.push_str(&format!("; {}: {}", choice.name, choice.choices.join("/")));
                if matches!(
                    pending.phase,
                    ObjectPromptPhase::Options | ObjectPromptPhase::Menu(_)
                ) && let Some(toggle) = &choice.toggle
                    && toggle.values.contains(&choice.value)
                {
                    message.push_str(&format!("; {}", toggle.name));
                }
            }
            self.push_log(message);
        }
    }

    pub(super) fn try_continue_object_prompt(&mut self, input: &str) -> bool {
        if self.continue_merge_surface_options(input) {
            return true;
        }
        if self.continue_length_choices(input)
            || self.continue_length_units(input)
            || self.start_length_chain(input)
        {
            return true;
        }
        if self.sweep_session.is_some() {
            return false;
        }
        if self.continue_mesh_conversion(input) {
            return true;
        }
        if self.continue_mesh_from_lines_prompt(input) {
            return true;
        }
        if self.continue_mesh_patch_prompt(input) {
            return true;
        }
        if self.promote_curve_extraction_subcurve(input) {
            return true;
        }
        if self.promote_curve_deviation_subcurve(input) {
            return true;
        }
        if self.try_select_prompt_points(input) {
            return true;
        }
        if self.continue_splop_fit_points(input) {
            return true;
        }
        if self
            .object_prompt
            .as_ref()
            .is_some_and(|pending| pending.description.command == "ExplodeBlock")
            && input
                .trim_start_matches('_')
                .eq_ignore_ascii_case("AllBlocks")
        {
            let pending = self.object_prompt.take().unwrap();
            let command = format!("{} AllBlocks", pending.description.command_line());
            self.command_input.clear();
            self.execute_command(&command);
            return true;
        }
        if self.continue_weight(input) {
            return true;
        }
        if self.continue_modify_radius(input) {
            return true;
        }
        if self.continue_reduce_polyline(input) {
            return true;
        }
        if self.continue_rebuild_options(input) {
            return true;
        }
        if self.continue_divide_prompt(input) {
            return true;
        }
        if self.continue_smooth_options(input) {
            return true;
        }
        if self.try_continue_transform_source_prompt(input) {
            return true;
        }
        if self.object_prompt.is_some()
            && input
                .trim_start_matches(['_', '-'])
                .eq_ignore_ascii_case("Cancel")
        {
            self.cancel_object_prompt(true);
            self.command_input.clear();
            return true;
        }
        let Some(mut pending) = self.object_prompt.clone() else {
            return false;
        };
        if let Some(ids) = pending.special_selection.as_mut() {
            let normalized = input.trim_start_matches(['_', '-']);
            if input.is_empty() {
                if ids.is_empty() {
                    self.push_log("Select at least one eligible object; Esc cancels".into());
                    return true;
                }
                let command = format!(
                    "{} Ids={}",
                    pending.description.command,
                    ids.iter()
                        .map(ToString::to_string)
                        .collect::<Vec<_>>()
                        .join(",")
                );
                match self.commands.execute(&mut self.document, &command) {
                    Ok(message) => {
                        self.object_prompt = None;
                        self.push_log(format!("> {command}"));
                        self.push_log(message);
                    }
                    Err(error) => self.push_log(format!("Error: {error}")),
                }
                self.command_input.clear();
                return true;
            }
            if normalized.eq_ignore_ascii_case("SelNone") {
                ids.clear();
                self.object_prompt = Some(pending);
                self.command_input.clear();
                return true;
            }
            if normalized.eq_ignore_ascii_case("SelAll") {
                let filter = pending.description.filter;
                let all = self
                    .document
                    .objects()
                    .filter(|object| filter.accepts_object(object))
                    .filter(|object| {
                        self.document
                            .layer(object.attributes().layer_id())
                            .is_some_and(|layer| layer.is_visible() && !layer.is_locked())
                    })
                    .map(|object| object.id())
                    .collect::<Vec<_>>();
                self.object_prompt = Some(pending);
                self.select_prompt_objects(all, SelectionMode::Add);
                self.command_input.clear();
                return true;
            }
            if input
                .split_whitespace()
                .next()
                .is_some_and(|name| self.commands.recognizes(name))
            {
                self.cancel_object_prompt(true);
                return false;
            }
            self.push_log("Select objects; Enter finishes, Esc cancels".into());
            self.command_input.clear();
            return true;
        }
        if let Some(target) = pending.cloud_action_target {
            return self.continue_cloud_action(input, target);
        }
        if pending.cloud_removal.is_some() {
            return self.continue_cloud_removal(input, pending);
        }
        if input.is_empty() {
            if self.finish_extract_point_components() {
                return true;
            }
            if self.finish_nurbs_edges() {
                return true;
            }
            if self.finish_to_subd() {
                return true;
            }
            if self.finish_subdivide(pending.postselected) {
                return true;
            }
            if self.finish_shrink_faces(pending.postselected) {
                return true;
            }
            if let ObjectPromptPhase::MenuChoice { menu, .. } = pending.phase {
                pending.phase = ObjectPromptPhase::Menu(menu);
                self.object_prompt = Some(pending);
                self.log_object_prompt();
                self.command_input.clear();
                return true;
            }
            if matches!(
                pending.phase,
                ObjectPromptPhase::Menu(_) | ObjectPromptPhase::Choice(_)
            ) {
                pending.phase = if pending.description.allows_selection_options() {
                    ObjectPromptPhase::Selecting
                } else {
                    ObjectPromptPhase::Options
                };
                self.object_prompt = Some(pending);
                self.log_object_prompt();
                self.command_input.clear();
                return true;
            }
            if pending.phase == ObjectPromptPhase::Selecting {
                if matches!(
                    pending.description.command,
                    "BooleanUnion" | "MeshBooleanUnion" | "MeshIntersect"
                ) && self
                    .document
                    .selected_objects()
                    .filter(|o| pending.description.filter.accepts_object(o))
                    .count()
                    == 1
                {
                    self.push_log(
                        if matches!(
                            pending.description.command,
                            "MeshBooleanUnion" | "MeshIntersect"
                        ) {
                            "Select at least two meshes, surfaces or polysurfaces; Esc cancels"
                                .into()
                        } else {
                            "Select at least two surfaces or polysurfaces; Esc cancels".into()
                        },
                    );
                    return true;
                }
                let graph_allowed = self.curvature_graph_selection_ids(pending.description.command);
                let has_eligible_picks = (pending.description.command == "Length"
                    && !pending.subcurve_measurement
                    && self.has_length_edges())
                    || self.document.selected_objects().any(|o| {
                        Some(o.id()) != pending.excluded_object
                            && pending.description.filter.accepts_object(o)
                            && graph_allowed
                                .as_ref()
                                .is_none_or(|ids| ids.contains(&o.id()))
                    })
                    || (matches!(
                        pending.description.command,
                        "Circle FitPoints"
                            | "SubDCylinder FitPoints"
                            | "SubDCone FitPoints"
                            | "SubDTruncatedCone FitPoints"
                            | "SubDTorus FitPoints"
                            | "SubDSphere FitPoints"
                            | "PlaneThroughPt"
                            | "LineThroughPt"
                            | "Sphere FitPoints"
                            | "Smooth"
                            | "HidePt"
                            | "ExtractPt"
                            | "Weight"
                    ) && self.document.selected_control_points().any(|(g, _)| {
                        pending.description.command != "HidePt"
                            || self.document.is_control_point_selectable(g)
                    }));
                if !has_eligible_picks {
                    if self
                        .commands
                        .cancel_empty_object_selection(&pending.description)
                    {
                        self.cancel_object_prompt(true);
                        return true;
                    }
                    self.push_log("Select at least one eligible object; Esc cancels".into());
                    return true;
                }
                if !pending.description.workflow.options_during_selection() {
                    match self
                        .commands
                        .object_selection_confirmation(&self.document, &pending.description)
                    {
                        Ok(Some(description)) => {
                            if description.command == "Rebuild"
                                && pending
                                    .command_override
                                    .as_ref()
                                    .is_some_and(|s| s.split_whitespace().nth(1).is_some())
                            {
                                // Complete inline scripts accept directly after picking.
                            } else {
                                if let Err(error) =
                                    self.commands.accept_object_selection_options(&description)
                                {
                                    self.push_log(format!("Error: {error}"));
                                    return true;
                                }
                                pending.description = description;
                                pending.phase = ObjectPromptPhase::Options;
                                self.object_prompt = Some(pending);
                                self.initialize_rebuild_options();
                                self.initialize_divide_prompt();
                                self.command_input.clear();
                                self.log_object_prompt();
                                return true;
                            }
                        }
                        Ok(None) => {} // No-op selection finishes without accepting choices.
                        Err(error) => {
                            self.push_log(format!("Error: {error}"));
                            return true;
                        }
                    }
                }
            }
            if pending.description.command == "ReducePointCloud"
                && pending.phase == ObjectPromptPhase::Options
                && pending.command_override.is_none()
            {
                self.push_log("Enter number to remove or Percent=n".into());
                return true;
            }
            if pending.description.command == "SubDTorus FitPoints" {
                self.accept_subd_torus_fit(pending.postselected);
                self.command_input.clear();
                return true;
            }
            if pending.description.command == "SubDSphere FitPoints" {
                self.accept_subd_sphere_fit(pending.postselected);
                self.command_input.clear();
                return true;
            }
            if matches!(
                pending.description.command,
                "SubDCylinder FitPoints" | "SubDCone FitPoints" | "SubDTruncatedCone FitPoints"
            ) {
                self.accept_subd_axial_fit(pending.postselected);
                self.command_input.clear();
                return true;
            }
            let mut command = pending
                .command_override
                .clone()
                .unwrap_or_else(|| pending.description.command_line());
            if pending.subcurve_measurement {
                command.push_str(" SubCrv");
            }
            if let Some(units) = pending.measurement_display_units {
                command.push_str(&format!(" Units={units}"));
            }
            if pending.description.command == "Dir" && command.split_whitespace().count() == 1 {
                self.object_prompt = None;
                self.begin_direction(pending.postselected);
                return true;
            }
            if pending.description.command == "RailRevolve" {
                command = match self.rail_revolve_selection_input(&command, &pending.description) {
                    Ok(command) => command,
                    Err(error) => {
                        self.push_log(format!("Error: {error}"));
                        return true;
                    }
                };
            }
            if pending.subcurve_measurement && self.domain_has_one_curve() {
                self.object_prompt = None;
                self.try_start_interactive_command(&command);
                return true;
            }
            if pending.description.command == "OffsetSrf" {
                self.object_prompt = None;
                if self.start_offset_surface(&command, pending.postselected) {
                    return true;
                }
                self.object_prompt = Some(pending.clone());
            }
            if pending.description.command == "OffsetSubD" {
                self.object_prompt = None;
                if self.start_offset_subd(&command, pending.postselected) {
                    return true;
                }
                self.object_prompt = Some(pending.clone());
            }
            if matches!(
                pending.description.command,
                "Section"
                    | "Contour"
                    | "ExtrudeCrvTapered"
                    | "ExtrudeSrf"
                    | "ExtrudeSrfAlongCrv"
                    | "ExtrudeSrfToPoint"
                    | "ExtrudeSrfTapered"
                    | "RailRevolve"
            ) {
                // Accept the picked sources before starting a point getter;
                // cancellation otherwise restores the pre-prompt selection.
                self.object_prompt = None;
                if self.try_start_interactive_command(&command) {
                    return true;
                }
                self.object_prompt = Some(pending.clone());
            }
            if pending.description.command == "Align" {
                self.object_prompt = None;
                if self.try_start_interactive_command(&command) {
                    if let Some(InteractiveCommand::Align { postselected, .. }) =
                        &mut self.active_command
                    {
                        *postselected = pending.postselected;
                    }
                    return true;
                }
                // No-point modes execute directly after selection acceptance.
            }
            if pending.description.command == "EvaluateUVPt" && self.evaluate_uv_can_pick() {
                self.object_prompt = None;
                self.try_start_interactive_command(&command);
                return true;
            }
            if command == "Domain" && self.domain_needs_face_pick() {
                // This is acceptance, not cancellation: retain the picked
                // object while handing control to the component-point phase.
                self.object_prompt = None;
                self.try_start_interactive_command(&command);
                return true;
            }
            let command = match self.silhouette_input(&command) {
                Ok(command) => command,
                Err(error) => {
                    self.push_log(format!("Error: {error}"));
                    return true;
                }
            };
            self.push_log(format!("> {command}"));
            let context = viboceros_command::CommandContext {
                construction_plane: self.viewports[self.active_viewport].construction_plane(),
            };
            let result =
                if let Some(projection) = self.viewports[self.active_viewport].pick_projection() {
                    self.commands.execute_with_pick_projection(
                        &mut self.document,
                        &command,
                        context,
                        pending.postselected,
                        projection,
                    )
                } else if pending.postselected {
                    self.commands
                        .execute_postselected(&mut self.document, &command, context)
                } else {
                    self.commands
                        .execute_in_context(&mut self.document, &command, context)
                };
            match result {
                Ok(message) => {
                    self.object_prompt = None;
                    self.push_log(message);
                    self.start_edge_zoom_options(&command);
                }
                Err(error) => {
                    if matches!(
                        pending.description.command,
                        "BooleanUnion"
                            | "MeshBooleanUnion"
                            | "MeshIntersect"
                            | "MeshSelfIntersect"
                            | "MergeSrf"
                    ) || (pending.description.command == "PlanarMesh"
                        && matches!(
                            error,
                            viboceros_command::CommandError::NoPlanarSurfaceBoundaries
                        ))
                        || (matches!(pending.description.command, "Join" | "JoinCopy")
                            && matches!(error, viboceros_command::CommandError::NothingJoined)
                            && self
                                .document
                                .selected_objects()
                                .all(|o| matches!(o.geometry(), Geometry::SubD(_))))
                    {
                        self.object_prompt = None;
                    }
                    if matches!(error, viboceros_command::CommandError::OperationDeclined) {
                        self.object_prompt = None;
                        self.push_log(format!("{} declined", pending.description.command));
                    } else {
                        if pending.description.command == "ReducePointCloud" {
                            pending.command_override = None;
                            self.object_prompt = Some(pending);
                        }
                        self.push_log(format!("Error: {error}"));
                    }
                }
            }
            self.command_input.clear();
            return true;
        }
        if pending.description.command == "ReducePointCloud"
            && pending.phase == ObjectPromptPhase::Options
        {
            let amount = input.trim_start_matches('_');
            let option = amount.split_once('=').is_some_and(|(name, _)| {
                name.eq_ignore_ascii_case("Percent") || name.eq_ignore_ascii_case("Count")
            });
            if amount.parse::<usize>().is_ok() || option {
                pending.command_override = Some(format!("ReducePointCloud {amount}"));
                self.object_prompt = Some(pending);
                self.command_input.clear();
                return self.try_continue_object_prompt("");
            }
        }
        let normalized = input.trim_start_matches(['_', '-']).to_ascii_lowercase();
        if matches!(pending.description.command, "Length" | "Area")
            && pending.phase == ObjectPromptPhase::Selecting
            && let Some((name, value)) = normalized.split_once('=')
            && name.eq_ignore_ascii_case("units")
        {
            match viboceros_command::distance_display_units(value) {
                Ok(units) => {
                    let name = pending.description.command;
                    pending.measurement_display_units = units;
                    self.object_prompt = Some(pending);
                    self.push_log(format!(
                        "{} display units: {}",
                        name,
                        units.unwrap_or("Model_Units")
                    ));
                }
                Err(error) => self.push_log(format!("Error: {error}")),
            }
            self.command_input.clear();
            return true;
        }
        if normalized == "selall" || normalized == "selnone" {
            if pending.phase != ObjectPromptPhase::Selecting {
                self.push_log("Selection is fixed; finish or cancel the command".into());
                return true;
            }
            if normalized == "selnone" {
                self.document.clear_selection();
                if self.shrink_prompt_mode().is_some()
                    || self.picking_subdivide()
                    || self.picking_nurbs_edges()
                    || pending.description.command == "Length"
                {
                    self.component_selection.clear();
                }
                self.record_nurbs_targets();
            } else {
                let ids = self
                    .document
                    .selectable_objects()
                    .filter(|o| {
                        Some(o.id()) != pending.excluded_object
                            && pending.description.filter.accepts_object(o)
                    })
                    .map(|o| o.id())
                    .collect::<Vec<_>>();
                self.select_prompt_objects(ids, SelectionMode::Add);
                if matches!(
                    pending.description.command,
                    "Circle FitPoints"
                        | "SubDCylinder FitPoints"
                        | "SubDCone FitPoints"
                        | "SubDTruncatedCone FitPoints"
                        | "SubDTorus FitPoints"
                        | "SubDSphere FitPoints"
                        | "PlaneThroughPt"
                        | "LineThroughPt"
                        | "Sphere FitPoints"
                        | "HidePt"
                        | "ExtractPt"
                        | "Weight"
                ) {
                    self.document.select_all_control_points();
                }
            }
            self.command_input.clear();
            return true;
        }
        // Active option names take precedence over global command aliases
        // (notably Direction, which is also an alias of Dir).
        let option_name = normalized
            .split_whitespace()
            .next()
            .unwrap_or("")
            .split('=')
            .next()
            .unwrap_or("");
        let local_choice = pending
            .description
            .choices
            .iter()
            .chain(pending.description.menus.iter().flat_map(|m| &m.choices))
            .any(|c| {
                c.name.eq_ignore_ascii_case(option_name)
                    || c.toggle
                        .as_ref()
                        .is_some_and(|t| t.name.eq_ignore_ascii_case(option_name))
            });
        let value_choices = match pending.phase {
            ObjectPromptPhase::Choice(index) => Some(&pending.description.choices[index]),
            ObjectPromptPhase::MenuChoice { menu, choice } => {
                Some(&pending.description.menus[menu].choices[choice])
            }
            _ => None,
        };
        let local_value = value_choices.is_some_and(|c| {
            c.choices
                .iter()
                .any(|v| v.eq_ignore_ascii_case(&normalized))
        });
        if !local_choice
            && !local_value
            && input
                .split_whitespace()
                .next()
                .is_some_and(|name| self.commands.recognizes(name))
        {
            self.cancel_object_prompt(true);
            return false;
        }
        if pending.phase == ObjectPromptPhase::Selecting
            && !pending.description.allows_selection_options()
        {
            self.push_log("Select objects first; Enter continues".into());
            return true;
        }
        if (pending.phase == ObjectPromptPhase::Options
            || (pending.phase == ObjectPromptPhase::Selecting
                && pending.description.allows_selection_options()))
            && let Some(index) = pending
                .description
                .choices
                .iter()
                .position(|choice| choice.name.eq_ignore_ascii_case(&normalized))
        {
            pending.phase = ObjectPromptPhase::Choice(index);
            self.object_prompt = Some(pending);
            self.command_input.clear();
            self.log_object_prompt();
            return true;
        }
        if pending.phase == ObjectPromptPhase::Options
            && let Some(index) = pending
                .description
                .menus
                .iter()
                .position(|menu| menu.name.eq_ignore_ascii_case(&normalized))
        {
            pending.phase = ObjectPromptPhase::Menu(index);
            self.object_prompt = Some(pending);
            self.command_input.clear();
            self.log_object_prompt();
            return true;
        }
        if let ObjectPromptPhase::Menu(menu) = pending.phase
            && let Some(choice) = pending.description.menus[menu]
                .choices
                .iter()
                .position(|choice| choice.name.eq_ignore_ascii_case(&normalized))
        {
            pending.phase = ObjectPromptPhase::MenuChoice { menu, choice };
            self.object_prompt = Some(pending);
            self.command_input.clear();
            self.log_object_prompt();
            return true;
        }
        let update = if pending.description.command == "Align" {
            self.update_align_selection(&pending.description, input)
                .map(|description| pending.description = description)
        } else {
            match pending.phase {
                ObjectPromptPhase::Menu(index) => {
                    pending.description.update_menu_options(index, input)
                }
                ObjectPromptPhase::Choice(index) => pending.description.choices[index].set(input),
                ObjectPromptPhase::MenuChoice { menu, choice } => {
                    pending.description.menus[menu].choices[choice].set(input)
                }
                _ => self
                    .commands
                    .update_object_selection_options(&mut pending.description, input),
            }
        };
        match update.and_then(|()| {
            self.commands
                .accept_object_selection_options(&pending.description)
        }) {
            Ok(()) => {
                if let ObjectPromptPhase::MenuChoice { menu, .. } = pending.phase {
                    pending.phase = ObjectPromptPhase::Menu(menu);
                } else if matches!(pending.phase, ObjectPromptPhase::Choice(_)) {
                    pending.phase = if pending.description.allows_selection_options() {
                        ObjectPromptPhase::Selecting
                    } else {
                        ObjectPromptPhase::Options
                    };
                }
                let answered = pending.phase == ObjectPromptPhase::Options
                    && pending.description.workflow.answers_immediately();
                self.object_prompt = Some(pending);
                self.command_input.clear();
                if answered {
                    return self.try_continue_object_prompt("");
                }
                self.log_object_prompt();
            }
            Err(error) => self.push_log(format!("Error: {error}")),
        }
        true
    }

    fn continue_cloud_action(&mut self, input: &str, target: ObjectId) -> bool {
        let action = input.trim_start_matches(['_', '-']);
        if action.eq_ignore_ascii_case("Add") || action.eq_ignore_ascii_case("Remove") {
            self.object_prompt = None;
            let command = format!("PointCloud {action} Target={target}");
            if !self.try_start_object_prompt(&command) {
                self.push_log("Error: the selected point cloud is no longer available".into());
            }
            self.command_input.clear();
            return true;
        }
        if input
            .split_whitespace()
            .next()
            .is_some_and(|name| self.commands.recognizes(name))
        {
            self.cancel_object_prompt(true);
            return false;
        }
        self.push_log("Type Add or Remove; Esc cancels".into());
        self.command_input.clear();
        true
    }

    fn continue_cloud_removal(&mut self, input: &str, mut pending: PendingObjectCommand) -> bool {
        let removal = pending.cloud_removal.as_mut().unwrap();
        if input.is_empty() {
            if removal.indices.is_empty() {
                self.push_log("Pick at least one cloud point; Esc cancels".into());
                return true;
            }
            let indices = removal
                .indices
                .iter()
                .map(usize::to_string)
                .collect::<Vec<_>>()
                .join(",");
            let command = format!(
                "{} Indices={indices}",
                pending.command_override.as_deref().unwrap()
            );
            let context = viboceros_command::CommandContext {
                construction_plane: self.viewports[self.active_viewport].construction_plane(),
            };
            self.push_log(format!("> {command}"));
            let result =
                if let Some(projection) = self.viewports[self.active_viewport].pick_projection() {
                    self.commands.execute_with_pick_projection(
                        &mut self.document,
                        &command,
                        context,
                        false,
                        projection,
                    )
                } else {
                    self.commands
                        .execute_in_context(&mut self.document, &command, context)
                };
            match result {
                Ok(message) => {
                    self.object_prompt = None;
                    self.push_log(message);
                }
                Err(error) => self.push_log(format!("Error: {error}")),
            }
            self.command_input.clear();
            return true;
        }
        let normalized = input.trim_start_matches(['_', '-']);
        if normalized.eq_ignore_ascii_case("SelAll") || normalized.eq_ignore_ascii_case("SelNone") {
            if normalized.eq_ignore_ascii_case("SelNone") {
                removal.indices.clear();
            } else if let Some(object) = self.document.object(removal.target)
                && let Geometry::PointCloud(cloud) = object.geometry()
            {
                removal.indices = (0..cloud.points().len()).collect();
            }
        } else if let Some((name, value)) = normalized.split_once('=')
            && name.eq_ignore_ascii_case("Output")
        {
            removal.output_cloud = if value.eq_ignore_ascii_case("PointCloud") {
                true
            } else if value.eq_ignore_ascii_case("Points") {
                false
            } else {
                self.push_log("Output must be Points or PointCloud".into());
                return true;
            };
            pending.command_override = Some(format!(
                "PointCloud Remove Target={} Output={}",
                removal.target,
                if removal.output_cloud {
                    "PointCloud"
                } else {
                    "Points"
                }
            ));
        } else if input
            .split_whitespace()
            .next()
            .is_some_and(|name| self.commands.recognizes(name))
        {
            self.cancel_object_prompt(true);
            return false;
        } else {
            self.push_log(
                "Pick cloud points or type Output=Points|PointCloud, SelAll, or SelNone".into(),
            );
            return true;
        }
        let count = removal.indices.len();
        self.push_log(format!("{count} cloud point(s) selected"));
        self.object_prompt = Some(pending);
        self.command_input.clear();
        true
    }

    pub(super) fn select_cloud_points(&mut self, indices: &[usize], mode: SelectionMode) {
        let Some(pending) = self.object_prompt.as_mut() else {
            return;
        };
        let Some(removal) = pending.cloud_removal.as_mut() else {
            return;
        };
        match mode {
            SelectionMode::Replace | SelectionMode::Add => {
                removal.indices.extend(indices.iter().copied());
            }
            SelectionMode::Remove => {
                for index in indices {
                    removal.indices.remove(index);
                }
            }
            SelectionMode::Toggle => {
                for index in indices {
                    if !removal.indices.insert(*index) {
                        removal.indices.remove(index);
                    }
                }
            }
        }
        let count = removal.indices.len();
        self.push_log(format!("{count} cloud point(s) selected"));
    }

    pub(super) fn cancel_object_prompt(&mut self, announce: bool) {
        self.length_choices = None;
        self.length_units_pending = false;
        self.clear_sweep_input();
        self.rebuild_preview = None;
        self.weight_prompt = None;
        if let Some(pending) = self.object_prompt.take() {
            if matches!(
                pending.description.command,
                "QuadrangulateMesh" | "TriangulateNonPlanarQuads"
            ) {
                self.document.clear_selection();
            }
            if pending.description.command == "SubDTorus FitPoints" {
                self.subd_torus_session = None;
                self.active_command = None;
                self.drafting_plane = None;
            }
            if pending.description.command == "SubDSphere FitPoints" {
                self.subd_sphere_session = None;
                self.active_command = None;
                self.drafting_plane = None;
            }

            if matches!(
                pending.description.command,
                "SubDCylinder FitPoints" | "SubDCone FitPoints" | "SubDTruncatedCone FitPoints"
            ) {
                self.subd_axial_session = None;
                self.active_command = None;
                self.drafting_plane = None;
            }
            if matches!(
                pending.description.command,
                "ShrinkTrimmedSrf"
                    | "ShrinkTrimmedSrfToEdge"
                    | "SubDivide"
                    | "ToSubD"
                    | "ToNURBS"
                    | "ExtractControlPolygon"
                    | "ExtractPt"
            ) {
                self.component_selection.clear();
            }
            if pending.description.command == "Length" && pending.postselected {
                self.component_selection.clear();
            }
            if let Some(selection_before) = pending.selection_before {
                if matches!(pending.description.command, "Sweep1" | "Dir") {
                    self.restore_curve_selection(selection_before);
                } else if let Err(error) = self
                    .document
                    .select_objects_direct(selection_before, SelectionMode::Replace)
                {
                    self.push_log(format!("Error restoring selection: {error}"));
                }
            } else if pending.postselected {
                self.document.clear_selection();
            }
            self.command_input.clear();
            if announce {
                self.push_log(format!("Cancelled {}", pending.description.command));
            }
        }
    }

    /// Keyboard Escape at an explicit warning may mean a default answer, unlike
    /// replacing a command, cancelling selection, or closing a document.
    pub(super) fn answer_object_prompt_escape(&mut self) -> bool {
        let Some(pending) = &self.object_prompt else {
            return false;
        };
        if pending.phase != ObjectPromptPhase::Options {
            return false;
        }
        let ObjectSelectionWorkflow::QuestionAfterSelection {
            escape_answer: Some(answer),
            ..
        } = pending.description.workflow
        else {
            return false;
        };
        self.try_continue_object_prompt(if answer { "Yes" } else { "No" })
    }

    pub(super) fn select_prompt_objects(
        &mut self,
        ids: impl IntoIterator<Item = ObjectId>,
        mode: SelectionMode,
    ) {
        if self.sweep_session.is_some() {
            self.select_sweep_objects(ids, mode);
            return;
        }
        if self.curve_boolean_prompt.is_some() {
            self.select_curve_boolean_sources(ids, mode);
            return;
        }
        let Some(filter) = self
            .object_prompt
            .as_ref()
            .and_then(PendingObjectCommand::selection_filter)
        else {
            return;
        };
        if self
            .object_prompt
            .as_ref()
            .is_some_and(|prompt| prompt.special_selection.is_some())
        {
            let requested = ids.into_iter().collect::<BTreeSet<_>>();
            let eligible = self
                .document
                .objects()
                .filter(|object| requested.contains(&object.id()) && filter.accepts_object(object))
                .filter(|object| {
                    self.document
                        .layer(object.attributes().layer_id())
                        .is_some_and(|layer| layer.is_visible() && !layer.is_locked())
                })
                .map(|object| object.id())
                .collect::<Vec<_>>();
            let pending = self.object_prompt.as_mut().unwrap();
            let selected = pending.special_selection.as_mut().unwrap();
            match mode {
                SelectionMode::Replace | SelectionMode::Add => selected.extend(eligible),
                SelectionMode::Remove => {
                    for id in eligible {
                        selected.remove(&id);
                    }
                }
                SelectionMode::Toggle => {
                    for id in eligible {
                        if !selected.insert(id) {
                            selected.remove(&id);
                        }
                    }
                }
            }
            let count = selected.len();
            self.push_log(format!("Selected {count} object(s); Enter continues"));
            return;
        }
        let excluded = self
            .object_prompt
            .as_ref()
            .and_then(|prompt| prompt.excluded_object);
        let requested = ids.into_iter().collect::<std::collections::BTreeSet<_>>();
        let allowed = self
            .object_prompt
            .as_ref()
            .and_then(|p| self.curvature_graph_selection_ids(p.description.command));
        let ids = self
            .document
            .selectable_objects()
            .filter(|object| requested.contains(&object.id()))
            .filter(|object| Some(object.id()) != excluded)
            .filter(|object| filter.accepts_object(object))
            .filter(|object| {
                allowed
                    .as_ref()
                    .is_none_or(|ids| ids.contains(&object.id()))
            })
            .map(|object| object.id())
            .collect::<Vec<_>>();
        let mode = if mode == SelectionMode::Replace {
            SelectionMode::Add
        } else {
            mode
        };
        let result = if self
            .object_prompt
            .as_ref()
            .is_some_and(|prompt| prompt.description.command == "Dir")
        {
            // Dir picks are provisional: Escape must preserve SelPrev and Redo
            // as well as the prior selection. Retain click order without group
            // expansion or quadratic per-object searches.
            let previous = self.document.selected_object_ids().collect::<Vec<_>>();
            let previous_set = previous.iter().copied().collect::<BTreeSet<_>>();
            let mut next = previous_set.clone();
            for &id in &ids {
                match mode {
                    SelectionMode::Add | SelectionMode::Replace => {
                        next.insert(id);
                    }
                    SelectionMode::Remove => {
                        next.remove(&id);
                    }
                    SelectionMode::Toggle => {
                        if !next.remove(&id) {
                            next.insert(id);
                        }
                    }
                }
            }
            let ordered = previous
                .into_iter()
                .filter(|id| next.contains(id))
                .chain(
                    ids.into_iter()
                        .filter(|id| next.contains(id) && !previous_set.contains(id)),
                )
                .collect::<Vec<_>>();
            self.document
                .set_transient_selection(ordered)
                .map(|_| self.document.selected_object_count())
        } else if self.object_prompt.as_ref().is_some_and(|prompt| {
            prompt.description.workflow == ObjectSelectionWorkflow::PointInputAfterSelection
        }) {
            self.document.select_objects(ids, mode)
        } else {
            self.document.select_objects_direct(ids, mode)
        };
        match result {
            Ok(count) => self.push_log(format!("Selected {count} object(s); Enter continues")),
            Err(error) => self.push_log(format!("Error: {error}")),
        }
        if self.picking_nurbs_edges() {
            let whole = self.document.selected_object_ids().collect::<Vec<_>>();
            self.component_selection.release_objects(&whole);
            self.record_nurbs_targets();
        }
        if let Some(pending) = &self.object_prompt {
            match self
                .commands
                .object_selection_complete(&self.document, &pending.description)
            {
                Ok(true) => {
                    self.try_continue_object_prompt("");
                }
                Ok(false) => {}
                Err(error) => self.push_log(format!("Error: {error}")),
            }
        }
    }
}
