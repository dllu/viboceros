//! Command editing, completion, and recall, independent of modeling state.
use super::*;
mod completion;
mod history;
#[cfg(test)]
pub(super) use completion::command_completions;

#[derive(Default)]
pub(super) struct CommandLineState {
    history: history::History,
    completion: completion::CompletionState,
    completion_cursor: Option<usize>,
}

impl CommandLineState {
    pub fn load() -> (Self, Option<String>) {
        let (history, error) = history::History::load(history::default_path());
        (
            Self {
                history,
                ..Self::default()
            },
            error,
        )
    }

    pub fn remember(&mut self, input: &str) -> Option<String> {
        self.completion.reset();
        self.history.remember(input).err().map(|error| {
            format!(
                "Command history could not be saved; recall remains available this session: {error}"
            )
        })
    }
}

impl VibocerosApp {
    pub(super) fn command_line_idle(&self) -> bool {
        !self.command_file_prompt
            && self.layer_prompt.is_none()
            && self.direction_session.is_none()
            && self.end_analysis_pick.is_none()
            && self.zoom_factor_pending.is_none()
            && self.snap_size_pending.is_none()
            && self.active_command.is_none()
            && self.surface_path_prompt.is_none()
            && self.shell_prompt.is_none()
            && self.merge_face_prompt.is_none()
            && self.boolean_two_prompt.is_none()
            && self.planar_boolean_prompt.is_none()
            && self.loft_prompt.is_none()
            && self.tween_surfaces_prompt.is_none()
            && self.blend_surface_prompt.is_none()
            && self.fillet_surface_prompt.is_none()
            && self.curve_boolean_prompt.is_none()
            && self.refinement_prompt.is_none()
            && self.select_uv_prompt.is_none()
            && self.edge_pattern_prompt.is_none()
            && self.chain_prompt.is_none()
            && self.reparameterize_prompt.is_none()
            && self.object_prompt.is_none()
            && self.group_prompt.is_none()
            && self.intersection_prompt.is_none()
            && self.edge_prompt.is_none()
            && self.hole_prompt.is_none()
            && self.unjoin_prompt.is_none()
            && self.edge_fillet_prompt.is_none()
            && self.crease_prompt.is_none()
            && self.soft_crease_prompt.is_none()
            && self.plane_prompt.is_none()
            && self.set_view_prompt.is_none()
            && !self.use_extrusions_prompt
            && !self.remember_copy_prompt
            && self.edge_zoom_prompt.is_none()
            && !self.component_selection.has_choices()
    }

    pub(super) fn remember_command_input(&mut self, input: &str) {
        if self.executing_command_file || self.command_file_prompt {
            return;
        }
        if input.is_empty() {
            return;
        }
        if self.set_view_options_active()
            && self
                .set_view_prompt
                .as_ref()
                .unwrap()
                .prompt
                .answer(input)
                .is_ok()
        {
            return;
        }
        let name = input.split_whitespace().next().unwrap_or("");
        let command_name = name.trim_start_matches(['\'', '_', '-']);
        if self.length_units_pending
            || (self.length_chain_available() && command_name.eq_ignore_ascii_case("Units"))
        {
            return;
        }
        if self.chain_prompt.is_some() && command_name.eq_ignore_ascii_case("Undo") {
            return;
        }
        let explicit_command = self.commands.recognizes(command_name)
            || command_name.eq_ignore_ascii_case("CPlane")
            || command_name.eq_ignore_ascii_case("CopyCPlaneToAll")
            || command_name.eq_ignore_ascii_case("CopyCPlaneSettingsToAll")
            || command_name.eq_ignore_ascii_case("SynchronizeCPlanes")
            || command_name.eq_ignore_ascii_case("NamedView")
            || command_name.eq_ignore_ascii_case("NamedCPlane")
            || command_name.eq_ignore_ascii_case("ReadViewportsFromFile")
            || command_name.eq_ignore_ascii_case("SetActiveViewport")
            || command_name.eq_ignore_ascii_case("SetMaximizedViewport")
            || command_name.eq_ignore_ascii_case("ViewportProperties")
            || viboceros_command::interface::COMMAND_NAMES
                .iter()
                .any(|n| n.eq_ignore_ascii_case(command_name));
        if (self.command_line_idle() || explicit_command)
            && let Some(error) = self.command_line.remember(input)
        {
            self.push_log(error);
        }
    }

    pub(super) fn capture_global_command_typing(&mut self, root: &mut egui::Ui) {
        if root.ctx().text_edit_focused()
            || root.input(|input| input.modifiers.command || input.modifiers.alt)
        {
            return;
        }
        if self.command_line_idle() {
            let older = root.input_mut(|input| {
                consume_exact_key(input, egui::Modifiers::NONE, egui::Key::ArrowUp)
            });
            let newer = root.input_mut(|input| {
                consume_exact_key(input, egui::Modifiers::NONE, egui::Key::ArrowDown)
            });
            if (older || newer)
                && let Some(text) = self
                    .command_line
                    .history
                    .navigate(&self.command_input, older)
            {
                self.command_input = text;
                self.command_line.completion.reset();
                self.command_focus_requested = true;
            }
        }
        let typed = root.input_mut(|input| {
            let mut typed = String::new();
            input.events.retain(|event| {
                if let egui::Event::Text(text) = event
                    && text.chars().any(|character| !character.is_control())
                {
                    typed.push_str(text);
                    false
                } else {
                    true
                }
            });
            typed
        });
        if !typed.is_empty() {
            self.queue_command_text(&typed);
        }
    }

    fn queue_command_text(&mut self, typed: &str) {
        self.command_input.push_str(typed);
        self.command_line.completion.reset();
        self.command_focus_requested = true;
    }

    pub(super) fn show_command_line(&mut self, root: &mut egui::Ui) {
        egui::Panel::bottom("command_line")
            .resizable(true)
            .default_size(120.0)
            .show(root, |ui| {
                egui::ScrollArea::vertical()
                    .stick_to_bottom(true)
                    .max_height(82.0)
                    .show(ui, |ui| {
                        for line in &self.command_log {
                            ui.label(line);
                        }
                    });
                ui.separator();
                let idle = self.command_line_idle();
                let set_view_prompt = self
                    .set_view_prompt
                    .as_ref()
                    .filter(|_| self.set_view_options_active())
                    .map(|session| session.prompt);
                self.command_line
                    .completion
                    .refresh(&self.commands, &self.command_input, idle);
                ui.horizontal(|ui| {
                    let label = if self.use_extrusions_prompt {
                        "UseExtrusions"
                    } else if self.remember_copy_prompt {
                        "RememberCopyOptions"
                    } else if let Some(prompt) = &self.edge_zoom_prompt {
                        prompt.command
                    } else if self.zoom_factor_pending.is_some() {
                        "Zoom Factor"
                    } else if self.plane_prompt.is_some() {
                        "CPlane"
                    } else if set_view_prompt.is_some() {
                        "SetView"
                    } else if self.length_units_pending {
                        "Length units"
                    } else if self.chain_prompt.is_some() {
                        "SelChain"
                    } else if let Some(p)=&self.edge_pattern_prompt {
                        p.command()
                    } else if self.select_uv_prompt.is_some() {
                        "SelUV"
                    } else if let Some(prompt)=&self.refinement_prompt {
                        prompt.command_name()
                    } else if self.reparameterize_prompt.is_some() {
                        "Reparameterize"
                    } else if self.curve_boolean_prompt.is_some() {
                        "CurveBoolean"
                    } else if self.fillet_surface_prompt.is_some() {
                        "FilletSrf"
                    } else if self.blend_surface_prompt.is_some() {
                        "BlendSrf"
                    } else if self.loft_prompt.is_some() {
                        "Loft"
                    } else if self.tween_surfaces_prompt.is_some() {
                        "TweenSurfaces"
                    } else if self.shell_prompt.is_some() {
                        "Shell"
                    } else if self.surface_path_prompt.is_some() {
                        "ExtrudeSrfAlongCrv"
                    } else if let Some(p) = &self.planar_boolean_prompt {
                        p.command
                    } else if self.boolean_two_prompt.is_some() {
                        "Boolean2Objects"
                    } else if let Some(prompt) = &self.object_prompt {
                        prompt.label()
                    } else if self.group_prompt.is_some() {
                        "AddToGroup"
                    } else if let Some(prompt) = &self.intersection_prompt {
                        prompt.name()
                    } else if let Some(prompt) = &self.edge_prompt {
                        prompt.name()
                    } else if let Some(prompt) = &self.hole_prompt {
                        prompt.name()
                    } else if let Some(prompt) = &self.crease_prompt {
                        prompt.command()
                    } else if self.soft_crease_prompt.is_some() {
                        "SubDCrease"
                    } else if let Some(prompt) = self.edge_fillet_prompt {
                        prompt.name()
                    } else if self.unjoin_prompt.is_some() {
                        "UnjoinEdge"
                    } else if self.component_selection.has_choices() {
                        "Select component"
                    } else {
                        self.active_command
                            .map_or("Command", InteractiveCommand::name)
                    };
                    ui.label(RichText::new(format!("{label}:")).strong());
                    let id = ui.make_persistent_id("main_command_input");
                    let focused = ui.memory(|memory| memory.focused() == Some(id));
                    let (tab, reverse, older, newer) = if focused && (idle || (self.active_command.is_none() && self.command_input.is_empty())) {
                        ui.input_mut(|input| {
                            // Consume Shift+Tab first: plain Tab must not steal it.
                            let reverse = idle &&
                                consume_exact_key(input, egui::Modifiers::SHIFT, egui::Key::Tab);
                            let tab = reverse
                                || consume_exact_key(input, egui::Modifiers::NONE, egui::Key::Tab);
                            let older = idle &&
                                consume_exact_key(input, egui::Modifiers::NONE, egui::Key::ArrowUp);
                            let newer = idle && consume_exact_key(
                                input,
                                egui::Modifiers::NONE,
                                egui::Key::ArrowDown,
                            );
                            (tab, reverse, older, newer)
                        })
                    } else {
                        (false, false, false, false)
                    };
                    if tab || older || newer {
                        ui.memory_mut(|memory| memory.move_focus(egui::FocusDirection::None));
                    }
                    if older || newer {
                        if let Some(text) = self
                            .command_line
                            .history
                            .navigate(&self.command_input, older)
                        {
                            self.command_input = text;
                            self.command_line.completion.reset();
                            self.command_focus_requested = true;
                        }
                    } else if tab && !reverse && self.command_input.is_empty() {
                        self.apply_interface_command(viboceros_command::interface::InterfaceCommand::SubDDisplayToggle);
                        self.command_focus_requested=true;
                    } else if tab && let Some(text) = self.command_line.completion.cycle(reverse) {
                        self.command_line.completion_cursor = Some(completion_cursor(&text));
                        self.command_input = text;
                        self.command_focus_requested = true;
                    }
                    let replacing_block = self.replacing_block();
                    let response = ui.add(
                        egui::TextEdit::singleline(&mut self.command_input)
                            .id(id)
                            .lock_focus(true)
                            .desired_width(f32::INFINITY)
                            .hint_text(if self.end_analysis_pick.is_some() {
                                "Pick curves; Enter finishes, Esc cancels"
                            } else if self.snap_size_pending.is_some() {
                                "Enter a positive grid snap spacing; Enter or Esc cancels"
                            } else if self.zoom_factor_pending.is_some() {
                                "Enter a positive factor; Enter or Esc cancels"
                            } else if self.plane_prompt.is_some() {
                                "Define the construction plane; Esc returns to the previous prompt"
                            } else if self.use_extrusions_prompt {
                                "Extrusion or Polysurface; Enter accepts, Esc cancels"
                            } else if self.remember_copy_prompt {
                                "Yes or No; Enter accepts, Esc cancels"
                            } else if self.edge_zoom_prompt.is_some() {
                                "All, Current, Next, Previous or Mark; Enter or Esc ends"
                            } else if let Some(prompt) = set_view_prompt {
                                prompt.message()
                            } else if let Some(p) = &self.select_uv_prompt {
                                p.hint()
                            } else if let Some(p) = &self.refinement_prompt {
                                p.hint()
                            } else if let Some(p) = &self.direction_session {
                                p.hint()
                            } else if let Some(p) = &self.reparameterize_prompt {
                                p.hint()
                            } else if let Some(p) = &self.curve_boolean_prompt {
                                if p.selecting() {"Select curves; Enter continues, Esc cancels"} else {"Pick regions or AllRegions; DeleteInput / CombineRegions / Output / SimplifyCurves; Enter accepts, Esc cancels"}
                            } else if let Some(p) = &self.curve_chamfer_session {
                                p.hint()
                            } else if let Some(p) = &self.offset_surface_session {
                                p.hint()
                            } else if let Some(p) = &self.ribbon_session {
                                p.hint()
                            } else if let Some(p) = &self.curve_fillet_session {
                                p.hint()
                            } else if let Some(p) = &self.fillet_surface_prompt {
                                p.hint()
                            } else if let Some(p) = &self.blend_surface_prompt {
                                p.hint()
                            } else if let Some(p)=&self.sweep_session {
                                p.hint()
                            } else if let Some(p)=&self.loft_prompt {
                                p.hint()
                            } else if let Some(p)=&self.tween_surfaces_prompt {
                                p.hint()
                            } else if let Some(p)=self.shell_prompt {
                                if p.awaiting_thickness{"Shell thickness; Enter a distance with optional units"}else{"Select faces to remove; Thickness / DeleteInput; Enter applies, Esc cancels"}
                            } else if self.surface_path_prompt.is_some() {
                                "Select path curve; Solid / DeleteInput / Reverse / PathLength; Esc cancels"
                            } else if self.planar_boolean_prompt.is_some() {
                                "Pick a planar surface; Esc cancels"
                            } else if let Some(prompt) = &self.boolean_two_prompt {
                                if prompt.cycling() {
                                    "Click for next result; Enter accepts, Esc cancels"
                                } else {
                                    "Select two surfaces or polysurfaces; Enter previews, Esc cancels"
                                }
                            } else if let Some(p)=&self.chain_prompt {
                                p.hint()
                            } else if self.edge_pattern_prompt.is_some() {
                                edge_pattern_selection::HINT
                            } else if self.length_units_pending {
                                "Enter a unit name or Model_Units; Esc cancels Length"
                            } else if let Some(prompt) = &self.object_prompt {
                                prompt.hint()
                            } else if let Some(prompt) = &self.group_prompt {
                                prompt.hint()
                            } else if let Some(prompt) = &self.intersection_prompt {
                                prompt.hint()
                            } else if let Some(prompt) = &self.subcurve_prompt {
                                prompt.hint()
                            } else if let Some(prompt) = &self.edge_prompt {
                                prompt.hint()
                            } else if let Some(prompt) = &self.hole_prompt {
                                prompt.hint()
                            } else if let Some(prompt)=&self.crease_prompt {
                                prompt.hint()
                            } else if let Some(prompt)=&self.soft_crease_prompt {
                                prompt.hint()
                            } else if let Some(prompt)=self.edge_fillet_prompt {
                                prompt.hint()
                            } else if self.unjoin_prompt.is_some() {
                                "Select joined edges; Enter applies, Esc cancels"
                            } else if self.component_selection.has_choices() {
                                "Choose a component by number, or pick again"
                            } else if replacing_block {
                                "Pick a replacement instance or choose a definition; Esc cancels"
                            } else if self.active_command.is_some() {
                                if self
                                    .active_command
                                    .is_some_and(InteractiveCommand::collects_curve_points)
                                {
                                    "Pick curve points; press Enter to finish or Esc to cancel"
                                } else {
                                    "Type coordinates or pick; Esc cancels"
                                }
                            } else {
                                "Type a command • Tab to complete • ↑ for history"
                            }),
                    );
                    if response.changed() {
                        self.command_line.completion.reset();
                    }
                    if self.command_focus_requested {
                        let cursor = self
                            .command_line
                            .completion_cursor
                            .take()
                            .unwrap_or_else(|| self.command_input.chars().count());
                        request_command_focus(ui.ctx(), id, &response, cursor);
                        self.command_focus_requested = false;
                    }
                    if response.lost_focus()
                        && ui.input(|input| input.key_pressed(egui::Key::Enter))
                    {
                        self.run_command();
                        request_command_focus(
                            ui.ctx(),
                            id,
                            &response,
                            self.command_input.chars().count(),
                        );
                    }
                });
                if self.set_view_prompt.is_none() {
                    self.show_edge_choices(ui);
                    self.show_hole_choices(ui);
                    self.show_rebuild_choices(ui);
                    self.show_component_choices(ui);
                    self.show_replace_block_choices(ui);
                }
                self.show_set_view_choices(ui);
                let idle = self.command_line_idle();
                self.command_line
                    .completion
                    .refresh(&self.commands, &self.command_input, idle);
                let completion = &self.command_line.completion;
                if !completion.candidates.is_empty() {
                    let mut chosen = None;
                    let start = completion.selected.unwrap_or(0) / 8 * 8;
                    ui.horizontal_wrapped(|ui| {
                        ui.label(RichText::new("Tab / Shift+Tab:").small());
                        for (index, candidate) in
                            completion.candidates.iter().enumerate().skip(start).take(8)
                        {
                            if ui
                                .selectable_label(
                                    completion.selected == Some(index),
                                    &candidate.label,
                                )
                                .clicked()
                            {
                                chosen = Some(index);
                            }
                        }
                        if completion.candidates.len() > 8 {
                            ui.small(format!("{} matches", completion.candidates.len()));
                        }
                    });
                    if let Some(index) = chosen
                        && let Some(text) = self.command_line.completion.choose(index)
                    {
                        self.command_line.completion_cursor = Some(completion_cursor(&text));
                        self.command_input = text;
                        self.command_focus_requested = true;
                    }
                }
            });
    }
}

// Egui's consume_key deliberately ignores extra Shift/Alt modifiers. Keep
// text-selection and platform shortcuts intact by matching these keys exactly.
pub(super) fn consume_exact_key(
    input: &mut egui::InputState,
    modifiers: egui::Modifiers,
    key: egui::Key,
) -> bool {
    let mut found = false;
    input.events.retain(|event| {
        let matched = matches!(event, egui::Event::Key { key: event_key, modifiers: event_modifiers, pressed: true, .. } if *event_key == key && *event_modifiers == modifiers);
        found |= matched;
        !matched
    });
    found
}

fn completion_cursor(text: &str) -> usize {
    let directory = text.ends_with("/\"") || cfg!(windows) && text.ends_with("\\\"");
    text.chars().count() - usize::from(directory)
}

fn request_command_focus(
    context: &egui::Context,
    id: egui::Id,
    response: &egui::Response,
    cursor: usize,
) {
    // Re-requesting existing focus resets egui's keyboard lock filter, which
    // makes the next Tab/arrow move focus to a suggestion instead of editing.
    if !context.memory(|memory| memory.has_focus(id)) {
        response.request_focus();
    }
    context.memory_mut(|memory| {
        memory.set_focus_lock_filter(
            id,
            egui::EventFilter {
                tab: true,
                horizontal_arrows: true,
                vertical_arrows: true,
                ..Default::default()
            },
        )
    });
    let mut state = egui::TextEdit::load_state(context, id).unwrap_or_default();
    let cursor = egui::text::CCursor::new(cursor);
    state
        .cursor
        .set_char_range(Some(egui::text::CCursorRange::one(cursor)));
    egui::TextEdit::store_state(context, id, state);
}

#[cfg(test)]
pub(super) mod tests {
    use std::path::PathBuf;
    pub(in crate::app) struct TempDirectory(pub PathBuf);
    impl TempDirectory {
        pub fn new() -> Self {
            use std::sync::atomic::{AtomicUsize, Ordering};
            static NEXT: AtomicUsize = AtomicUsize::new(0);
            let path = std::env::temp_dir().join(format!(
                "viboceros-command-line-{}-{}-{}",
                std::process::id(),
                std::time::SystemTime::now()
                    .duration_since(std::time::UNIX_EPOCH)
                    .unwrap()
                    .as_nanos(),
                NEXT.fetch_add(1, Ordering::Relaxed)
            ));
            std::fs::create_dir(&path).unwrap();
            Self(path)
        }
    }
    impl Drop for TempDirectory {
        fn drop(&mut self) {
            let _ = std::fs::remove_dir_all(&self.0);
        }
    }
}
