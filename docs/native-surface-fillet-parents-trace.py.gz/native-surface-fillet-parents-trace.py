import subprocess,json,time
from pathlib import Path
b=Path('target/release/build/viboceros-smlib-d4f77638f5302455/out/build');p='/tmp/viboceros-fillet-parents-'
s=Path('crates/viboceros-smlib/native/surface_fillet.cpp').read_text().replace('SmBrep *vb_fillet_surfaces(','SmBrep *vb_test_fillet_parents(').replace('double extension_factor, double accuracy) {','double extension_factor, double accuracy, unsigned base_trim, SmBrep *output_parents[2]) {').replace('        0, FALSE, FALSE, extension_factor);','        base_trim, FALSE, FALSE, extension_factor);').replace('    return result.release();','    for(size_t i=0;i<2;++i) output_parents[i]=parents[i].release();\n    return result.release();')
Path(p+'prototype.cpp').write_text(s)
flags=['c++','-std=c++17','-O1','-DNDEBUG','-DNOMINMAX','-DSM_GRAPHICS_CALLBACKS=1','-DVIBOCEROS_CURVE_INTERSECTION_DISTANCE_PATCH=1','-w','-I','crates/viboceros-smlib/native','-I',str(b/'usd-brep-patched'),'-I','third_party/usd-brep/source/SM_API/inc','-I','third_party/usd-brep/source/SMLib/inc','-include','third_party/usd-brep/source/SMLib/inc/StdAfx.h']
a=flags+[p+'probe-trace.cpp',str(b/'libviboceros_smlib.a'),str(b/'libSM_API.a'),str(b/'libSMLib.a'),'-ltbb','-ltbbmalloc','-o',p+'probe-trace']
start=time.monotonic();subprocess.run(a,check=True)
with open(p+'probe-trace.jsonl','w')as out:r=subprocess.run([p+'probe-trace'],stdout=out,check=True)
Path(p+'trace-runtime.json').write_text(json.dumps(dict(status=r.returncode,seconds=time.monotonic()-start,build_command=a))+'\n')
