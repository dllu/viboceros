import copy,json,time,sys
from pathlib import Path
from tools.rhino_oracle.client import OracleClient
from tools.rhino_oracle.reparameterize_automatic_cases import request
p='/tmp/viboceros-auto-surface-';root=Path('tools/rhino_oracle/fixtures/reparameterize_automatic').resolve();root.mkdir(exist_ok=True)
q=request(str(root))
for label,epsilon in [('main',1e-8),('tight',1e-12),('loose',1e-5)]:
 if len(sys.argv)>1 and label!=sys.argv[1]:continue
 batch=copy.deepcopy(q);batch['tolerance']['absolute']=epsilon
 if label!='main':
  batch['operations']=[o for o in batch['operations']if o['id']in ['sphere_automatic','bilinear_warp_automatic']]
  for op in batch['operations']:
   op['id']=label+'_'+op['id'];op['artifact_path']=str(root/(op['id']+'.3dm'))
 Path(p+label+'-request.json').write_text(json.dumps(batch,indent=2)+'\n');t=time.monotonic()
 r=OracleClient(settings_scheme='VibocerosOracleAutomaticSize20261018'+label).run_rhino(batch,timeout=600.)
 Path(p+label+'-response.json').write_text(json.dumps(r,indent=2)+'\n');Path(p+label+'-runtime.json').write_text(json.dumps(dict(seconds=time.monotonic()-t,recipes=len(batch['operations'])))+'\n')
 for row in r['results']:
  v=row['value'];f=v['after']['geometry']['geometry']['faces'][0]['definition'];print(label,row['id'],v['success'],f['domain_u'],f['domain_v'],flush=True)
