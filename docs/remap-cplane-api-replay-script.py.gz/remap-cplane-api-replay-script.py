import json
from pathlib import Path
from tools.rhino_oracle.client import OracleClient


class RecordingClient(OracleClient):
    def run_viboceros_audit(self, request, timeout=180.0):
        response = super().run_viboceros_audit(request, timeout)
        self.response = response
        return response


client = RecordingClient()
rows = []
for suffix in ('', '_copy', '_views'):
    stem = 'remap_cplane' + suffix
    request = json.loads(Path('tools/rhino_oracle/fixtures/' + stem + '.json').read_text())
    observation = json.loads(Path('tools/rhino_oracle/observations/' + stem + '.json').read_text())
    report = client.replay(request, observation, absolute_epsilon=1e-9,
                           relative_epsilon=0., timeout=1200.)
    raw = '/tmp/viboceros-remap-api-' + stem + '-audit.json'
    result = '/tmp/viboceros-remap-api-' + stem + '-report.json'
    Path(raw).write_text(json.dumps(client.response, indent=2) + '\n')
    Path(result).write_text(json.dumps(report.as_dict(), indent=2) + '\n')
    row = dict(fixture=stem, matched=report.matched, failed=report.native_failed,
               passed=report.passed, raw=raw, report=result,
               maximum_absolute_error=max(o.comparison.max_absolute_error for o in report.operations
                                          if o.comparison is not None))
    rows.append(row)
    print(json.dumps(row), flush=True)
    assert report.passed
assert sum(row['matched'] for row in rows) == 52
Path('/tmp/viboceros-remap-api-replay-summary.json').write_text(json.dumps(rows, indent=2) + '\n')
