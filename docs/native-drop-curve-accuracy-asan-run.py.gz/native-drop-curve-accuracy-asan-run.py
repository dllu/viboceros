import json,os,subprocess,time
from pathlib import Path
p='/tmp/viboceros-drop-accuracy-'
for suffix in ['jsonl','stderr']:
 path=Path(p+'asan.'+suffix)
 if path.exists():path.rename(p+'asan-initial.'+suffix)
lines=Path(p+'asan-initial.jsonl').read_text().splitlines();complete=[]
for line in lines:
 try:complete.append(json.loads(line))
 except json.JSONDecodeError:pass
Path(p+'asan-initial.json').write_text(json.dumps(dict(outcome='runner_timeout',runner_timeout_seconds=120,completed_rows=len(complete),completed_passes=sum(x['passed']for x in complete),diagnostic_bytes=Path(p+'asan-initial.stderr').stat().st_size,scope='The subprocess runner killed the instrumented executable at its fixed 120-second limit; this is an incomplete attempt, not a passing run.'),indent=2)+'\n')
start=time.monotonic()
with open(p+'asan.jsonl','w')as out,open(p+'asan.stderr','w')as err:
 r=subprocess.run(['/tmp/viboceros-isocurve-pair-asan/viboceros_smlib_drop_curve_probe'],stdout=out,stderr=err,timeout=600,env=dict(os.environ,ASAN_OPTIONS='detect_leaks=0:halt_on_error=1'))
Path(p+'asan.status').write_text(str(r.returncode)+'\n')
rows=[json.loads(x)for x in Path(p+'asan.jsonl').read_text().splitlines()]
assert r.returncode==0 and len(rows)==270 and all(x['passed']for x in rows)
Path(p+'asan-runtime.json').write_text(json.dumps(dict(elapsed_seconds=time.monotonic()-start,runner_timeout_seconds=600,exit_code=r.returncode,cases=len(rows)),indent=2)+'\n')
with open(p+'asan-flags.txt','w')as log:
 for name in ['SMLib','SM_API','viboceros_smlib','viboceros_smlib_drop_curve_probe']:
  flags=(Path('/tmp/viboceros-isocurve-pair-asan')/'CMakeFiles'/(name+'.dir')/'flags.make').read_text();assert '-fsanitize=address'in flags;log.write(name+'\n'+flags+'\n')
print('asan',r.returncode,len(rows),flush=True)
