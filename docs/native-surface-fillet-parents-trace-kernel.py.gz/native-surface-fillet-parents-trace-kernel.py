import subprocess,time,json
from pathlib import Path
b=Path('target/release/build/viboceros-smlib-d4f77638f5302455/out/build');p='/tmp/viboceros-fillet-parents-'
flags=['c++','-std=c++17','-O1','-DNDEBUG','-DNOMINMAX','-DSM_GRAPHICS_CALLBACKS=1','-DVIBOCEROS_CURVE_INTERSECTION_DISTANCE_PATCH=1','-w','-I','crates/viboceros-smlib/native','-I',str(b/'usd-brep-patched'),'-I','third_party/usd-brep/source/SM_API/inc','-I','third_party/usd-brep/source/SMLib/inc','-include','third_party/usd-brep/source/SMLib/inc/StdAfx.h']
objects=[];jobs=[]
for name in ['SmFilletExecutive','SmFilletGeom']:
 source=b/'usd-brep-patched'/str(('SmFilletExecutiveDomains' if name=='SmFilletExecutive' else name)+'.cpp')
 if not source.exists():source=Path('third_party/usd-brep/source/SMLib/src')/str(name+'.cpp')
 s=source.read_text();s='#undef SER\n#define SER(a) {SmStatus ss=(a);if(ss!=SM_SUCCESS){fprintf(stderr,"TRACE %s:%d %s = %ld\\n",__FILE__,__LINE__,#a,(long)ss);return ss;}}\n'+s
 target=Path(p+name+'.cpp');target.write_text(s);obj=p+name+'.o';objects.append(obj);jobs.append(subprocess.Popen(flags+['-c',str(target),'-o',obj]))
statuses=[job.wait()for job in jobs];assert statuses==[0,0],statuses
subprocess.run(flags+[p+'probe-trace.cpp',*objects,str(b/'libviboceros_smlib.a'),str(b/'libSM_API.a'),str(b/'libSMLib.a'),'-ltbb','-ltbbmalloc','-o',p+'kernel-trace'],check=True)
with open(p+'kernel-trace.jsonl','w')as out:subprocess.run([p+'kernel-trace'],stdout=out,check=True)
