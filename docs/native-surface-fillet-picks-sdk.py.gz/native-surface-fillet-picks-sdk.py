import copy,json,math,time
from pathlib import Path
from tools.rhino_oracle.client import OracleClient
base=json.loads(Path('tools/rhino_oracle/fixtures/surface_fillet.json').read_text());plane=next(o for o in base['operations']if o['id']=='planes-0-False');cylinder=next(o for o in base['operations']if o['id']=='cylinder-False');ops=[];expected={}
radius=.75

def queries(sides,curved):
 a,b=sides;cz=a*radius;points=[]
 for t in [.2,.7]:
  for alpha in [.3,.8]:
   z=cz-a*radius*math.cos(alpha)
   if curved:
    r=5+b*radius-b*radius*math.sin(alpha);points.append([r*math.cos(t*math.pi/2),r*math.sin(t*math.pi/2),z])
   else:points.append([5-b*radius+b*radius*math.sin(alpha),10*t,z])
 return points
for x in [.2,.8]:
 for z in [.2,.8]:
  o=copy.deepcopy(plane);o.update(id='planes-'+str(x)+'-'+str(z),radius=radius,extend=False,picks=[[x,.5],[z,.5]])
  sides=[1 if z>.5 else -1,1 if x<.5 else -1];o['queries']=queries(sides,False);ops.append(o);expected[o['id']]=sides
for xy in [[2.,2.],[6.,0.],[-6.,0.]]:
 for z in [.2,.8]:
  o=copy.deepcopy(cylinder);o.update(id='cylinder-'+str(xy[0])+'-'+str(z),radius=radius,extend=False,picks=[[(xy[0]+10)/20,(xy[1]+10)/20],[.5,z]])
  sides=[1 if z>.5 else -1,1 if math.hypot(*xy)>5 else -1];o['queries']=queries(sides,True);ops.append(o);expected[o['id']]=sides
source=next(o for o in ops if o['id']=='cylinder--6.0-0.8')
for kind in ['reverse-u','reverse-v','swap','mobius-.5','mobius-2','reverse-plane']:
 o=copy.deepcopy(source);o['id']=kind;s=o['surfaces'][1];nu,nv=s['control_point_count_u'],s['control_point_count_v'];cp=s['control_points']
 if kind in ['reverse-u','reverse-v']:
  axis=0 if kind=='reverse-u'else 1;o['picks'][1][axis]=1-o['picks'][1][axis]
  s['control_points']=[cp[j*nu+(nu-1-i)if axis==0 else(nv-1-j)*nu+i]for j in range(nv)for i in range(nu)]
 elif kind=='swap':
  s['control_points']=[cp[j*nu+i]for i in range(nu)for j in range(nv)]
  for key in ['degree','control_point_count','knots']:s[key+'_u'],s[key+'_v']=s[key+'_v'],s[key+'_u']
  o['picks'][1].reverse()
 elif kind.startswith('mobius'):
  k=float(kind.split('-')[1]);o['picks'][1][0]=1/(k+1)
  for j in range(nv):
   for i in range(nu):cp[j*nu+i]['weight']*=k**i
 else:
  p=o['surfaces'][0];p['control_points']=[p['control_points'][j*2+1-i]for j in range(2)for i in range(2)];o['picks'][0][0]=1-o['picks'][0][0]
 sides=[-1,1]if kind=='reverse-plane'else[1,1 if kind.startswith('mobius')else -1]
 ops.append(o);expected[o['id']]=sides
base['operations']=ops;prefix='/tmp/viboceros-fillet-picks-sdk-'
Path(prefix+'request.json').write_text(json.dumps(base,indent=2)+'\n');Path(prefix+'expected-sides.json').write_text(json.dumps(expected,indent=2)+'\n')
start=time.monotonic();r=OracleClient(settings_scheme='VibocerosOracleFilletPicks20261018').run_rhino(base,timeout=600.)
Path(prefix+'response.json').write_text(json.dumps(r,indent=2)+'\n');Path(prefix+'runtime.json').write_text(json.dumps({'seconds':time.monotonic()-start,'recipes':len(ops)})+'\n')
for row in r['results']:
 o=next(o for o in ops if o['id']==row['id']);outs=row['value']['outputs'];assert len(outs)==1 and outs[0]['valid'] and row['value']['source_unchanged'],row['id']
 error=max(math.dist(p,q)for p,q in zip(o['queries'],outs[0]['closest_points']))
 print(json.dumps({'id':row['id'],'expected_sides':expected[row['id']],'maximum_analytic_query_error':error,'vertices':[v['point']for v in outs[0]['geometry']['vertices']]}),flush=True)
 assert error<=1e-8,(row['id'],error)
