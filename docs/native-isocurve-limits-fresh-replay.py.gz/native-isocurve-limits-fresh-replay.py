import json
from pathlib import Path
from tools.rhino_oracle.client import OracleClient
class RecordingClient(OracleClient):
 def run_viboceros_audit(self,request,timeout=180.):
  self.response=super().run_viboceros_audit(request,timeout)
  return self.response
client=RecordingClient(native_smlib=True)
request=json.loads(Path('tools/rhino_oracle/fixtures/surface_isocurve_geometry.json').read_text())
observation=json.loads(Path('tools/rhino_oracle/observations/surface_isocurve_geometry.json').read_text())
report=client.replay(request,observation,timeout=1800.)
Path('/tmp/viboceros-isocurve-limits-fresh-audit.json').write_text(json.dumps(client.response,indent=2)+'\n')
Path('/tmp/viboceros-isocurve-limits-fresh-report.json').write_text(json.dumps(report.as_dict(),indent=2)+'\n')
print(json.dumps(dict(cases=len(report.operations),matched=report.matched,native_failed=report.native_failed,passed=report.passed)),flush=True)
