import json
from pathlib import Path
from tools.rhino_oracle.audit import compare_audit_response

root = Path('tools/rhino_oracle')
def read(path):
    return json.loads(path.read_text())
audit = read(Path('/tmp/viboceros-surface-patch-isocurve-audit.json'))
discovery = read(root / 'fixtures/join_isocurve_certificates.json')
source_operations = {o['id']: o for o in discovery['operations']}
rows = {o['result']['id'] if o['status'] == 'success' else o['id']: o for o in audit['outcomes']}
for stem in ['join_isocurve_local', 'join_isocurve_origin']:
    request = read(root / ('fixtures/' + stem + '.json'))
    observation = read(root / ('observations/' + stem + '.json'))
    for op in request['operations']:
        assert op == source_operations[op['id']], op['id']
    subset = dict(audit, outcomes=[rows[o['id']] for o in request['operations']])
    report = compare_audit_response(subset, observation, 1e-10, 1e-12, request=request)
    Path('/tmp/viboceros-surface-patch-' + stem + '-report.json').write_text(json.dumps(report.as_dict(), indent=2) + '\n')
    print(json.dumps(dict(fixture=stem, cases=len(report.operations), matched=report.matched,
                         native_failed=report.native_failed,
                         mismatched=len(report.operations)-report.matched-report.native_failed)), flush=True)

assert len(rows) == 64
assert all(r['status'] == 'success' for r in rows.values())
for identifier, row in rows.items():
    value = row['result']['value']
    assert value['succeeded'], identifier
    outputs = [o for o in value['objects'] if o['source'] is None]
    assert len(outputs) == 1, (identifier, len(outputs))
    b = outputs[0]['brep']
    assert len(b['faces']) == 2 and len(b['edges']) == 7, identifier
    assert b['manifold'] and not b['solid'], identifier
    assert sorted(e['uses'] for e in b['edges']) == [1]*6+[2], identifier
print(json.dumps(dict(discovery_cases=64, single_connected_two_face_outputs=64)), flush=True)
