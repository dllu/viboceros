import json,math
from pathlib import Path
from tools.rhino_oracle.client import OracleClient
sdk=json.loads(Path('tools/rhino_oracle/observations/curve_segment_limits_geometry.json').read_text())
cpp=json.loads(Path('/tmp/viboceros-curve-segment-limits-sdk-2-audit.json').read_text())
ref=next(o['value']for o in sdk['results']if o['id']=='native-segment-limit-9')
native=next(o['result']['value']for o in cpp['outcomes']if o['result']['id']=='native-segment-limit-9')
request=dict(protocol_version=1,iterations=1,operations=[])
for label,definition in [('cpp',native),('sdk',ref)]:
 for i in range(65):
  t=definition['domain'][0]+(definition['domain'][1]-definition['domain'][0])*i/64
  request['operations'].append(dict(op='nurbs_curve_evaluate',id=label+'-'+str(i),degree=definition['degree'],control_points=definition['control_points'],knots=definition['knots'],parameter=t))
Path('/tmp/viboceros-curve-segment-limits-equivalence-request.json').write_text(json.dumps(request,indent=2)+'\n')
response=OracleClient(settings_scheme='VibocerosOracleCurveSegmentEquivalent20261018').run_rhino(request,timeout=180.)
Path('/tmp/viboceros-curve-segment-limits-equivalence-rhino.json').write_text(json.dumps(response,indent=2)+'\n')
values={r['id']:r['value']for r in response['results']}
errors=dict(point=0.,derivative=0.)
for i in range(65):
 for key in errors:
  a,b=values['cpp-'+str(i)][key],values['sdk-'+str(i)][key]
  assert len(a)==len(b)==3
  for x,y in zip(a,b):
   assert math.isfinite(x)and math.isfinite(y)
   errors[key]=max(errors[key],abs(x-y))
report=dict(engine='rhino',sdk_evaluations=len(response['results']),comparison_pairs=65,absolute_epsilon=1e-10,max_absolute_differences=errors,passed=max(errors.values())<=1e-10,normalization='None. Rhino evaluates both retained definitions at identical parameter stations; the raw definition mismatch remains.')
Path('/tmp/viboceros-curve-segment-limits-equivalence-report.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report),flush=True);assert report['passed']
