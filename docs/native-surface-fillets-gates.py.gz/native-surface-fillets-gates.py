import os,subprocess
from pathlib import Path
prefix='/tmp/viboceros-surface-fillet-';env=dict(os.environ,CMAKE_BUILD_PARALLEL_LEVEL='10',CARGO_BUILD_JOBS='8',PYTHONPATH='.')
commands=[('bridge',['cargo','test','--release','-p','viboceros-smlib','--features','native','--no-fail-fast','--','--nocapture']),('command',['cargo','test','--release','-p','viboceros-command','--features','native-smlib','--no-fail-fast','--','--nocapture']),('oracle',['cargo','test','--release','-p','viboceros-oracle','--features','native-smlib','surface_fillet','--','--nocapture']),('oracle-portable',['cargo','test','--release','-p','viboceros-oracle','surface_fillet','--','--nocapture']),('clippy',['cargo','clippy','--workspace','--all-targets','--all-features','--','-D','warnings']),('fmt',['cargo','fmt','--all','--','--check']),('python',['python3','-m','unittest','discover','-s','tools/rhino_oracle','-t','.']),('oracle-build-final',['cargo','build','--release','-p','viboceros-oracle','--features','native-smlib'])]
for name,command in commands[1:]:
 with open(prefix+name+'.log','w')as log:result=subprocess.run(command,env=env,stdout=log,stderr=subprocess.STDOUT)
 Path(prefix+name+'.status').write_text(str(result.returncode)+'\n');print(name,result.returncode,flush=True)
 if result.returncode:raise SystemExit(result.returncode)
