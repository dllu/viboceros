//! Optional native USD BRep/SMLib adapter. Enable `native` on Linux.
//!
//! Kernel handles are thread-local; native calls are serialized process-wide.
//! Boolean operations copy their operands before mutation. Native solids can
//! import and export owned NURBS topology with validated Rust B-reps. The optional
//! application feature uses this adapter for closed curved BooleanDifference,
//! BooleanUnion, BooleanIntersection and BooleanSplit, surface joining/offsets,
//! and native curve extrusion.
#[cfg(feature = "native")]
mod native;
// The native wall classifier calls the shared OpenNURBS C ABI directly.
#[cfg(feature = "native")]
pub use native::{
    BooleanOperation, ChamferRailType, CurveDistanceExtrema, CurveDistanceWitness,
    EdgeBlendRailType, Error, FittedGordonNetwork, GordonCurveFamilyFit, GordonCurveFitClock,
    GordonCurveFitInput, GordonNetworkSourceImage, KernelCurve, MeshIntersections, MeshSplitPart,
    Shape, Solid, SolidProperties, StitchResult, SurfaceFilletOptions, SurfaceFilletParentMode,
    SurfaceFilletResult, SurfaceFilletSide, SurfaceMergeOptions, SurfacePullCurve, Tessellation,
    average_match_curve_ends, average_match_surface_supports, blend_curve,
    blend_curve_from_endpoint_jets, blend_curve_from_jets, blend_surfaces,
    brep_intersection_events, chamfer_curves_joined, chamfer_curves_parts, change_curve_degree,
    change_curve_seam, change_surface_degree, change_surface_seam, connect_curves_joined,
    connect_curves_parts, curve_bezier_spans, curve_brep_intersection_events,
    curve_distance_extrema, curve_edit_point_interpolation, curve_intersection_events,
    curve_minimum_distance, curve_offset_operations, curve_self_intersection_events,
    curve_surface_intersection_events, curve_tweens, extend_curve, extend_curve_by_length,
    extend_curve_naturally_by_length, extend_curve_to_boundaries, extend_surface,
    extend_surface_by_length, fillet_corners, fillet_curves_joined, fillet_curves_parts,
    fillet_surfaces, fillet_surfaces_with_parents, fit_cubic_curve_at_stations,
    fit_cubic_curve_with_constraints, fit_curve, fit_gordon_curve_family,
    fit_gordon_curve_family_with_clock, fit_surface_image_in_basis, fit_surface_image_with_bound,
    fit_surface_in_basis, fit_surface_with_bound, fit_sweep_model_surface,
    fitted_gordon_network_surface, gordon_network_surface, insert_curve_knot, insert_surface_knot,
    interpolate_affine_greville, interpolate_curve, interpolate_curve_for_command,
    interpolate_endpoints, interpolate_open_point_grid, interpolate_point_grid,
    interpolate_surface_blend, interpolate_surface_in_basis, join_curve_natural_extension,
    join_curve_smooth_extension, join_curve_to_boundaries, loft_surface, loft_surface_rebuilt,
    loft_surface_refitted, loft_surface_refitted_with_angle, loft_surface_with_end_points,
    make_curve_non_periodic, make_curve_periodic, make_surface_non_periodic, make_surface_periodic,
    match_curve_end, match_surface_supports, merge_surface_supports, mesh_boolean,
    mesh_boolean_interaction, mesh_intersections, mesh_self_intersections, mesh_split,
    mesh_split_with_face_sources, modeling_surface_intersection_events, morph_interpolation,
    morph_preview_operations, offset_curve_parts, offset_curve_through_point, offset_surface,
    point_grid_brep, prepare_loft_sections, prepare_morph_preview_curve, prepared_gordon_surface,
    projected_curve_intervals, pull_curve_to_surface, rail_revolved_brep, rail_revolved_surface,
    rebuild_curve, rebuild_surface, rebuild_sweep_sections, reduce_curve_knots_in_range,
    reduce_surface_knots_in_range, remove_curve_knot, remove_curve_knot_at_value,
    remove_curve_multiple_knots, remove_periodic_surface_knot, remove_surface_knot,
    remove_surface_multiple_knots, ruled_surface, separate_curve_extensions_to_boundaries,
    separate_curve_natural_extensions, separate_curve_smooth_extensions, split_curve,
    split_curve_at_parameters, split_surface, subcurve, subcurve_at_arc_length,
    surface_brep_intersection_events, surface_face_intersection_events,
    surface_intersection_events, surface_isocurve, surface_single_span_patches, surface_tweens,
    surface_tweens_refitted, surface_tweens_sampled, sweep_model, sweep_model_with_point_ends,
    sweep_surface, trim_blend_parent, trim_curve, trim_surface, trim_surface_direction,
    two_rail_sweep_surface,
};
#[cfg(feature = "native")]
use viboceros_opennurbs as _;
