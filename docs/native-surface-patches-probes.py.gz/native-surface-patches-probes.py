import json,os,subprocess
from pathlib import Path
root=Path('/home/dllu/proj/viboceros')
builds=list((root/'target/debug/build').glob('viboceros-smlib-*/out/build/viboceros_smlib_surface_patch_probe'))
build=max(builds,key=lambda p:p.stat().st_mtime).parent
# Use a tree not currently being built by Cargo only after its focused gate completes.
Path('/tmp/viboceros-surface-patch-build-path').write_text(str(build))
with open('/tmp/viboceros-surface-patch-baseline-build.log','w') as log:
 r=subprocess.run(['cmake','--build',str(build),'--target','viboceros_smlib_surface_patch_probe','viboceros_smlib_surface_patch_baseline','-j10'],stdout=log,stderr=subprocess.STDOUT)
Path('/tmp/viboceros-surface-patch-baseline-build.status').write_text(str(r.returncode)+'\n')
if r.returncode:raise SystemExit(r.returncode)
asan=Path('/tmp/viboceros-isocurve-pair-asan')
with open('/tmp/viboceros-surface-patch-asan-build.log','w') as log:
 r=subprocess.run(['cmake','--build',str(asan),'--target','viboceros_smlib_surface_patch_probe','viboceros_smlib','-j10'],stdout=log,stderr=subprocess.STDOUT)
Path('/tmp/viboceros-surface-patch-asan-build.status').write_text(str(r.returncode)+'\n')
if r.returncode:raise SystemExit(r.returncode)
with open('/tmp/viboceros-surface-patch-asan-flags.txt','w')as log:
 for name in ['SMLib','SM_API','viboceros_smlib','viboceros_smlib_surface_patch_probe']:
  s=(asan/'CMakeFiles'/(name+'.dir')/'flags.make').read_text();assert '-fsanitize=address' in s
  log.write(name+'\n'+s+'\n')
for label,binary,expected in [('baseline',build/'viboceros_smlib_surface_patch_baseline',1),('candidate',build/'viboceros_smlib_surface_patch_probe',0),('asan',asan/'viboceros_smlib_surface_patch_probe',0)]:
 with open('/tmp/viboceros-surface-patch-'+label+'.jsonl','w')as log,open('/tmp/viboceros-surface-patch-'+label+'.stderr','w')as err:
  r=subprocess.run([str(binary)],stdout=log,stderr=err,env=dict(os.environ,ASAN_OPTIONS='detect_leaks=0:halt_on_error=1'))
 Path('/tmp/viboceros-surface-patch-'+label+'.status').write_text(str(r.returncode)+'\n')
 print(json.dumps(dict(label=label,binary=str(binary),exit_code=r.returncode)),flush=True)
 assert r.returncode==expected
