#include "/tmp/viboceros-fillet-parents-prototype.cpp"
#include <iomanip>
#include <iostream>
#include <vector>
struct Input {
 size_t pu=1,nu=2;std::vector<double>u{0,0,1,1},v{0,0,1,1},cp;
 VbNurbsData view()const{return {{pu,1},{nu,2},{u.size(),v.size()},{u.data(),v.data()},cp.data()};}
};
Input plane(bool other){Input s;for(double y:{-10.,10.})for(double x:{-10.,10.}){if(other)s.cp.insert(s.cp.end(),{0.,y,x,1.});else s.cp.insert(s.cp.end(),{x,y,0.,1.});}return s;}
Input cylinder(){Input s;s.pu=2;s.nu=3;s.u={0,0,0,1,1,1};for(double z:{-5.,5.})for(int i=0;i<3;i++)s.cp.insert(s.cp.end(),{i<2?5.:0.,i>0?5.:0.,z,i==1?std::sqrt(.5):1.});return s;}
void trace(SmStatus code,const TCHAR *file,ULONG line,const TCHAR *message){std::cerr<<"trace "<<code<<" "<<(file?file:"")<<":"<<line<<" "<<(message?message:"")<<"\n";}
int main(){smos_SetErrorCallback(trace);std::cout<<std::setprecision(17);for(int family=0;family<2;family++)for(int a:{-1,1})for(int b:{-1,1})for(unsigned mode:{0,1,2}){
 std::cout<<"{\"family\":"<<family<<",\"sides\":["<<a<<","<<b<<"],\"mode\":"<<mode;
 try{auto first=plane(false),second=family?cylinder():plane(true);auto f=first.view(),s=second.view();SmBrep *parents[2]={};int sides[2]={a,b};std::unique_ptr<SmBrep>fillet(vb_test_fillet_parents(f,s,.75,sides,false,0,1e-8,mode,parents));std::unique_ptr<SmBrep>one(parents[0]),two(parents[1]);std::vector<VbBrep*>copies;
 for(auto* body:{one.get(),two.get(),fillet.get()})copies.push_back(body?vb_export_brep(*body,1e-10):nullptr);
 one.reset();two.reset();fillet.reset();std::cout<<",\"outputs\":[";
 for(size_t k=0;k<copies.size();++k){if(k)std::cout<<',';std::unique_ptr<VbBrep,decltype(&vb_brep_free)>copy(copies[k],&vb_brep_free);if(!copy){std::cout<<"null";continue;}VbBrepView v{};if(vb_brep_view(copy.get(),&v))throw std::runtime_error("view");std::cout<<"{\"counts\":["<<v.face_count<<","<<v.edge_count<<","<<v.vertex_count<<"],\"vertices\":[";for(size_t j=0;j<v.vertex_count;j++){if(j)std::cout<<',';auto*p=v.vertices[j].point;std::cout<<'['<<p[0]<<','<<p[1]<<','<<p[2]<<']';}std::cout<<"]}";}
 std::cout<<"]";
 }catch(const std::exception&e){std::cout<<",\"error\":\""<<e.what()<<"\"";}std::cout<<"}\n";
}}
