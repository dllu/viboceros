import json
from pathlib import Path
from tools.rhino_oracle.client import OracleClient
class RecordingClient(OracleClient):
 def run_viboceros_audit(self,request,timeout=180.):
  self.response=super().run_viboceros_audit(request,timeout);return self.response
client=RecordingClient(native_smlib=True)
for stem in ['curve_trim_geometry','curve_segment_limits_geometry']:
 request=json.loads(Path('tools/rhino_oracle/fixtures/'+stem+'.json').read_text())
 observation=json.loads(Path('tools/rhino_oracle/observations/'+stem+'.json').read_text())
 report=client.replay(request,observation,1e-10,1e-12,timeout=1800.)
 Path('/tmp/viboceros-curve-segment-limits-'+stem+'-audit.json').write_text(json.dumps(client.response,indent=2)+'\n')
 Path('/tmp/viboceros-curve-segment-limits-'+stem+'-report.json').write_text(json.dumps(report.as_dict(),indent=2)+'\n')
 print(json.dumps(dict(fixture=stem,cases=len(report.operations),matched=report.matched,native_failed=report.native_failed,mismatched_ids=[r.id for r in report.operations if not r.passed])),flush=True)
 assert len(report.operations)==9 and report.native_failed==0
