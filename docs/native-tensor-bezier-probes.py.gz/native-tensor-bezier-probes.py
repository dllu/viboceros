import json,os,subprocess
from pathlib import Path
root=Path('/home/dllu/proj/viboceros')
prefix='/tmp/viboceros-tensor-bezier-'
build=root/'target/debug/build/viboceros-smlib-e982af202de3f65b/out/build'
Path(prefix+'build-path').write_text(str(build))
with open(prefix+'baseline-build.log','w')as log:
 r=subprocess.run(['cmake','-S',str(root/'crates/viboceros-smlib/native'),'-B',str(build),'-DUSD_BREP_ROOT='+str(root/'third_party/usd-brep')],stdout=log,stderr=subprocess.STDOUT)
 assert r.returncode==0
 r=subprocess.run(['cmake','--build',str(build),'--target','viboceros_smlib_tensor_bezier_probe','viboceros_smlib_tensor_bezier_baseline','-j10'],stdout=log,stderr=subprocess.STDOUT)
Path(prefix+'baseline-build.status').write_text(str(r.returncode)+'\n')
if r.returncode:raise SystemExit(r.returncode)
for label,binary,expected in [('baseline',build/'viboceros_smlib_tensor_bezier_baseline',0),('candidate',build/'viboceros_smlib_tensor_bezier_probe',0)]:
 with open(prefix+label+'.jsonl','w')as log,open(prefix+label+'.stderr','w')as err:r=subprocess.run([str(binary)]+(["--safe-control"]if label=="baseline"else[]),stdout=log,stderr=err)
 Path(prefix+label+'.status').write_text(str(r.returncode)+'\n')
 print(json.dumps(dict(label=label,binary=str(binary),exit_code=r.returncode)),flush=True)
 assert r.returncode==expected
asan=Path('/tmp/viboceros-isocurve-pair-asan')
with open(prefix+'asan-build.log','w')as log:
 r=subprocess.run(['cmake','-S',str(root/'crates/viboceros-smlib/native'),'-B',str(asan),'-DUSD_BREP_ROOT='+str(root/'third_party/usd-brep'),'-DVIBOCEROS_SMLIB_ASAN=ON','-DCMAKE_BUILD_TYPE=Release'],stdout=log,stderr=subprocess.STDOUT)
 if not r.returncode:r=subprocess.run(['cmake','--build',str(asan),'--target','viboceros_smlib_tensor_bezier_probe','viboceros_smlib','-j10'],stdout=log,stderr=subprocess.STDOUT)
Path(prefix+'asan-build.status').write_text(str(r.returncode)+'\n')
if r.returncode:raise SystemExit(r.returncode)
with open(prefix+'asan-flags.txt','w')as log:
 for name in ['SMLib','SM_API','viboceros_smlib','viboceros_smlib_tensor_bezier_probe']:
  s=(asan/'CMakeFiles'/(name+'.dir')/'flags.make').read_text();assert '-fsanitize=address' in s
  log.write(name+'\n'+s+'\n')
with open(prefix+'asan.jsonl','w')as log,open(prefix+'asan.stderr','w')as err:r=subprocess.run([str(asan/'viboceros_smlib_tensor_bezier_probe')],stdout=log,stderr=err,env=dict(os.environ,ASAN_OPTIONS='detect_leaks=0:halt_on_error=1'))
Path(prefix+'asan.status').write_text(str(r.returncode)+'\n')
print(json.dumps(dict(label='asan',exit_code=r.returncode)),flush=True)
assert r.returncode==0
