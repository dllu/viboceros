import json,math
from pathlib import Path
from tools.rhino_oracle.client import OracleClient
prefix='/tmp/viboceros-tensor-bezier-'
rows=[json.loads(l)for l in Path(prefix+'candidate.jsonl').read_text().splitlines()]
rows=[r for r in rows if r['fixture']in [4,9,14,15,25,27]and r['chart']==1 and r['representation']==2 and r['gauge']==1]
assert len(rows)==6
request=dict(protocol_version=1,iterations=1,operations=[]);pairs=[]
def definition(raw):
 return dict(degree_u=raw['degree'][0],degree_v=raw['degree'][1],knots_u=raw['knots'][0],knots_v=raw['knots'][1],control_point_count_u=raw['count'][0],control_point_count_v=raw['count'][1],control_points=[dict(point=[x/h[3]for x in h[:3]],weight=h[3])for h in raw['controls']])
for r in rows:
 for patch,out in enumerate(r['actual']):
  bounds=[(out['knots'][d][out['degree'][d]],out['knots'][d][out['count'][d]])for d in range(2)]
  for i in range(3):
   for j in range(3):
    identifier=f"{r['fixture']}-{patch}-{i}-{j}";pairs.append(identifier)
    for label,raw in [('source',r['source']),('native',out)]:
     request['operations'].append(dict(op='nurbs_surface_evaluate',id=identifier+'-'+label,u=bounds[0][0]+(bounds[0][1]-bounds[0][0])*i/2,v=bounds[1][0]+(bounds[1][1]-bounds[1][0])*j/2,**definition(raw)))
assert len(pairs)==144
Path(prefix+'sdk-request.json').write_text(json.dumps(request,indent=2)+'\n')
response=OracleClient(settings_scheme='VibocerosOracleTensorBezier20261018').run_rhino(request,timeout=180.)
Path(prefix+'sdk-rhino.json').write_text(json.dumps(response,indent=2)+'\n')
values={r['id']:r['value']for r in response['results']};assert len(values)==2*len(pairs)
errors={};comparisons=[]
for identifier in pairs:
 a,b=values[identifier+'-source'],values[identifier+'-native'];entry=dict(id=identifier,errors={})
 for key in ['point','derivative_u','derivative_v','normal']:
  assert len(a[key])==len(b[key])==3 and all(math.isfinite(x)for x in a[key]+b[key])
  error=max(abs(x-y)for x,y in zip(a[key],b[key]));errors[key]=max(errors.get(key,0),error);entry['errors'][key]=error
 comparisons.append(entry)
report=dict(sdk_evaluations=len(values),paired_stations=len(pairs),point_epsilon=1e-10,max_absolute_differences=errors,passed=errors['point']<=1e-10,comparisons=comparisons,scope='Public SDK evaluates complete source and native tensor Bezier definitions at identical parameters. Six unit-chart varying-weight families include degree 17, unclamped padding, and irregular knots. Derivatives and normals are diagnostic; point agreement is sampled, not a continuous bound or direct Rhino decomposition-definition parity. Independent control-net checks separately cover discontinuities, degree zero, mixed signs and extreme charts/gauges.')
Path(prefix+'sdk-report.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({k:v for k,v in report.items()if k!='comparisons'}),flush=True);assert report['passed']
