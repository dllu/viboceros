import os,subprocess,time,json
from pathlib import Path
prefix='/tmp/viboceros-fillet-command-'
env=dict(os.environ,CMAKE_BUILD_PARALLEL_LEVEL='10',CARGO_BUILD_JOBS='8')
commands=[
 ('native-app',['cargo','test','--release','-p','viboceros','--features','native-smlib','--bin','viboceros']),
 ('native-command',['cargo','test','--release','-p','viboceros-command','--features','native-smlib','--lib']),
 ('portable-command',['cargo','test','--release','-p','viboceros-command','--lib','fillet_surface']),
 ('portable-app',['cargo','test','--release','-p','viboceros','--bin','viboceros']),
 ('clippy',['cargo','clippy','--workspace','--all-targets','--all-features','--','-D','warnings']),
 ('fmt',['cargo','fmt','--all','--','--check']),
]
for name,args in commands:
 start=time.monotonic()
 with open(prefix+name+'.log','w') as log:r=subprocess.run(args,stdout=log,stderr=subprocess.STDOUT,env=env)
 result=dict(command=args,status=r.returncode,seconds=time.monotonic()-start)
 Path(prefix+name+'-runtime.json').write_text(json.dumps(result)+'\n');print(name,r.returncode,flush=True)
 if r.returncode:raise SystemExit(r.returncode)
