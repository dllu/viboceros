import gzip,hashlib,json,math,re,subprocess
from pathlib import Path
from tools.verify_provenance import verify
prefix='/tmp/viboceros-circular-rails-';artifacts={}
def retain(path,label=None):
 path=Path(path);data=path.read_bytes();label=label or path.name.removeprefix('viboceros-circular-rails-')
 dest=Path('docs/native-circular-fillet-rails-'+label+'.gz');dest.write_bytes(gzip.compress(data,mtime=0))
 artifacts[str(dest)]=hashlib.sha256(dest.read_bytes()).hexdigest()
 return dict(retained=str(dest),uncompressed_sha256=hashlib.sha256(data).hexdigest())
def rows(name):return [json.loads(line)for line in Path(prefix+name+'.jsonl').read_text().splitlines()]
base=rows('baseline');candidate=rows('candidate');asan=rows('asan-direct');fillet=rows('fillet');asan_fillet=rows('asan-fillet')
assert len(base)==len(candidate)==len(asan)==216
assert any(not r['passed']for r in base)
assert all(r['passed']for r in candidate+asan+fillet+asan_fillet)
assert len(fillet)==len(asan_fillet)==66
keys=['angle','mobius','reversed','shifted','scale','rotated','tolerance']
assert [[r[k]for k in keys]for r in base]==[[r[k]for k in keys]for r in candidate]
gates=[]
commands={
 'geometry':'cargo test --release -p viboceros-geometry --no-fail-fast -- --nocapture',
 'bridge':'cargo test --release -p viboceros-smlib --features native --no-fail-fast -- --nocapture',
 'command':'cargo test --release -p viboceros-command --features native-smlib --no-fail-fast -- --nocapture',
 'fillet-oracle':'cargo test --release -p viboceros-oracle --features native-smlib --lib surface_fillet -- --nocapture',
 'clippy':'cargo clippy --workspace --all-targets --all-features -- -D warnings',
 'fmt':'cargo fmt --all -- --check',
 'oracle-build':'cargo build --release -p viboceros-oracle --features native-smlib'}
for name in ['geometry','bridge','command','fillet-oracle','clippy','fmt','oracle-build']:
 assert Path(prefix+name+'.status').read_text().strip()=='0',name
 data=Path(prefix+name+'.log').read_text();results=re.findall(r'test result: (?:ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored;',data)
 entry=dict(name=name,command=commands[name],exit_code=0,log=retain(prefix+name+'.log'))
 if results:
  counts=list(map(sum,zip(*[list(map(int,r))for r in results])));entry.update(zip(['passed','failed','ignored'],counts));assert entry['failed']==0
 gates.append(entry)
for name in ['normal-build','candidate','fillet','compare','asan-configure','asan-build','asan-direct','asan-fillet']:
 assert Path(prefix+name+'.status').read_text().strip()=='0',name
assert Path(prefix+'baseline.status').read_text().strip()=='1'
record=dict(date='2026-10-18',baseline_commit='b0d2354baf7fe42a3b3ae66c4eab4284c36aed45',
 upstream_commit=subprocess.check_output(['git','-C','third_party/usd-brep','rev-parse','HEAD'],text=True).strip(),
 change='Remove the circular generator revolution shortcut that replaced a traced rail parameterization by a fresh rational angular chart. Keep the original rails and parent UV curves with the existing rail-constrained native loft. Preserve the ruled branch, G2 repair, production extension policy, and caller tolerances.',
 completed_runs=gates,
 direct_matrix=dict(cases=216,baseline_passed=sum(r['passed']for r in base),baseline_failed=sum(not r['passed']for r in base),candidate_passed=216,asan_passed=216,
  families='Three arc angles, three exact rational Mobius parameterizations, both directions, two parameter intervals, three spatial scales, two rigid placements. Exact source curves are expanded independently in homogeneous Bernstein form. Check same-parameter boundaries and unchanged rail geometry, then torus identity after deleting all source curves.',
  baseline_maximum_pair_gap=max(r['maximum_pair_gap']for r in base),
  candidate_maximum_pair_gap=max(r['maximum_pair_gap']for r in candidate),
  candidate_maximum_source_gap=max(r['maximum_source_gap']for r in candidate),
  candidate_maximum_torus_error=max(r['maximum_torus_error']for r in candidate),
  baseline=retain(prefix+'baseline.jsonl'),candidate=retain(prefix+'candidate.jsonl'),asan=retain(prefix+'asan-direct.jsonl'),
  baseline_control='Opt-in CMake executable overrides only the generated SmFilletStandardSolver.cpp from before the new circular patch. It retains the existing G2 patch and all other current repairs.'),
 native_fillet_matrix=dict(normal_passed=66,asan_passed=66,scope='56 existing geometry and ownership cases plus 10 invalid requests, with original 1e-8 analytic geometry acceptance. Source buffers and private parent bodies die before export; exported definitions outlive native results.',normal=retain(prefix+'fillet.jsonl'),asan=retain(prefix+'asan-fillet.jsonl')),
 sdk_comparison=json.loads(Path(prefix+'comparison.json').read_text()),
 limitations=['This repairs rail correspondence and face construction, not the production curved Extend=Yes endpoint policy or the FilletSrf command workflow.', 'A separate NL_CMAX continuation experiment is identical in its baseline and candidate executables and is not a production policy change. Its endpoint and successful-export checks are not a complete Rhino parity claim.', 'The loft may retain more control points than the old geometrically coincident revolution. No general throughput claim or compact representation guarantee.', 'ASan instruments the complete native libraries and direct probes. Leak detection is disabled; Rust gates run normally. Upstream repo.sh/prog_test, USD, Python-binding and GUI harnesses were not run.'])
for kind in ['baseline','candidate']:
 r=rows('continuation-'+kind);assert len(r)==14
 assert sum(v['status']==0 for v in r)==(2 if kind=='baseline'else 14)
 record.setdefault('experimental_continuation',{})[kind]=dict(cases=14,successes=sum(v['status']==0 for v in r),raw=retain(prefix+'continuation-'+kind+'.jsonl'))
 if kind=='candidate':
  maximum_radius_error=0;maximum_top_endpoint_error=0
  for row in r:
   bottom=[p for p in row['vertices']if abs(p[2])<=1e-8]
   top=[p for p in row['vertices']if abs(p[2]-1)<=1e-8]
   assert len(bottom)==len(top)==2
   maximum_radius_error=max(maximum_radius_error,*(abs(math.hypot(p[0],p[1])-6)for p in bottom),*(abs(math.hypot(p[0],p[1])-5)for p in top))
   maximum_top_endpoint_error=max(maximum_top_endpoint_error,*(min(math.dist(p,target)for target in [(5,0,1),(0,5,1)])for p in top))
  assert maximum_radius_error<=1e-8 and maximum_top_endpoint_error<=1e-8
  record['experimental_continuation'][kind].update(vertex_radius_tolerance=1e-8,maximum_vertex_radius_error=maximum_radius_error,maximum_top_endpoint_error=maximum_top_endpoint_error)

# Retain complete diagnostics, build output, executable commands and runtime observations.
for name in ['normal-build','baseline','candidate','fillet','compare','asan-configure','asan-build','asan-direct','asan-fillet','continuation-baseline','continuation-candidate']:
 path=Path(prefix+name+'.log')
 if path.exists():retain(path)
 runtime=Path(prefix+name+'-runtime.json')
 if runtime.exists():retain(runtime)
for name in ['mass-audit','mass-report','fillet-audit','fillet-raw-report','comparison']:
 retain(prefix+name+'.json')
for name in ['gates.py','asan.py','native.py','compare.py','continuation.py','preserve-provenance.py','record.py','stage.py']:
 retain(prefix+name)
retain(prefix+'experimental-offset.cpp')
retain('/tmp/viboceros-fillet-continuation-probe.cpp','continuation-driver.cpp')
retain('/tmp/viboceros-fillet-trace.log','initial-continuation-trace.log')
source_paths=['crates/viboceros-smlib/build.rs','crates/viboceros-smlib/native/CMakeLists.txt','crates/viboceros-smlib/tests/circular_fillet_rails.rs','third_party/patches/usd-brep-circular-fillet-rail-parameters.cmake','third_party/patches/usd-brep-circular-fillet-rail-parameters.patch','third_party/patches/usd-brep-g2-blend-rail-parameterization.patch','third_party/usd-brep/source/SMLib/src/SmFilletStandardSolver.cpp','third_party/usd-brep/source/SMLib/src/SmOffsetSurface.cpp','tools/usd_brep/circular_fillet_rails_probe.cpp','tools/usd_brep/surface_fillet_probe.cpp','README.md','docs/native-circular-fillet-rails.md','docs/native-surface-fillets.md','tools/verify_provenance.py','tools/rhino_oracle/fixtures/surface_fillet.json','tools/rhino_oracle/observations/surface_fillet.json']
record['source_sha256']={p:hashlib.sha256(Path(p).read_bytes()).hexdigest()for p in source_paths}
record['artifact_sha256']=artifacts
out=Path('docs/native-circular-fillet-rails-validation.json');out.write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps(dict(record=str(out),verified_sha256_entries=verify(record),baseline_passed=record['direct_matrix']['baseline_passed'],baseline_failed=record['direct_matrix']['baseline_failed'],candidate_passed=216,asan_passed=216,gates=gates),indent=2),flush=True)
