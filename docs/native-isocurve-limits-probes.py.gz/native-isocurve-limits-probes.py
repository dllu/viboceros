from pathlib import Path
import subprocess,os,json
root=Path('/home/dllu/proj/viboceros')
build=Path(Path('/tmp/viboceros-isocurve-limits-build-path').read_text())
with open('/tmp/viboceros-isocurve-limits-baseline-build.log','w') as log:
 r=subprocess.run(['cmake','-S',str(root/'crates/viboceros-smlib/native'),'-B',str(build),'-DUSD_BREP_ROOT='+str(root/'third_party/usd-brep')],stdout=log,stderr=subprocess.STDOUT)
 if not r.returncode:r=subprocess.run(['cmake','--build',str(build),'--target','viboceros_smlib_isocurve_limits_baseline','-j10'],stdout=log,stderr=subprocess.STDOUT)
Path('/tmp/viboceros-isocurve-limits-baseline-build.status').write_text(str(r.returncode)+'\n')
if r.returncode:raise SystemExit(r.returncode)
asan=Path('/tmp/viboceros-isocurve-pair-asan')
with open('/tmp/viboceros-isocurve-limits-asan-build.log','w') as log:
 r=subprocess.run(['cmake','--build',str(asan),'--target','viboceros_smlib_isocurve_pair_probe','viboceros_smlib','-j10'],stdout=log,stderr=subprocess.STDOUT)
Path('/tmp/viboceros-isocurve-limits-asan-build.status').write_text(str(r.returncode)+'\n')
if r.returncode:raise SystemExit(r.returncode)
with open('/tmp/viboceros-isocurve-limits-asan-flags.txt','w')as log:
 for name in ['SMLib','SM_API','viboceros_smlib','viboceros_smlib_isocurve_pair_probe']:
  flags=(asan/'CMakeFiles'/ (name+'.dir')/'flags.make').read_text()
  assert '-fsanitize=address' in flags
  log.write(name+'\n'+flags+'\n')
for label,binary,modes in [('baseline',build/'viboceros_smlib_isocurve_limits_baseline',['--limits']),('candidate',build/'viboceros_smlib_isocurve_pair_probe',['','--limits','--discontinuity','--rejection']),('asan',asan/'viboceros_smlib_isocurve_pair_probe',['','--limits','--discontinuity','--rejection'])]:
 receipts=[]
 with open('/tmp/viboceros-isocurve-limits-'+label+'.jsonl','w')as log,open('/tmp/viboceros-isocurve-limits-'+label+'.stderr','w')as err:
  for mode in modes:
   r=subprocess.run([str(binary),*([mode]if mode else[])],stdout=log,stderr=err,env=dict(os.environ,ASAN_OPTIONS='detect_leaks=0:halt_on_error=1'))
   receipts.append(dict(mode=mode,exit_code=r.returncode))
 Path('/tmp/viboceros-isocurve-limits-'+label+'.status').write_text(str(r.returncode)+'\n')
 print(json.dumps(dict(label=label,binary=str(binary),runs=receipts)),flush=True)
 assert all(x['exit_code']==(1 if label=='baseline'else 0)for x in receipts)
