import os,subprocess
from pathlib import Path
prefix='/tmp/viboceros-tensor-bezier-'
env=dict(os.environ,CMAKE_BUILD_PARALLEL_LEVEL='10',CARGO_BUILD_JOBS='8',PYTHONPATH='.')
commands=[('command',['cargo','test','--release','-p','viboceros-command','--features','native-smlib','--no-fail-fast','--','--nocapture']),('clippy',['cargo','clippy','--workspace','--all-targets','--all-features','--','-D','warnings']),('fmt',['cargo','fmt','--all','--','--check']),('replay',['python3',prefix+'replay.py'])]
for label,args in commands:
 with open(prefix+label+'.log','w')as log:r=subprocess.run(args,env=env,stdout=log,stderr=subprocess.STDOUT)
 Path(prefix+label+'.status').write_text(str(r.returncode)+'\n');print(label,r.returncode,flush=True)
 if r.returncode:raise SystemExit(r.returncode)
