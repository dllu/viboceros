import copy,json
from pathlib import Path
from tools.rhino_oracle.client import OracleClient
base=json.loads(Path('tools/rhino_oracle/fixtures/surface_fillet.json').read_text())
source=next(o for o in base['operations'] if o['id']=='cylinder-True')
ops=[]
for radius in [.25,.5,1.,2.]:
 op=copy.deepcopy(source);op['id']='radius-'+str(radius);op['radius']=radius;ops.append(op)
for which in ['plane','both']:
 op=copy.deepcopy(source);op['id']='double-'+which
 for s in op['surfaces'][:1] if which=='plane'else op['surfaces']:
  for cp in s['control_points']:cp['point']=[2*x for x in cp['point']]
 ops.append(op)
base['operations']=ops
prefix='/tmp/viboceros-fillet-extension-sdk-'
Path(prefix+'request.json').write_text(json.dumps(base,indent=2)+'\n')
r=OracleClient(settings_scheme='VibocerosOracleSurfaceFilletExtension20261018').run_rhino(base,timeout=300.)
Path(prefix+'response.json').write_text(json.dumps(r,indent=2)+'\n')
for row in r['results']:
 print(json.dumps({'id':row['id'],'outputs':[{'vertices':b['geometry']['vertices'],'area':b['area'],'bounds':b['bounds']} for b in row['value']['outputs']]}),flush=True)
