use serde_json::{Value,json};
use viboceros_geometry::{NurbsSurface,Point3,WeightedPoint3,Tolerance};
use viboceros_smlib::{SurfaceFilletOptions,fillet_surfaces,Shape};
fn point(v:&Value)->Point3 {Point3::try_new(v[0].as_f64().unwrap(),v[1].as_f64().unwrap(),v[2].as_f64().unwrap()).unwrap()}
fn surface(s:&Value,capture:bool)->NurbsSurface {
 let n=|key:&str,i:usize|if capture{s[key][i].as_u64().unwrap()as usize}else{let key=match(key,i){("degree",0)=>"degree_u",("degree",_)=>"degree_v",("control_count",0)=>"control_point_count_u",_=>"control_point_count_v"};s[key].as_u64().unwrap()as usize};
 NurbsSurface::try_new_rational(n("degree",0),n("degree",1),n("control_count",0),n("control_count",1),s["control_points"].as_array().unwrap().iter().map(|p|WeightedPoint3::try_new(point(&p["point"]),p["weight"].as_f64().unwrap()).unwrap()).collect(),s["knots_u"].as_array().unwrap().iter().map(|k|k.as_f64().unwrap()).collect(),s["knots_v"].as_array().unwrap().iter().map(|k|k.as_f64().unwrap()).collect()).unwrap()
}
fn projection(s:&NurbsSurface,p:Point3,t:Tolerance)->Point3 {let(u,v)=s.closest_parameters(p,t).unwrap();s.evaluate(u,v).unwrap()}
fn main(){
 let request:Value=serde_json::from_slice(&std::fs::read("tools/rhino_oracle/fixtures/surface_fillet_picks.json").unwrap()).unwrap();let sdk:Value=serde_json::from_slice(&std::fs::read("tools/rhino_oracle/observations/surface_fillet_picks.json").unwrap()).unwrap();let tol=Tolerance::try_new(1e-8,1e-12,1e-8).unwrap();
 for op in request["operations"].as_array().unwrap(){
  let parents=op["surfaces"].as_array().unwrap().iter().map(|s|surface(s,false)).collect::<Vec<_>>();let picks=std::array::from_fn(|i|std::array::from_fn(|j|op["picks"][i][j].as_f64().unwrap()));let options=SurfaceFilletOptions::try_from_picks(&parents[0],&parents[1],picks,0.75,false,tol).unwrap();let b=fillet_surfaces(&parents[0],&parents[1],options,tol).unwrap().unwrap();
  let e=&sdk["results"].as_array().unwrap().iter().find(|r|r["id"]==op["id"]).unwrap()["value"]["outputs"][0];let es=surface(&e["geometry"]["faces"][0]["definition"],true);let ns=b.faces()[0].surface();let bb=Shape::from_brep(&b,tol).unwrap().tight_bounds().unwrap();let mut max_bounds:f64=0.;for(a,v)in [bb.min(),bb.max()].into_iter().zip(e["bounds"].as_array().unwrap()){max_bounds=max_bounds.max(a.distance_to(point(v)).unwrap());}
  let(mut coordinate_gap,mut distance_gap,mut sdk_points_to_native,mut native_grid_to_sdk,mut sdk_grid_to_native)=(0_f64,0_f64,0_f64,0_f64,0_f64);
  for(q,e)in op["queries"].as_array().unwrap().iter().zip(e["closest_points"].as_array().unwrap()) {let q=point(q);let ep=point(e);let(face,u,v)=b.closest_face_parameters(q,tol).unwrap().unwrap();let p=b.faces()[face].surface().evaluate(u,v).unwrap();for(x,y)in p.to_array().iter().zip(ep.to_array()){coordinate_gap=coordinate_gap.max((x-y).abs());}distance_gap=distance_gap.max((p.distance_to(q).unwrap()-ep.distance_to(q).unwrap()).abs());sdk_points_to_native=sdk_points_to_native.max(projection(ns,ep,tol).distance_to(ep).unwrap());}
  for i in 0..=8 {for j in 0..=8 {let p=ns.evaluate(ns.parameter_at_u(i as f64/8.).unwrap(),ns.parameter_at_v(j as f64/8.).unwrap()).unwrap();native_grid_to_sdk=native_grid_to_sdk.max(projection(&es,p,tol).distance_to(p).unwrap());}}
  for p in e["geometry"]["faces"][0]["samples"].as_array().unwrap(){let p=point(p);sdk_grid_to_native=sdk_grid_to_native.max(projection(ns,p,tol).distance_to(p).unwrap());}
  println!("{}",json!({"id":op["id"],"coordinate_gap":coordinate_gap,"distance_gap":distance_gap,"sdk_points_to_native":sdk_points_to_native,"native_grid_to_sdk":native_grid_to_sdk,"sdk_grid_to_native":sdk_grid_to_native,"bounds_gap":max_bounds,"sides":format!("{:?}",options.sides)}));
 }
}
