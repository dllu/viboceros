import json,time
from pathlib import Path
from tools.rhino_oracle.client import OracleClient
from tools.rhino_oracle.structural_sdk import validate_operations
p='/tmp/viboceros-reparameterize-input-'
root=Path('tools/rhino_oracle/fixtures/reparameterize_input').resolve();root.mkdir(exist_ok=True)
recipes=[('cylinder_defaults','cylinder',[0,1,2,3]),('annulus_defaults','annulus',[0,1,2,3]),('sphere_mixed','sphere',[1,2]),('box_face_mixed','box_2',[0,2]),('reversed_trim_mixed','reversed_rectangle',[2,3])]
q=dict(protocol_version=1,iterations=1,tolerance=dict(absolute=1e-8,relative=1e-12,angular=1e-8),operations=[dict(op='reparameterize_face_command',id=name,family=family,domains=[[-2.,8.],[10.,30.]],default_indices=defaults,artifact_path=str(root/(name+'.3dm'))) for name,family,defaults in recipes])
validate_operations(q)
Path(p+'request.json').write_text(json.dumps(q,indent=2)+'\n');t=time.monotonic()
r=OracleClient(settings_scheme='VibocerosOracleReparameterizeInput20261018').run_rhino(q,timeout=300.)
Path(p+'response.json').write_text(json.dumps(r,indent=2)+'\n')
Path(p+'sdk-runtime.json').write_text(json.dumps(dict(seconds=time.monotonic()-t,recipes=len(recipes)))+'\n')
for row in r['results']:
 print(row['id'],row['value']['success'],row['value']['domains'],row['value']['inputs'],flush=True)
