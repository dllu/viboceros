import json,math
from pathlib import Path
from tools.rhino_oracle.client import OracleClient
prefix='/tmp/viboceros-basis-evaluation-'
rows=[json.loads(l)for l in Path(prefix+'candidate.jsonl').read_text().splitlines()]
rows=[r for r in rows if r['case']<=7 and r['right_limit'] and (r['chart']==1 or (r['chart']==3 and r['case']in [5,6,7]))]
assert len(rows)==44
request=dict(protocol_version=1,iterations=1,operations=[])
expected={}
for index,r in enumerate(rows):
 n=len(r['knots'])-r['degree']-1
 controls=[dict(point=[2.*i,float(i*i),float(i%3-1)],weight=1.+(3*i%4)/4.)for i in range(n)]
 identifier='basis-curve-'+str(index)
 request['operations'].append(dict(op='nurbs_curve_evaluate',id=identifier,degree=r['degree'],knots=r['knots'],control_points=controls,parameter=r['parameter']))
 expected[identifier]=dict(point=r['curves'][0]['actual_point'],derivative=r['curves'][0]['actual_first_derivative_normalized'])
 identifier='basis-surface-'+str(index)
 top=[dict(point=[p['point'][0]+3,p['point'][1]-2,p['point'][2]+5],weight=2*p['weight'])for p in controls]
 request['operations'].append(dict(op='nurbs_surface_evaluate',id=identifier,degree_u=r['degree'],degree_v=1,control_point_count_u=n,control_point_count_v=2,knots_u=r['knots'],knots_v=[-3,-3,5,5],control_points=controls+top,u=r['parameter'],v=-1))
 expected[identifier]=dict(point=r['curves'][0]['actual_surface_point'])
Path(prefix+'sdk-request.json').write_text(json.dumps(request,indent=2)+'\n')
response=OracleClient(settings_scheme='VibocerosOracleBasisEvaluation20261018').run_rhino(request,timeout=180.)
Path(prefix+'sdk-rhino.json').write_text(json.dumps(response,indent=2)+'\n')
assert len(response['results'])==len(request['operations'])==88
errors=dict(curve_point=0.,curve_derivative=0.,surface_point=0.)
comparisons=[]
for r in response['results']:
 want=expected[r['id']];actual=r['value'];station=dict(id=r['id'],errors={})
 for key,point in want.items():
  label=('surface_'if r['id'].startswith('basis-surface-')else'curve_')+key
  difference=max(abs(x-y)for x,y in zip(point,actual[key]));assert all(math.isfinite(x)for x in point+actual[key])
  errors[label]=max(errors[label],difference);station['errors'][key]=difference
 comparisons.append(station)
report=dict(sdk_evaluations=88,curve_stations=44,surface_stations=44,absolute_epsilon=1e-10,max_absolute_differences=errors,comparisons=comparisons,passed=max(errors.values())<=1e-10,
 scope='Continuous degree 1/2/3/5/17 sources at unit scale, plus three unclamped families translated to 1e12; gauge 1. Exact stored knots and parameters, no normalization. Surface comparison covers points only. Small/large chart scales, full-order breaks, inactive padding and higher derivatives use the independent polynomial checks, not this SDK capture.')
Path(prefix+'sdk-report.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({k:v for k,v in report.items()if k!='comparisons'}),flush=True);assert report['passed']
