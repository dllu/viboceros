import os,subprocess,json
from pathlib import Path
root=Path.cwd();prefix='/tmp/viboceros-surface-fillet-'
for label,build,sanitize in [('normal',Path('target/debug/build/viboceros-smlib-e982af202de3f65b/out/build'),False),('asan',Path('/tmp/viboceros-isocurve-pair-asan'),True)]:
 with open(prefix+label+'-build.log','w')as log:
  result=subprocess.run(['cmake','-S','crates/viboceros-smlib/native','-B',str(build),'-DUSD_BREP_ROOT='+str(root/'third_party/usd-brep'),'-DVIBOCEROS_SMLIB_ASAN='+('ON'if sanitize else'OFF'),'-DCMAKE_BUILD_TYPE=Release'],stdout=log,stderr=subprocess.STDOUT)
  if not result.returncode:result=subprocess.run(['cmake','--build',str(build),'--target','viboceros_smlib_surface_fillet_probe','-j10'],stdout=log,stderr=subprocess.STDOUT)
 Path(prefix+label+'-build.status').write_text(str(result.returncode)+'\n');assert result.returncode==0,label
 with open(prefix+label+'.jsonl','w')as log,open(prefix+label+'.stderr','w')as err:
  result=subprocess.run([str(build/'viboceros_smlib_surface_fillet_probe')],stdout=log,stderr=err,env=dict(os.environ,ASAN_OPTIONS='detect_leaks=0:halt_on_error=1'),timeout=120)
 Path(prefix+label+'.status').write_text(str(result.returncode)+'\n');print(label,result.returncode,flush=True);assert result.returncode==0,label
 if sanitize:
  with open(prefix+'asan-flags.txt','w')as log:
   for name in ['SMLib','SM_API','viboceros_smlib','viboceros_smlib_surface_fillet_probe']:
    flags=(build/'CMakeFiles'/(name+'.dir')/'flags.make').read_text();assert '-fsanitize=address'in flags;log.write(name+'\n'+flags+'\n')

with open(prefix+'baseline.log','w') as log:
 result=subprocess.run(['python3',prefix+'baseline.py'],stdout=log,stderr=subprocess.STDOUT)
Path(prefix+'baseline-run.status').write_text(str(result.returncode)+'\n');assert result.returncode==0
