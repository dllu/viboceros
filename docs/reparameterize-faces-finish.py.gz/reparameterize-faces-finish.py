import json,os,subprocess,time
from pathlib import Path
p='/tmp/viboceros-reparameterize-faces-';args=['cargo','test','--release','-p','viboceros-command','--test','reparameterize_faces'];t=time.monotonic()
with open(p+'portable-replay.log','w')as out:r=subprocess.run(args,stdout=out,stderr=subprocess.STDOUT,env=dict(os.environ,CARGO_BUILD_JOBS='8'))
Path(p+'portable-replay-runtime.json').write_text(json.dumps(dict(command=args,status=r.returncode,seconds=time.monotonic()-t))+'\n')
if r.returncode:raise SystemExit(r.returncode)
for name in ['preserve-provenance','record']:
 with open(p+name+'.log','w')as out:r=subprocess.run(['python3',p+name+'.py'],env=dict(os.environ,PYTHONPATH='.'),stdout=out,stderr=subprocess.STDOUT)
 if r.returncode:raise SystemExit(r.returncode)
