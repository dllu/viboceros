import json
from pathlib import Path
from tools.rhino_oracle.client import OracleClient


class RecordingClient(OracleClient):
    def run_viboceros_audit(self, request, timeout=180.):
        response = super().run_viboceros_audit(request, timeout)
        self.response = response
        return response


client = RecordingClient(native_smlib=True)
stem = 'join_curved_certificates'
request = json.loads(Path('tools/rhino_oracle/fixtures/' + stem + '.json').read_text())
reference = json.loads(Path('tools/rhino_oracle/observations/' + stem + '.json').read_text())
report = client.replay(request, reference, timeout=1800.)
Path('/tmp/viboceros-stitch-uv-curved-audit.json').write_text(json.dumps(client.response, indent=2) + '\n')
Path('/tmp/viboceros-stitch-uv-curved-report.json').write_text(json.dumps(report.as_dict(), indent=2) + '\n')
assert len(client.response['outcomes']) == 48
assert all(row['status'] == 'success' for row in client.response['outcomes'])
unclamped = [row for row in client.response['outcomes'] if row['result']['id'].startswith('unclamped-')]
assert len(unclamped) == 8
assert all(row['result']['value']['succeeded'] for row in unclamped)
print(json.dumps(dict(fixture=stem, executed=48, execution_errors=report.native_failed,
                      raw_matches=report.matched, raw_mismatches=48-report.matched,
                      unclamped_join_successes=8)), flush=True)

stem = 'join_isocurve_certificates'
request = json.loads(Path('tools/rhino_oracle/fixtures/' + stem + '.json').read_text())
def no_artifacts(value):
    if isinstance(value, dict):
        assert 'artifact_path' not in value
        for child in value.values(): no_artifacts(child)
    elif isinstance(value, list):
        for child in value: no_artifacts(child)
no_artifacts(request)
response = client.run_viboceros_audit(request, timeout=1800.)
Path('/tmp/viboceros-stitch-uv-isocurve-audit.json').write_text(json.dumps(response, indent=2) + '\n')
assert len(response['outcomes']) == 64
failures = [r for r in response['outcomes'] if r['status'] == 'failure']
successes = [r for r in response['outcomes'] if r['status'] == 'success']
print(json.dumps(dict(fixture=stem, executed=len(successes), execution_errors=len(failures),
                      failed_cases=failures,
                      unclamped_join_successes=sum('unclamped-' in r['result']['id'] and r['result']['value']['succeeded']
                                                   for r in successes))), flush=True)
