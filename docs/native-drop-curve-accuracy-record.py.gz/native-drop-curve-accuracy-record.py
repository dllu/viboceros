import gzip,hashlib,json,re,subprocess
from pathlib import Path
from tools.verify_provenance import verify
BASE='e4bd95e00761c57e66e0974488d46d3ab4da355b';TEMP='/tmp/viboceros-drop-accuracy-';DEST='docs/native-drop-curve-accuracy-'
assert subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()==BASE
sha=lambda data:hashlib.sha256(data).hexdigest();artifacts={}
def retain(name,source=None):
 data=Path(source or TEMP+name).read_bytes();path=DEST+name+'.gz';Path(path).write_bytes(gzip.compress(data,mtime=0));artifacts[path]=sha(Path(path).read_bytes());return dict(retained=path,uncompressed_sha256=sha(data))
def run(name,command,tests=False):
 code=int(Path(TEMP+name+'.status').read_text());assert code==0,(name,code)
 result=dict(command=command,exit_code=code,log=retain(name+'.log'))
 if tests:
  groups=re.findall(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored;',Path(TEMP+name+'.log').read_text());assert groups
  result.update(zip(['passed','failed','ignored'],[sum(int(v[i])for v in groups)for i in range(3)]))
 return result
runs=[run('focused','cargo test --release -p viboceros-smlib --features native --test surface_fillets -- --nocapture',True),run('bridge','cargo test --release -p viboceros-smlib --features native --no-fail-fast -- --nocapture',True),run('command','cargo test --release -p viboceros-command --features native-smlib --no-fail-fast -- --nocapture',True),run('fillet-oracle','cargo test --release -p viboceros-oracle --features native-smlib --lib surface_fillet -- --nocapture',True),run('clippy','cargo clippy --workspace --all-targets --all-features -- -D warnings'),run('fmt','cargo fmt --all -- --check'),run('oracle-build','cargo build --release -p viboceros-oracle --features native-smlib')]
assert runs[1]['passed']==430 and runs[2]['passed']==1600
probes={}
for label,expected in [('baseline',18),('normal',270),('asan',270)]:
 rows=[json.loads(l)for l in Path(TEMP+label+'.jsonl').read_text().splitlines()]
 code=int(Path(TEMP+label+'.status').read_text());assert len(rows)==270 and sum(x['passed']for x in rows)==expected and code==(1 if label=='baseline'else 0)
 probes[label]=dict(exit_code=code,cases=270,passed=expected,failed=270-expected,maximum_normalized_lateral_error=max(x['maximum_lateral_error']/x['scale']for x in rows),caller_normalized_tolerance=1e-8,source_unchanged=all(x['source_unchanged']for x in rows),raw=retain(label+'.jsonl'),stderr=retain(label+'.stderr'))
probes['asan']['runtime']=json.loads(Path(TEMP+'asan-runtime.json').read_text())
probes['asan']['flags']=retain('asan-flags.txt')
for label in ['normal','asan']:
 assert int(Path(TEMP+label+'-build.status').read_text())==0
 probes[label]['build_log']=retain(label+'-build.log')
initial=json.loads(Path(TEMP+'asan-initial.json').read_text());assert initial['outcome']=='runner_timeout'
initial['raw']=retain('asan-initial.jsonl');initial['stderr']=retain('asan-initial.stderr')
fillet=dict(summary=json.loads(Path(TEMP+'fillet-trims-summary.json').read_text()),runner=retain('fillets.py'),driver=retain('fillet-trims.cpp','/tmp/viboceros-fillet-trims-diagnostic.cpp'),build_log=retain('fillet-trims-build.log'),previous=retain('fillet-trims-previous.jsonl','/tmp/viboceros-fillet-trims-diagnostic.jsonl'),repaired=retain('fillet-trims.jsonl'),stderr=retain('fillet-trims.stderr'),analysis=retain('fillet-trims-analysis.json'),analysis_log=retain('fillet-trims-analysis.log'),inspector=retain('fillet-trims-inspect.py'),previous_analysis=retain('fillet-trims-previous-analysis.json','/tmp/viboceros-fillet-trims-stations-analysis.json'))
fillet_probes={}
for label in ['normal','asan']:
 rows=[json.loads(x)for x in Path(TEMP+'fillet-'+label+'.jsonl').read_text().splitlines()]
 assert int(Path(TEMP+'fillet-'+label+'.status').read_text())==0 and len(rows)==66 and all(x['passed']for x in rows)
 fillet_probes[label]=dict(exit_code=0,geometry_and_lifetime_cases=56,rejected_requests=10,maximum_sampled_analytic_error=max(x.get('maximum_geometry_error',0)for x in rows),raw=retain('fillet-'+label+'.jsonl'),stderr=retain('fillet-'+label+'.stderr'),build_log=retain('fillet-'+label+'-build.log'))
fillet_probes['runner']=retain('fillet-probes.py')
comparison=json.loads(Path(TEMP+'comparison.json').read_text())
for name in ['contact-audit','contact-report','fillet-audit','fillet-raw-report']:
 comparison[name]=retain(name+'.json')
comparison['runner']=retain('compare.py');comparison['log']=retain('compare.log')
runners={name:retain(name)for name in ['gates.py','probes.py','asan-run.py','record.py','preserve-provenance.py','provenance.log','after-gates.py']}
normal=Path('target/debug/build/viboceros-smlib-e982af202de3f65b/out/build/usd-brep-patched/SmSurfaceDropLib.cpp');asan=Path('/tmp/viboceros-isocurve-pair-asan/usd-brep-patched/SmSurfaceDropLib.cpp');assert normal.read_bytes()==asan.read_bytes()
sources=['crates/viboceros-smlib/build.rs','crates/viboceros-smlib/native/CMakeLists.txt','third_party/patches/usd-brep-drop-curve-accuracy.patch','third_party/patches/usd-brep-drop-curve-accuracy.cmake','tools/usd_brep/drop_curve_accuracy_probe.cpp','third_party/usd-brep/source/SMLib/src/SmSurfaceDropLib.cpp','third_party/usd-brep/source/SMLib/src/SmCurveClass.cpp','third_party/usd-brep/source/SMLib/src/SmCrvOnSurf.cpp','third_party/usd-brep/source/SMLib/src/SmHermiteCurve.cpp']
for path in ['README.md','docs/native-drop-curve-accuracy.md']:
 artifacts[path]=sha(Path(path).read_bytes())
record=dict(date='2026-10-18',baseline_commit=BASE,upstream_commit=subprocess.check_output(['git','-C','third_party/usd-brep','rev-parse','HEAD'],text=True).strip(),change='Remove the short-parameter-span override of failed UV accuracy tests, retain original Hermite stations, test crossed surface knot spans without boundary merging, validate actual source knots in the isoparametric shortcut, and stop subdivision without representable progress. Preserve defining 3D geometry and the caller distance tolerance.',completed_runs=runs,execution_environment='CMAKE_BUILD_PARALLEL_LEVEL=10 CARGO_BUILD_JOBS=8. Cargo gates sequential; separate preexisting normal/manual and ASan native build trees. No Wine, FEX, launcher or licensing changes.',direct_probes=probes,initial_incomplete_asan_attempt=initial,fillet_cap_diagnostic=fillet,shared_fillet_probes=fillet_probes,saved_sdk_audits=comparison,runner_scripts=runners,historical_provenance=json.loads(Path(TEMP+'provenance.log').read_text()),generated_source_sha256=sha(normal.read_bytes()),validation_selection=dict(guides=['third_party/usd-brep/.agents/skills/smlib-kernel-drop-curve/SKILL.md','third_party/usd-brep/.agents/skills/usd-brep-test-selection/SKILL.md'],rationale='Independent exact polynomial drop family exercises short spans and off-grid narrow features, scales, orientations, source purity and ownership; identical pinned-source baseline and complete-library ASan; four actual fillet cap before/after snapshots; existing fillet/bridge/command callers; saved complete SDK protocol values; workspace lint and formatting.',not_run='Upstream repo.sh/prog_test, USD, Python-binding, OCCT and GUI harnesses. No new SDK capture required for unchanged recipes; saved SDK captures remain raw and hash-pinned.'),limitations=['Tests are sampled; general drop completeness, a continuous global error guarantee and performance are unqualified. Native surface and curve knot queries/intersections retain their existing numerical limits.','Curved ExtendYes surface fillets, support continuation, boundary policy, FilletSrf picking, source trimming, joining and document/preview workflow remain in progress. Actual current execution failures and raw SDK mismatches are retained.','ASan instruments SMLib, SM_API, the bridge and the direct native matrix. Rust caller gates run normally. Leak detection is disabled; the initial 120-second runner timeout is retained as incomplete and is not a passing run.'],source_sha256={name:sha(Path(name).read_bytes())for name in sources},artifact_sha256=artifacts,baseline_git_sha256={BASE+':'+name:sha(subprocess.check_output(['git','cat-file','blob',BASE+':'+name]))for name in ['crates/viboceros-smlib/build.rs','crates/viboceros-smlib/native/CMakeLists.txt','tools/usd_brep/surface_fillet_probe.cpp','crates/viboceros-smlib/src/native/surface_fillet.rs','tools/rhino_oracle/fixtures/surface_fillet.json','tools/rhino_oracle/observations/surface_fillet.json','tools/rhino_oracle/fixtures/curve_contacts_tolerance.json','tools/rhino_oracle/observations/curve_contacts_tolerance.json']})
Path('docs/native-drop-curve-accuracy-validation.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps(dict(hashes=verify(record),test_totals=[{k:v for k,v in r.items()if k in ['passed','failed','ignored']}for r in runs],native_cases={k:v['passed']for k,v in probes.items()},fillet_followup=comparison['fillet_followup'])),flush=True)
