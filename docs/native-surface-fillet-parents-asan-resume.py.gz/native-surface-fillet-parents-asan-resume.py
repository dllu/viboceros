import os,subprocess,json,time
from pathlib import Path
p='/tmp/viboceros-fillet-parents-';b='/tmp/viboceros-isocurve-pair-asan';env=dict(os.environ,ASAN_OPTIONS='detect_leaks=0:abort_on_error=1')
commands=[('asan-configure',['cmake','-S','crates/viboceros-smlib/native','-B',b,'-DUSD_BREP_ROOT='+str(Path('third_party/usd-brep').resolve()),'-DVIBOCEROS_SMLIB_ASAN=ON','-DCMAKE_BUILD_TYPE=Release']),('asan-build',['cmake','--build',b,'--parallel','5','--target','viboceros_smlib_surface_fillet_parents_probe','viboceros_smlib_surface_fillet_probe']),('asan-parents',[b+'/viboceros_smlib_surface_fillet_parents_probe']),('asan-original',[b+'/viboceros_smlib_surface_fillet_probe'])]
for name,args in commands[1:]:
 start=time.monotonic()
 with open(p+name+'.log','w')as log,open(p+name+'.jsonl','w')as out:r=subprocess.run(args,stdout=out if name in ['asan-parents','asan-original']else log,stderr=log,env=env)
 Path(p+name+'.status').write_text(str(r.returncode)+'\n');Path(p+name+'-runtime.json').write_text(json.dumps(dict(command=args,status=r.returncode,seconds=time.monotonic()-start))+'\n');print(name,r.returncode,flush=True)
 if r.returncode:raise SystemExit(r.returncode)
