import subprocess
from pathlib import Path
root=Path.cwd();b=root/'target/release/build/viboceros-smlib-d4f77638f5302455/out/build';prefix='/tmp/viboceros-fillet-g2-prototype'
s=(root/'third_party/usd-brep/source/SMLib/src/SmOffsetSurface.cpp').read_text();needle='gflg, cflg = NL_G1R;';assert s.count(needle)==1
source=Path(prefix+'.cpp');source.write_text(s.replace(needle,'gflg, cflg = NL_G2;'))
flags=['c++','-std=c++17','-O1','-DNDEBUG','-DNOMINMAX','-DSM_GRAPHICS_CALLBACKS=1','-DVIBOCEROS_CURVE_INTERSECTION_DISTANCE_PATCH=1','-w','-I',str(root/'crates/viboceros-smlib/native'),'-I',str(b/'usd-brep-patched'),'-I',str(root/'third_party/usd-brep/source/SM_API/inc'),'-I',str(root/'third_party/usd-brep/source/SMLib/inc'),'-include',str(root/'third_party/usd-brep/source/SMLib/inc/StdAfx.h')]
subprocess.run(flags+['-c',str(source),'-o',prefix+'.o'],check=True)
subprocess.run(flags+['/tmp/viboceros-fillet-continuation-probe.cpp',prefix+'.o',str(b/'libviboceros_smlib.a'),str(b/'libSM_API.a'),str(b/'libSMLib.a'),'-ltbb','-ltbbmalloc','-o',prefix],check=True)
with open(prefix+'.jsonl','w')as out,open(prefix+'.log','w')as log:subprocess.run([prefix],stdout=out,stderr=log,check=True)
