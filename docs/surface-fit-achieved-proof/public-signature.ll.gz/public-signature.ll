; ModuleID = 'tools/rhino_oracle/public_surface_fit_signature.cpp'
source_filename = "tools/rhino_oracle/public_surface_fit_signature.cpp"
target datalayout = "e-m:w-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-pc-windows-msvc19.33.0"

@"?fit@@3P6APEAVON_Surface@@AEBV1@HHNPEAN@ZEA" = dso_local global ptr null, align 8
@llvm.global_ctors = appending global [1 x { i32, ptr, ptr }] [{ i32, ptr, ptr } { i32 65535, ptr @_GLOBAL__sub_I_public_surface_fit_signature.cpp, ptr null }]

; Function Attrs: noinline uwtable
define internal void @"??__Efit@@YAXXZ"() #0 {
  store ptr @"?RhinoFitSurface@@YAPEAVON_Surface@@AEBV1@HHNPEAN@Z", ptr @"?fit@@3P6APEAVON_Surface@@AEBV1@HHNPEAN@ZEA", align 8
  ret void
}

declare dllimport noundef ptr @"?RhinoFitSurface@@YAPEAVON_Surface@@AEBV1@HHNPEAN@Z"(ptr noundef nonnull align 1, i32 noundef, i32 noundef, double noundef, ptr noundef) #1

; Function Attrs: noinline uwtable
define internal void @_GLOBAL__sub_I_public_surface_fit_signature.cpp() #0 {
  call void @"??__Efit@@YAXXZ"()
  ret void
}

attributes #0 = { noinline uwtable "min-legal-vector-width"="0" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #1 = { "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }

!llvm.module.flags = !{!0, !1, !2, !3}
!llvm.ident = !{!4}

!0 = !{i32 1, !"wchar_size", i32 2}
!1 = !{i32 8, !"PIC Level", i32 2}
!2 = !{i32 7, !"uwtable", i32 2}
!3 = !{i32 1, !"MaxTLSAlign", i32 65536}
!4 = !{!"Ubuntu clang version 18.1.3 (1ubuntu1)"}
