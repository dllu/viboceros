from pathlib import Path
import subprocess
root=Path('/home/dllu/proj/viboceros')
builds=list((root/'target/debug/build').glob('viboceros-smlib-*/out/build/viboceros_smlib_isocurve_pair_probe'))
assert builds
build=max(builds,key=lambda p:p.stat().st_mtime).parent
with Path('/tmp/viboceros-isocurve-pair-baseline-build.log').open('w') as f:
 code=subprocess.run(['cmake','-S',str(root/'crates/viboceros-smlib/native'),'-B',str(build),'-DUSD_BREP_ROOT='+str(root/'third_party/usd-brep')],stdout=f,stderr=subprocess.STDOUT).returncode
 if code==0:
  code=subprocess.run(['cmake','--build',str(build),'--target','viboceros_smlib_isocurve_pair_baseline','-j10'],stdout=f,stderr=subprocess.STDOUT).returncode
Path('/tmp/viboceros-isocurve-pair-baseline-build.status').write_text(str(code)+'\n')
if code:raise SystemExit(code)
with Path('/tmp/viboceros-isocurve-pair-baseline.jsonl').open('w') as f, Path('/tmp/viboceros-isocurve-pair-baseline.stderr').open('w') as e:
 code=subprocess.run([str(build/'viboceros_smlib_isocurve_pair_baseline')],stdout=f,stderr=e).returncode
Path('/tmp/viboceros-isocurve-pair-baseline.status').write_text(str(code)+'\n')
print(str(build),code,flush=True)
raise SystemExit(code)
