//! A floating grid can reject a map proposal, never certify a surface image.
use super::*;
use crate::ParameterSide;

pub(super) fn within(a: &NurbsSurface, b: &NurbsSurface, maps: &Maps, limit: Real) -> bool {
    let stations: [Vec<[Real; 2]>; 2] = maps.each_ref().map(|pairs| {
        let mut values = vec![pairs[0]];
        for pair in pairs.windows(2) {
            values.push(std::array::from_fn(|i| pair[0][i].midpoint(pair[1][i])));
            values.push(pair[1]);
        }
        values
    });
    let parameters = |s: &NurbsSurface, which: usize| -> Option<[Vec<(Real, ParameterSide)>; 2]> {
        Some([
            stations[0]
                .iter()
                .map(|p| Some((s.parameter_at_u(p[which]).ok()?, ParameterSide::Right)))
                .collect::<Option<_>>()?,
            stations[1]
                .iter()
                .map(|p| Some((s.parameter_at_v(p[which]).ok()?, ParameterSide::Right)))
                .collect::<Option<_>>()?,
        ])
    };
    let (Some(u), Some(v)) = (parameters(a, 0), parameters(b, 1)) else {
        return false;
    };
    let nu = stations[0].len();
    let mut points = vec![None; nu * stations[1].len()];
    if a.try_for_each_grid_point_on_sides(&u[0], &u[1], |i, j, p| {
        points[j * nu + i] = Some(p.map_err(|_| ())?);
        Ok::<_, ()>(())
    })
    .is_err()
    {
        return false;
    }
    b.try_for_each_grid_point_on_sides(&v[0], &v[1], |i, j, p| {
        let distance = points[j * nu + i]
            .ok_or(())?
            .distance_to(p.map_err(|_| ())?)
            .map_err(|_| ())?;
        if distance > limit * 1.001 {
            return Err(());
        }
        Ok(())
    })
    .is_ok()
}
