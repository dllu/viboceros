import json,os,subprocess,time,sys
from pathlib import Path
p='/tmp/viboceros-reparameterize-input-'
env=dict(os.environ,CARGO_BUILD_JOBS='8',CMAKE_BUILD_PARALLEL_LEVEL='10')
commands=[('ui-final',['cargo','test','-p','viboceros','app::tests::reparameterize','--','--nocapture']),('ui-native',['cargo','test','-p','viboceros','--features','native-smlib','app::tests::reparameterize','--','--nocapture']),('viewport-picking',['cargo','test','-p','viboceros','viewport::picking::']),('viewport-clipping',['cargo','test','-p','viboceros','viewport::clip_tests::']),('clippy',['cargo','clippy','--workspace','--all-targets','--all-features','--','-D','warnings']),('check',['cargo','check','--workspace','--all-targets']),('fmt',['cargo','fmt','--all','--','--check']),('python',['python3','-m','unittest','tools.rhino_oracle.test_reparameterize_face_probe','tools.rhino_oracle.test_surface_fillet_probe','tools.rhino_oracle.test_structural_sdk'])]
if len(sys.argv)>1:commands=commands[[n for n,args in commands].index(sys.argv[1]):]
for name,args in commands:
 t=time.monotonic()
 with open(p+name+'.log','w')as out:r=subprocess.run(args,env=env,stdout=out,stderr=subprocess.STDOUT)
 Path(p+name+'-runtime.json').write_text(json.dumps(dict(command=args,status=r.returncode,seconds=time.monotonic()-t))+'\n')
 print(name,r.returncode,flush=True)
 if r.returncode:raise SystemExit(r.returncode)
