import json,os,subprocess,time
from pathlib import Path
prefix='/tmp/viboceros-circular-rails-'
build=Path('target/release/build/viboceros-smlib-d4f77638f5302455/out/build')
env=dict(os.environ,PYTHONPATH='.')
commands=[('normal-build',['cmake','--build',str(build),'--parallel','8','--target','viboceros_smlib_circular_fillet_rails_baseline','viboceros_smlib_surface_fillet_probe']),('baseline',[str(build/'viboceros_smlib_circular_fillet_rails_baseline')]),('candidate',[str(build/'viboceros_smlib_circular_fillet_rails_probe')]),('fillet',[str(build/'viboceros_smlib_surface_fillet_probe')]),('compare',['python3',prefix+'compare.py'])]
for name,args in commands:
 if name=='compare':
  while not Path(prefix+'oracle-build.status').exists():
   for gate in ['command','fillet-oracle','clippy','fmt']:
    gate_status=Path(prefix+gate+'.status')
    if gate_status.exists() and gate_status.read_text().strip()!='0':raise RuntimeError(gate+' failed')
   time.sleep(2)
  assert Path(prefix+'oracle-build.status').read_text().strip()=='0'
 start=time.monotonic()
 with open(prefix+name+'.log','w')as log:
  with open(prefix+name+'.jsonl','w')as out:r=subprocess.run(args,stdout=out if name in ['baseline','candidate','fillet']else log,stderr=log,env=env)
 Path(prefix+name+'.status').write_text(str(r.returncode)+'\n')
 Path(prefix+name+'-runtime.json').write_text(json.dumps(dict(command=args,seconds=time.monotonic()-start,status=r.returncode))+'\n')
 print(name,r.returncode,flush=True)
 if r.returncode and not(name=='baseline'and r.returncode==1):raise SystemExit(r.returncode)

subprocess.run(['python3',prefix+'continuation.py'],check=True)
