import os,subprocess,json,time
from pathlib import Path
p='/tmp/viboceros-fillet-parents-';env=dict(os.environ,CMAKE_BUILD_PARALLEL_LEVEL='10',CARGO_BUILD_JOBS='8')
commands=[
('fillet-oracle',['cargo','test','--release','-p','viboceros-oracle','--features','native-smlib','--lib','surface_fillet','--','--nocapture']),
('bridge',['cargo','test','--release','-p','viboceros-smlib','--features','native','--no-fail-fast','--','--nocapture']),
('command',['cargo','test','--release','-p','viboceros-command','--features','native-smlib','--no-fail-fast','--','--nocapture']),
('clippy',['cargo','clippy','--workspace','--all-targets','--all-features','--','-D','warnings']),
('fmt',['cargo','fmt','--all','--','--check']),
('oracle-build',['cargo','build','--release','-p','viboceros-oracle','--features','native-smlib']),
('python',['python3','-m','unittest','tools.rhino_oracle.test_surface_fillet_probe'])]
for name,args in commands:
 start=time.monotonic()
 with open(p+name+'.log','w')as log:r=subprocess.run(args,stdout=log,stderr=subprocess.STDOUT,env=env)
 Path(p+name+'.status').write_text(str(r.returncode)+'\n');Path(p+name+'-runtime.json').write_text(json.dumps(dict(command=args,status=r.returncode,seconds=time.monotonic()-start))+'\n');print(name,r.returncode,flush=True)
 if r.returncode:raise SystemExit(r.returncode)
