import json
from pathlib import Path
from tools.rhino_oracle.audit import compare_audit_response

def definition(raw):
 nu,nv=raw['count_u'],raw['count_v'];h=raw['homogeneous_u_major']
 points=[]
 for v in range(nv):
  for u in range(nu):
   p=h[4*(u*nv+v):4*(u*nv+v)+4]
   points.append(dict(point=[x/p[3]for x in p[:3]],weight=p[3]))
 return dict(degree_u=raw['degree_u'],degree_v=raw['degree_v'],control_point_count_u=nu,
             control_point_count_v=nv,control_points=points,knots_u=raw['knots_u'],knots_v=raw['knots_v'])
def value(raw):
 d=definition(raw);p,q=raw['degree_u'],raw['degree_v']
 return dict(degree=[p,q],control_count=[raw['count_u'],raw['count_v']],control_points=d['control_points'],
             knots_u=d['knots_u'],knots_v=d['knots_v'],domain_u=[raw['knots_u'][p],raw['knots_u'][raw['count_u']]],
             domain_v=[raw['knots_v'][q],raw['knots_v'][raw['count_v']]],periodic_u=False,periodic_v=False)
def select(path):
 rows=[json.loads(l)for l in Path(path).read_text().splitlines()]
 rows=[r for r in rows if r['case']<4 and r['chart']==1 and r['rational'] and r['gauge']==1]
 assert len(rows)==8
 return rows
fixture=Path('tools/rhino_oracle/fixtures/surface_patch_geometry.json')
if not fixture.exists():
 rows=select('/tmp/viboceros-surface-patch-before.jsonl')
 request=dict(protocol_version=1,iterations=1,operations=[dict(op='surface_trim_geometry',id='native-patch-'+str(r['case'])+'-'+str(int(r['swapped'])),surface=definition(r['input']),u=r['u'],v=r['v'])for r in rows])
 fixture.write_text(json.dumps(request,indent=2)+'\n')
else:
 request=json.loads(fixture.read_text())
 rows=select('/tmp/viboceros-surface-patch-candidate.jsonl')
 observation=json.loads(Path('tools/rhino_oracle/observations/surface_patch_geometry.json').read_text())
 for mode in range(3):
  outcomes=[]
  for r,operation in zip(rows,request['operations']):
   assert operation['surface']==definition(r['input']) and operation['u']==r['u'] and operation['v']==r['v']
   output=r['outputs'][mode];assert output['correct']
   outcomes.append(dict(status='success',result=dict(id=operation['id'],elapsed_ns=0,value=value(output['surface']))))
  audit=dict(protocol_version=1,engine='viboceros',engine_version='usd-brep-native-patch-probe',iterations=1,outcomes=outcomes)
  report=compare_audit_response(audit,observation,1e-10,1e-10,request=request)
  Path('/tmp/viboceros-surface-patch-sdk-'+str(mode)+'-audit.json').write_text(json.dumps(audit,indent=2)+'\n')
  Path('/tmp/viboceros-surface-patch-sdk-'+str(mode)+'-report.json').write_text(json.dumps(report.as_dict(),indent=2)+'\n')
  print(json.dumps(dict(mode=mode,cases=len(report.operations),matched=report.matched,native_failed=report.native_failed)),flush=True)
