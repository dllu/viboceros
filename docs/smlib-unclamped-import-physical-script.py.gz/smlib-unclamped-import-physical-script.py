"""Independent active-surface witness; strict raw comparisons stay unchanged."""
import itertools
import json
from pathlib import Path
import mpmath as mp
from tools.rhino_oracle.references.join_isocurve_areas import basis


def domain(s):
    return tuple((s['knots_' + a][s['degree'][d]],
                  s['knots_' + a][s['control_count'][d]]) for d, a in enumerate(('u', 'v')))


def grid(s):
    domains = domain(s)
    knots = [list(map(mp.mpf, s['knots_' + a])) for a in ('u', 'v')]
    rows = []
    values = []
    for d, a in enumerate(('u', 'v')):
        lo, hi = map(mp.mpf, domains[d])
        values.append([basis(knots[d], s['degree'][d],
                             lo + (hi - lo) * mp.mpf(i) / 17) for i in range(1, 17)])
    controls = [[mp.mpf(p) * mp.mpf(c['weight']) for p in c['point']] + [mp.mpf(c['weight'])]
                for c in s['control_points']]
    nu, nv = s['control_count']
    for u in values[0]:
        row = []
        for v in values[1]:
            h = [mp.fsum(u[i] * v[j] * controls[j * nu + i][d]
                         for i in range(nu) for j in range(nv)) for d in range(4)]
            assert h[3] > 0
            row.append([x / h[3] for x in h[:3]])
        rows.append(row)
    return rows


audit = json.loads(Path('/tmp/viboceros-unclamped-curved-audit.json').read_text())
native = json.loads(Path('tools/rhino_oracle/observations/join_curved_certificates.json').read_text())
reference = {r['id']: r['value'] for r in native['results']}
results = []
with mp.workdps(80):
    for row in audit['outcomes']:
        assert row['status'] == 'success'
        record = row['result']
        if not record['id'].startswith('unclamped-'):
            continue
        local = [o['brep'] for o in record['value']['objects'] if o['source'] is None]
        expected = [o['brep'] for o in reference[record['id']]['objects'] if o['source'] is None]
        assert len(local) == len(expected) == 1
        local, expected = local[0]['surfaces'], expected[0]['surfaces']
        assert len(local) == len(expected) == 2
        points = [grid(s) for s in local]
        expected_points = [grid(s) for s in expected]
        candidates = {}
        for i, s in enumerate(local):
            for j, r in enumerate(expected):
                for swap in (False, True):
                    if domain(s) != (domain(r)[::-1] if swap else domain(r)):
                        continue
                    error = max(mp.sqrt(mp.fsum((points[i][u][v][d] -
                        expected_points[j][v if swap else u][u if swap else v][d]) ** 2
                        for d in range(3))) for u in range(16) for v in range(16))
                    if error < mp.mpf('1e-10'):
                        candidates[(i, j, swap)] = error
        choices = []
        for order in itertools.permutations(range(2)):
            for swaps in itertools.product((False, True), repeat=2):
                keys = [(i, order[i], swaps[i]) for i in range(2)]
                if all(k in candidates for k in keys):
                    choices.append((max(candidates[k] for k in keys), keys))
        assert len(choices) == 1, record['id']
        maximum, mapping = choices[0]
        results.append(dict(id=record['id'], maximum_point_error=mp.nstr(maximum, 35),
                            face_mapping=[dict(output=i, rhino=j, swapped_uv=s) for i, j, s in mapping]))
assert len(results) == 8
report = dict(cases=8, samples_per_surface=256, surfaces_per_case=2,
              absolute_epsilon=1e-10, arithmetic_digits=80,
              policy='Compare active domains exactly, then independently evaluate tensor NURBS on a 16x16 interior grid. '
                     'Require a unique face bijection, allowing only a U/V transpose. '
                     'Keep raw tolerance, topology, metadata and representation mismatches in the separate strict report. '
                     'A grid is a diagnostic witness, not a continuous boundary proof.',
              results=results)
Path('/tmp/viboceros-unclamped-physical.json').write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps(dict(cases=8, samples=4096,
                      maximum_point_error=max(float(r['maximum_point_error']) for r in results))))
