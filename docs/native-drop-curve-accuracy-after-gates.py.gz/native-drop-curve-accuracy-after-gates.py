import subprocess,time
from pathlib import Path
p='/tmp/viboceros-drop-accuracy-'
# Observe the existing runner's terminal build result; do not restart any job.
for _ in range(360):
 status=Path(p+'oracle-build.status')
 if status.exists():
  assert int(status.read_text())==0
  break
 failed=[]
 for name in ['focused','bridge','command','fillet-oracle','clippy','fmt']:
  path=Path(p+name+'.status')
  if path.exists()and int(path.read_text()):failed.append(name)
 if failed:raise RuntimeError(failed)
 time.sleep(5)
else:raise TimeoutError('Existing gate runner has not reached a terminal build result')
with open(p+'compare.log','w')as log:r=subprocess.run(['python3',p+'compare.py'],stdout=log,stderr=subprocess.STDOUT,env=__import__('os').environ|{'PYTHONPATH':'.'})
Path(p+'compare.status').write_text(str(r.returncode)+'\n');print('saved-sdk-audits',r.returncode,flush=True)
if r.returncode:raise SystemExit(r.returncode)
