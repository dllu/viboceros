import json
from pathlib import Path
from tools.rhino_oracle.client import OracleClient
from tools.rhino_oracle.audit import compare_audit_response
p='/tmp/viboceros-trim-axis-'
read=lambda path:json.loads(Path(path).read_text())
write=lambda name,value:Path(p+name+'.json').write_text(json.dumps(value,indent=2)+'\n')
client=OracleClient(native_smlib=True)
request=read('tools/rhino_oracle/fixtures/trim_parameter_frames.json');sdk=read('tools/rhino_oracle/observations/trim_parameter_frames.json')
native=client.run_viboceros_audit(request,timeout=600.);write('mass-audit',native)
report=compare_audit_response(native,sdk,1e-8,1e-10,request=request);write('mass-report',report.as_dict())
assert report.passed and report.matched==35 and report.native_failed==0
request=read('tools/rhino_oracle/fixtures/surface_fillet.json');sdk=read('tools/rhino_oracle/observations/surface_fillet.json')
native=client.run_viboceros_audit(request,timeout=600.);write('fillet-audit',native)
raw=compare_audit_response(native,sdk,1e-8,1e-12,request=request);write('fillet-raw-report',raw.as_dict())
expected={r['id']:r['value']for r in sdk['results']};failures=[];recipes=[]
for outcome in native['outcomes']:
 if outcome['status']=='failure':failures.append(outcome);continue
 row=outcome['result'];a=row['value'];b=expected[row['id']]
 assert a['source_unchanged']and b['source_unchanged']and len(a['outputs'])==len(b['outputs'])==1
 a,b=a['outputs'][0],b['outputs'][0]
 point_error=max(abs(x-y)for q,r in zip(a['closest_points'],b['closest_points'])for x,y in zip(q,r))
 bounds_error=max(abs(x-y)for q,r in zip(a['bounds'],b['bounds'])for x,y in zip(q,r))
 record=dict(id=row['id'],valid=a['valid'],maximum_point_difference=point_error,maximum_bounds_difference=bounds_error,native_area=a['area'],sdk_area=b['area'])
 recipes.append(record)
 if row['id']!='cylinder-True':assert a['valid']and point_error<=1e-8 and bounds_error<=1e-8
assert len(recipes)==6 and not failures
extended=next(r for r in recipes if r['id']=='cylinder-True')
assert abs(extended['native_area']-28.941496050285952)<1e-7 and extended['maximum_bounds_difference']>9
summary=dict(saved_mass_recipes=35,complete_mass_matches=report.matched,mass_absolute_epsilon=1e-8,mass_relative_epsilon=1e-10,fillet_executed=6,fillet_execution_failures=failures,fillet_recipes=recipes,complete_fillet_matches=raw.matched,complete_fillet_mismatches=raw.as_dict()['mismatched'],scope='All six fillet recipes now return complete protocol values. Only the five previously qualified recipes pass the sampled closest-point/bounds checks. The curved extended recipe retains its large geometry/area mismatch; completing execution is not Rhino parity. No output normalization or tolerance widening.')
write('comparison',summary);print(json.dumps(summary),flush=True)
