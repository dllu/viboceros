import json,time
from pathlib import Path
from tools.rhino_oracle.reparameterize_face_probe import request
from tools.rhino_oracle.client import OracleClient
p='/tmp/viboceros-reparameterize-faces-';root=Path('tools/rhino_oracle/fixtures/reparameterize_faces').resolve();root.mkdir(exist_ok=True)
q=request(str(root));Path(p+'request.json').write_text(json.dumps(q,indent=2)+'\n')
t=time.monotonic();r=OracleClient(settings_scheme='VibocerosOracleReparameterizeFaces20261018').run_rhino(q,timeout=600.)
Path(p+'sdk-response.json').write_text(json.dumps(r,indent=2)+'\n');Path(p+'sdk-runtime.json').write_text(json.dumps(dict(seconds=time.monotonic()-t,recipes=len(q['operations'])))+'\n')
for row in r['results']:
 v=row['value'];print(json.dumps(dict(id=row['id'],success=v['success'],domains=v['domains'],text=v['after']['geometry_text'],equal_sdk=v['after']['geometry']==v['sdk'])),flush=True)
