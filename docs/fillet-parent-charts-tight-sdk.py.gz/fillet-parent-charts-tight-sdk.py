import copy,json,time
from pathlib import Path
from tools.rhino_oracle.client import OracleClient
p='/tmp/viboceros-fillet-charts-';base=json.loads(Path('tools/rhino_oracle/fixtures/surface_fillet_charts.json').read_text());base['operations']=[o for o in base['operations'] if o['id'].endswith('anisotropic') and not o['id'].startswith('planes-')]
assert len(base['operations'])==8
for label,tolerance in [('tight10',1e-10),('tight12',1e-12),('tight14',1e-14)]:
 request=copy.deepcopy(base);request['tolerance']['absolute']=tolerance;Path(p+label+'-request.json').write_text(json.dumps(request,indent=2)+'\n');start=time.monotonic()
 response=OracleClient(settings_scheme='VibocerosOracleFilletCharts'+label+'20261018').run_rhino(request,timeout=600.)
 Path(p+label+'-response.json').write_text(json.dumps(response,indent=2)+'\n');Path(p+label+'-runtime.json').write_text(json.dumps(dict(seconds=time.monotonic()-start,tolerance=tolerance,recipes=8))+'\n')
 print(label,[(r['id'],[(b['geometry']['faces'][0]['definition']['control_count'],b['bounds']) for b in r['value']['outputs']])for r in response['results']],flush=True)
