import json,subprocess,time
from pathlib import Path
root=Path.cwd();b=root/'target/release/build/viboceros-smlib-d4f77638f5302455/out/build';prefix='/tmp/viboceros-circular-rails-'
flags=['c++','-std=c++17','-O1','-DNDEBUG','-DNOMINMAX','-DSM_GRAPHICS_CALLBACKS=1','-DVIBOCEROS_CURVE_INTERSECTION_DISTANCE_PATCH=1','-w','-I',str(root/'crates/viboceros-smlib/native'),'-I',str(b/'usd-brep-patched'),'-I',str(root/'third_party/usd-brep/source/SM_API/inc'),'-I',str(root/'third_party/usd-brep/source/SMLib/inc'),'-include',str(root/'third_party/usd-brep/source/SMLib/inc/StdAfx.h')]
# Experimental offset policy: identical in both executables, outside production.
s=(root/'third_party/usd-brep/source/SMLib/src/SmOffsetSurface.cpp').read_text();needle='gflg, cflg = NL_G1R;';assert s.count(needle)==1
source=Path(prefix+'experimental-offset.cpp');source.write_text(s.replace(needle,'gflg, cflg = NL_CMAX;'))
obj=source.with_suffix('.o');subprocess.run(flags+['-c',str(source),'-o',str(obj)],check=True)
for kind in ['baseline','candidate']:
 extra=[str(b/'CMakeFiles/viboceros_smlib_circular_fillet_rails_baseline.dir/usd-brep-patched/SmFilletStandardSolver.cpp.o')]if kind=='baseline'else[]
 exe=prefix+'continuation-'+kind
 subprocess.run(flags+['/tmp/viboceros-fillet-continuation-probe.cpp',str(obj),*extra,str(b/'libviboceros_smlib.a'),str(b/'libSM_API.a'),str(b/'libSMLib.a'),'-ltbb','-ltbbmalloc','-o',exe],check=True)
 start=time.monotonic()
 with open(exe+'.jsonl','w')as out,open(exe+'.log','w')as log:r=subprocess.run([exe],stdout=out,stderr=log,check=True)
 rows=[json.loads(line)for line in Path(exe+'.jsonl').read_text().splitlines()];assert len(rows)==14
 if kind=='baseline':assert sum(row['status']==0 for row in rows)==2
 else:assert all(row['status']==0 and row['exported']==0 and len(row['vertices'])==4 for row in rows)
 Path(exe+'-runtime.json').write_text(json.dumps(dict(command=[exe],seconds=time.monotonic()-start,status=r.returncode,successes=sum(row['status']==0 for row in rows),cases=len(rows)))+'\n')
 print(kind,sum(row['status']==0 for row in rows),flush=True)
