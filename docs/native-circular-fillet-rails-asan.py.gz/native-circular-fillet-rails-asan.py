import json,os,subprocess,time
from pathlib import Path
p='/tmp/viboceros-circular-rails-';build=Path('/tmp/viboceros-isocurve-pair-asan');env=dict(os.environ,ASAN_OPTIONS='detect_leaks=0:abort_on_error=1')
commands=[('asan-configure',['cmake','-S','crates/viboceros-smlib/native','-B',str(build),'-DUSD_BREP_ROOT='+str(Path('third_party/usd-brep').resolve()),'-DVIBOCEROS_SMLIB_ASAN=ON','-DCMAKE_BUILD_TYPE=Release']),('asan-build',['cmake','--build',str(build),'--parallel','5','--target','viboceros_smlib_circular_fillet_rails_probe','viboceros_smlib_surface_fillet_probe']),('asan-direct',[str(build/'viboceros_smlib_circular_fillet_rails_probe')]),('asan-fillet',[str(build/'viboceros_smlib_surface_fillet_probe')])]
for name,args in commands:
 start=time.monotonic()
 with open(p+name+'.log','w')as log:
  with open(p+name+'.jsonl','w')as out:r=subprocess.run(args,stdout=out if name in ['asan-direct','asan-fillet'] else log,stderr=log,env=env)
 Path(p+name+'.status').write_text(str(r.returncode)+'\n')
 Path(p+name+'-runtime.json').write_text(json.dumps(dict(command=args,seconds=time.monotonic()-start,status=r.returncode))+'\n')
 print(name,r.returncode,flush=True)
 if r.returncode:raise SystemExit(r.returncode)
