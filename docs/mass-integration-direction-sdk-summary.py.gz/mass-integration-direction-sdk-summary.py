import json,math
from pathlib import Path
load=lambda name:json.loads(Path(name).read_text())
req=load('/tmp/viboceros-fillet-extension-shape-sdk-request.json');ref=load('/tmp/viboceros-fillet-extension-shape-sdk-response.json')
fixed_req=load('/tmp/viboceros-fillet-extension-mobius-sdk-request.json');fixed=load('/tmp/viboceros-fillet-extension-mobius-sdk-response.json')
assert len(req['operations'])==len(ref['results'])==20 and len(fixed_req['operations'])==len(fixed['results'])==2
for row in ref['results']+fixed['results']:
 assert row['value']['source_unchanged']and len(row['value']['outputs'])==1 and row['value']['outputs'][0]['valid']
lookup={r['id']:r for r in ref['results']};operations={r['id']:r for r in req['operations']}
source=load('tools/rhino_oracle/fixtures/surface_fillet.json')['operations'][-1]['surfaces'][1]
def evaluate(s,u,v):
 bu=[(1-u)**2,2*u*(1-u),u*u];bv=[1-v,v];total=0.;point=[0.]*3
 for j in range(2):
  for i in range(3):
   p=s['control_points'][j*3+i];w=bu[i]*bv[j]*p['weight'];total+=w
   for axis in range(3):point[axis]+=w*p['point'][axis]
 return [p/total for p in point]
rows=[]
for op,row in zip(fixed_req['operations'],fixed['results']):
 original_id=op['id'].replace('-fixed-physical-pick','');k=float(original_id.split('-')[1])
 assert row['value']==lookup[original_id]['value']
 maximum=0.
 for i in range(33):
  u=i/32.;mapped=k*u/(1+(k-1)*u)
  for v in [0.,.5,.8,1.]:maximum=max(maximum,math.dist(evaluate(op['surfaces'][1],u,v),evaluate(source,mapped,v)))
 assert maximum<1e-12
 physical=math.dist(evaluate(op['surfaces'][1],*op['picks'][1]),evaluate(source,.5,.8));assert physical<1e-12
 points=[r['point']for r in row['value']['outputs'][0]['geometry']['vertices']if abs(r['point'][2])<1e-8]
 rows.append(dict(id=op['id'],mobius_k=k,maximum_independent_reparameterization_error=maximum,physical_pick_error=physical,complete_value_equal_to_same_chart_original_pick=True,bottom_rail_endpoints=points))
summary=dict(owned_public_sdk_recipes=22,source_unchanged=True,valid_owned_outputs=22,angle_matrix=load('/tmp/viboceros-fillet-extension-shape-analysis.json'),fixed_physical_pick_checks=rows,inference='For these equivalent cylinder sheets, the SDK extended caps depend on the rational parameterization even with identical physical picks. A fixed geometric angular margin cannot reproduce these cases. No new native continuation parity is claimed.')
Path('/tmp/viboceros-trim-axis-sdk-summary.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps(dict(recipes=22,fixed_physical_picks=rows)),flush=True)
