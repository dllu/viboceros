import json
from pathlib import Path
from tools.rhino_oracle.client import OracleClient

def curve(points):
 p=len(points)-1
 return dict(degree=p,control_points=[dict(point=point,weight=1.)for point in points],knots=[0.]*(p+1)+[1.]*(p+1))
ops=[]
for scale in [0.,.05,.5,-.5,1.5]:
 gap=scale*1e-8
 ops.append(dict(op='curve_intersect_command',id='skew-'+str(scale),curves=[curve([[0,0,gap],[1,2,gap],[2,0,gap]]),curve([[0,.5,0],[2,.5,0]])]))
request=dict(protocol_version=1,iterations=1,tolerance=dict(absolute=1e-8,relative=1e-12,angular=1e-10),operations=ops)
p='/tmp/viboceros-curve-contact-'
Path(p+'request.json').write_text(json.dumps(request,indent=2)+'\n')
client=OracleClient(settings_scheme='VibocerosOracleCurveContact20261018',native_smlib=True)
r=client.run_rhino(request,timeout=300.)
Path(p+'sdk-response.json').write_text(json.dumps(r,indent=2)+'\n')
n=client.run_viboceros_audit(request,timeout=300.)
Path(p+'baseline-audit.json').write_text(json.dumps(n,indent=2)+'\n')
for row in r['results']:print('Rhino',row['id'],json.dumps(row['value']),flush=True)
for row in n['outcomes']:print('Native',json.dumps(row),flush=True)
