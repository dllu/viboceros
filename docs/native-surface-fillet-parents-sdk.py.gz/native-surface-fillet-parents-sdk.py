import copy,json,time
from pathlib import Path
from tools.rhino_oracle.client import OracleClient
p='/tmp/viboceros-fillet-parents-sdk-';r=json.loads(Path('tools/rhino_oracle/fixtures/surface_fillet_picks.json').read_text());ops=[]
for op in r['operations']:
 for trim in [False,True]:
  o=copy.deepcopy(op);o['trim']=trim;o['id']+='-trim'if trim else'-split';ops.append(o)
r['operations']=ops;Path(p+'request.json').write_text(json.dumps(r,indent=2)+'\n');start=time.monotonic();out=OracleClient(settings_scheme='VibocerosOracleFilletParents20261018').run_rhino(r,timeout=600.)
Path(p+'response.json').write_text(json.dumps(out,indent=2)+'\n');Path(p+'runtime.json').write_text(json.dumps(dict(seconds=time.monotonic()-start,recipes=len(ops)))+'\n')
for row in out['results']:
 v=row['value'];print(json.dumps(dict(id=row['id'],source_unchanged=v['source_unchanged'],fillets=len(v['outputs']),parents=[[dict(faces=o['face_count'],valid=o['valid'],bounds=o['bounds'],area=o['area'])for o in group]for group in v['parents']])),flush=True)
