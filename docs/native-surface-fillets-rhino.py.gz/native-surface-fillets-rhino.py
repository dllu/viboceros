import json,math
from pathlib import Path
from tools.rhino_oracle.client import OracleClient

def surface(points,p=1,q=1,nu=2,nv=2,ku=None,kv=None,weights=None):
 return dict(degree_u=p,degree_v=q,control_point_count_u=nu,control_point_count_v=nv,knots_u=ku or[0,0,1,1],knots_v=kv or[0,0,1,1],control_points=[dict(point=a,weight=w)for a,w in zip(points,weights or[1]*len(points))])
def parents(y):
 return [surface([[0,0,0],[10,0,0],[0,10,0],[10,10,0]]),surface([[5,y[0],-5],[5,y[0],5],[5,y[1],-5],[5,y[1],5]])]
operations=[]
for length in [[0,10],[3,7]]:
 for extend in [False,True]:
  operations.append(dict(op='surface_fillet',id='planes-'+str(length[0])+'-'+str(extend),surfaces=parents(length),picks=[[.2,.5],[.8,.5]],radius=1.,extend=extend,queries=[[4,0,0],[4,10,0],[5,5,1],[4+1/math.sqrt(2),5,1-1/math.sqrt(2)]]))
plane=surface([[-10,-10,0],[10,-10,0],[-10,10,0],[10,10,0]])
cyl=surface([[5,0,-5],[5,5,-5],[0,5,-5],[5,0,5],[5,5,5],[0,5,5]],2,1,3,2,[0,0,0,1,1,1],[0,0,1,1],[1,math.sqrt(.5),1,1,math.sqrt(.5),1])
for extend in [False,True]:operations.append(dict(op='surface_fillet',id='cylinder-'+str(extend),surfaces=[plane,cyl],picks=[[.9,.6],[.5,.8]],radius=1.,extend=extend,queries=[[6,0,0],[0,6,0],[5,0,1],[6/math.sqrt(2),6/math.sqrt(2),0]]))
request=dict(protocol_version=1,iterations=1,tolerance=dict(absolute=1e-8,relative=1e-12,angular=1e-8),operations=operations)
Path('/tmp/viboceros-surface-fillet-rhino-request.json').write_text(json.dumps(request,indent=2)+'\n')
response=OracleClient(settings_scheme='VibocerosOracleSurfaceFillet20261018').run_rhino(request,timeout=180.)
Path('/tmp/viboceros-surface-fillet-rhino-response.json').write_text(json.dumps(response,indent=2)+'\n')
for row in response['results']:print(json.dumps(dict(id=row['id'],source_unchanged=row['value']['source_unchanged'],outputs=[{k:v for k,v in b.items()if k!='geometry'}for b in row['value']['outputs']])),flush=True)
