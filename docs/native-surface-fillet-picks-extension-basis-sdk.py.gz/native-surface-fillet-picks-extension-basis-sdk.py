import copy,json,math,time
from pathlib import Path
from tools.rhino_oracle.client import OracleClient
base=json.loads(Path('tools/rhino_oracle/fixtures/surface_fillet.json').read_text());source=next(o for o in base['operations']if o['id']=='cylinder-True');prefix='/tmp/viboceros-fillet-extension-basis-sdk-'
def homogeneous(cp):return [x*cp['weight']for x in cp['point']]+[cp['weight']]
def control(h):return {'point':[x/h[3]for x in h[:3]],'weight':h[3]}
def mix(a,b,t):return [(1-t)*x+t*y for x,y in zip(a,b)]
ops=[]
for k in [.5,1.,2.]:
 for basis in ['original','elevated3','elevated4','split']:
  op=copy.deepcopy(source);op['id']='basis-'+str(k)+'-'+basis;op['picks'][1][0]=1/(k+1)
  s=op['surfaces'][1];rows=[]
  for row in range(2):
   h=[homogeneous(cp)for cp in s['control_points'][row*3:row*3+3]]
   for i in range(3):h[i]=[x*k**i for x in h[i]]
   if basis.startswith('elevated'):
    while len(h)<=int(basis[-1]):
     n=len(h)-1;h=[h[0]]+[mix(h[i],h[i-1],i/(n+1))for i in range(1,n+1)]+[h[-1]]
   elif basis=='split':
    a=.3;l=mix(h[0],h[1],a);r=mix(h[1],h[2],a);m=mix(l,r,a);h=[h[0],l,m,r,h[2]]
   rows.extend(map(control,h))
  s['control_points']=rows;s['control_point_count_u']=len(rows)//2
  if basis.startswith('elevated'):s['degree_u']=int(basis[-1]);s['knots_u']=[0.]*(s['degree_u']+1)+[1.]*(s['degree_u']+1)
  elif basis=='split':s['knots_u']=[0.]*3+[.3]*2+[1.]*3
  ops.append(op)
for chart in [[-2.,7.],[1e12,1e12+10.]]:
 op=copy.deepcopy(source);op['id']='chart-'+str(chart[0]);op['surfaces'][1]['knots_u']=[chart[0]]*3+[chart[1]]*3;op['picks'][1][0]=(chart[0]+chart[1])/2;ops.append(op)
for batch,tolerance,operations in [('basis',1e-8,ops),('loose',1e-4,[copy.deepcopy(source)]),('tight',1e-10,[copy.deepcopy(source)])]:
 request=copy.deepcopy(base);request['operations']=operations;request['tolerance']['absolute']=tolerance
 Path(prefix+batch+'-request.json').write_text(json.dumps(request,indent=2)+'\n');start=time.monotonic()
 result=OracleClient(settings_scheme='VibocerosOracleFilletBasis20261018'+batch).run_rhino(request,timeout=600.)
 Path(prefix+batch+'-response.json').write_text(json.dumps(result,indent=2)+'\n')
 Path(prefix+batch+'-runtime.json').write_text(json.dumps({'seconds':time.monotonic()-start,'recipes':len(operations)})+'\n')
 for row in result['results']:
  outputs=[dict(vertices=[v['point']for v in o['geometry']['vertices']],area=o['area'],surface_counts=[f['definition']['control_count']for f in o['geometry']['faces']])for o in row['value']['outputs']]
  print(json.dumps({'batch':batch,'tolerance':tolerance,'id':row['id'],'outputs':outputs}),flush=True)
