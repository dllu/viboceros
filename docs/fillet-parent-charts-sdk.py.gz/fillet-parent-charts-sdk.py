import copy,json,time
from pathlib import Path
from tools.rhino_oracle.client import OracleClient
prefix='/tmp/viboceros-fillet-charts-'
request=json.loads(Path('tools/rhino_oracle/fixtures/surface_fillet_parents.json').read_text())
keep=['planes-0.2-0.2','planes-0.2-0.8','planes-0.8-0.2','planes-0.8-0.8','cylinder-2.0-0.2','cylinder-6.0-0.8','swap','mobius-2']
operations=[]
charts=[('affine',[[[-2.,8.],[10.,30.]],[[2.,7.],[-8.,3.]]]),('anisotropic',[[[2e-8,7e-8],[-8e3,-3e3]],[[-4.,6.],[2e-7,8e-7]]])]
for op in request['operations']:
 if op['id'].rsplit('-',1)[0] not in keep:continue
 for tag,domains in charts:
  out=copy.deepcopy(op);out['id']+='-'+tag
  for i,s in enumerate(out['surfaces']):
   for axis,name in enumerate(['u','v']):
    knots=s['knots_'+name];a=knots[s['degree_'+name]];b=knots[s['control_point_count_'+name]];low,high=domains[i][axis]
    def mapped(t):
     if t==a:return low
     if t==b:return high
     return low+(high-low)*((t-a)/(b-a))
    s['knots_'+name]=list(map(mapped,knots));out['picks'][i][axis]=mapped(out['picks'][i][axis])
  operations.append(out)
request['operations']=operations;assert len(operations)==32
Path(prefix+'sdk-request.json').write_text(json.dumps(request,indent=2)+'\n')
start=time.monotonic();response=OracleClient(settings_scheme='VibocerosOracleFilletCharts20261018').run_rhino(request,timeout=600.)
Path(prefix+'sdk-response.json').write_text(json.dumps(response,indent=2)+'\n')
Path(prefix+'sdk-runtime.json').write_text(json.dumps(dict(seconds=time.monotonic()-start,recipes=len(operations)))+'\n')
for row in response['results']:print(json.dumps(dict(id=row['id'],outputs=len(row['value']['outputs']),parents=list(map(len,row['value']['parents'])),pure=row['value']['source_unchanged'])),flush=True)
