import os,subprocess,time,json
from pathlib import Path
prefix='/tmp/viboceros-fillet-command-'
env=dict(os.environ,CMAKE_BUILD_PARALLEL_LEVEL='10',CARGO_BUILD_JOBS='8')
for name,args in [
 ('clippy',['cargo','clippy','--workspace','--all-targets','--all-features','--','-D','warnings']),
 ('portable-check',['cargo','check','--workspace','--all-targets']),
 ('fmt',['cargo','fmt','--all','--','--check'])]:
 start=time.monotonic()
 with open(prefix+name+'.log','w') as log:r=subprocess.run(args,stdout=log,stderr=subprocess.STDOUT,env=env)
 Path(prefix+name+'-runtime.json').write_text(json.dumps(dict(command=args,status=r.returncode,seconds=time.monotonic()-start))+'\n');print(name,r.returncode,flush=True)
 if r.returncode:raise SystemExit(r.returncode)
