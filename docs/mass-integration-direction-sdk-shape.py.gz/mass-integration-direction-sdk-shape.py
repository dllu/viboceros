import copy,json,math,time
from pathlib import Path
from tools.rhino_oracle.client import OracleClient
base=json.loads(Path('tools/rhino_oracle/fixtures/surface_fillet.json').read_text())
source=next(o for o in base['operations']if o['id']=='cylinder-True');ops=[]
for degrees in [15,30,45,60,90,120,150]:
 angle=math.radians(degrees);weight=math.cos(angle/2)
 for extend in [False,True]:
  op=copy.deepcopy(source);op['id']=f'angle-{degrees}-{extend}';op['extend']=extend
  c=op['surfaces'][1]
  for row,z in enumerate([-5.,5.]):
   for i,p in enumerate([(5.,0.),(5.,5.*math.tan(angle/2)),(5.*math.cos(angle),5.*math.sin(angle))]):
    c['control_points'][3*row+i]={'point':[p[0],p[1],z],'weight':weight if i==1 else 1.}
  ops.append(op)
for height in [4.,30.]:
 op=copy.deepcopy(source);op['id']=f'height-{height}'
 for c in op['surfaces'][1]['control_points']:c['point'][2]=math.copysign(height/2,c['point'][2])
 ops.append(op)
for k in [.5,2.]:
 op=copy.deepcopy(source);op['id']=f'mobius-{k}'
 for row in range(2):
  for i in range(3):op['surfaces'][1]['control_points'][row*3+i]['weight']*=k**i
 ops.append(op)
for axis in [0,1]:
 op=copy.deepcopy(source);op['id']=f'wide-plane-{axis}'
 for c in op['surfaces'][0]['control_points']:c['point'][axis]*=3
 ops.append(op)
base['operations']=ops
prefix='/tmp/viboceros-fillet-extension-shape-sdk-';Path(prefix+'request.json').write_text(json.dumps(base,indent=2)+'\n')
started=time.monotonic()
r=OracleClient(settings_scheme='VibocerosOracleSurfaceFilletShape20261018').run_rhino(base,timeout=600.)
Path(prefix+'response.json').write_text(json.dumps(r,indent=2)+'\n')
for row in r['results']:
 print(json.dumps({'id':row['id'],'outputs':[{'vertices':b['geometry']['vertices'],'area':b['area'],'bounds':b['bounds']}for b in row['value']['outputs']]}),flush=True)
Path(prefix+'runtime.json').write_text(json.dumps({'elapsed_seconds':time.monotonic()-started,'recipes':len(ops)},indent=2)+'\n')
