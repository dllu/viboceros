#define main parent_matrix_main
#include "/home/dllu/proj/viboceros/tools/usd_brep/surface_fillet_parents_probe.cpp"
#undef main
int main(){try{size_t cases=0;for(int family=0;family<3;++family)for(int trim:{0,1})for(int reverse:{0,1}){
 auto first=plane(false,family!=0),second=family?cylinder(family==2):plane(true,false);const auto f=first.view(),s=second.view();int sides[2]={1,1},changed[2]={};VbSolid *out[3]={};char error[2048]={};check(vb_surface_fillet_parents(&f,&s,.75,sides,0,0,1e-8,trim,out,changed,error,sizeof error)==0,error);
 std::unique_ptr<VbSolid,decltype(&vb_solid_free)>owners[3]={{out[0],&vb_solid_free},{out[1],&vb_solid_free},{out[2],&vb_solid_free}};std::unique_ptr<VbBrep,decltype(&vb_brep_free)>copies[3]={{nullptr,&vb_brep_free},{nullptr,&vb_brep_free},{nullptr,&vb_brep_free}};
 for(int step=0;step<3;++step){int index=reverse?2-step:step;if(!owners[index])continue;VbBrep*raw=nullptr;check(vb_shape_brep(owners[index].get(),1e-10,&raw,error,sizeof error)==0,error);copies[index].reset(raw);owners[index].reset();}
 size_t points=0;for(auto &copy:copies){if(!copy)continue;VbBrepView v{};check(vb_brep_view(copy.get(),&v)==0,"view");for(size_t i=0;i<v.face_count;++i){const auto&srf=v.faces[i].surface;for(size_t j=0;j<4*srf.count[0]*srf.count[1];++j)check(std::isfinite(srf.points_xyzw[j]),"nonfinite");points+=srf.count[0]*srf.count[1];}for(size_t i=0;i<v.edge_count;++i){const auto&c=v.edges[i].curve;for(size_t j=0;j<4*c.count[0];++j)check(std::isfinite(c.points_xyzw[j]),"nonfinite edge");points+=c.count[0];}}
 ++cases;std::cout<<"{\"family\":"<<family<<",\"trim\":"<<trim<<",\"reverse_deletion\":"<<reverse<<",\"read_controls\":"<<points<<",\"passed\":true}\n";
 }std::cerr<<cases<<" cross-handle deletion-order cases passed\n";return 0;}catch(const std::exception&e){std::cerr<<e.what()<<'\n';return 2;}}
