import json
from pathlib import Path
from tools.rhino_oracle.audit import compare_audit_response

def definition(raw):
 h=raw['homogeneous'];points=[]
 for i in range(0,len(h),4):
  w=h[i+3];points.append(dict(point=[x/w for x in h[i:i+3]],weight=w))
 return dict(degree=raw['degree'],knots=raw['knots'],control_points=points)
def value(raw):
 d=definition(raw);p=d['degree'];count=len(d['control_points'])
 return dict(**d,domain=[d['knots'][p],d['knots'][count]],closed=False,periodic=False)
def select(path):
 rows=[json.loads(l)for l in Path(path).read_text().splitlines()]
 rows=[r for r in rows if r['case']in [0,1,2,3,4,5,7,8,9]and r['chart']==1 and r['rational']and r['gauge']==1]
 assert len(rows)==9;return rows
fixture=Path('tools/rhino_oracle/fixtures/curve_segment_limits_geometry.json')
if not fixture.exists():
 rows=select('/tmp/viboceros-curve-segment-limits-before.jsonl')
 request=dict(protocol_version=1,iterations=1,operations=[dict(op='curve_trim_geometry',id='native-segment-limit-'+str(r['case']),curve=definition(r['input']),start=r['low'],end=r['high'])for r in rows])
 fixture.write_text(json.dumps(request,indent=2)+'\n')
else:
 rows=select('/tmp/viboceros-curve-segment-limits-candidate.jsonl')
 request=json.loads(fixture.read_text())
 observation=json.loads(Path('tools/rhino_oracle/observations/curve_segment_limits_geometry.json').read_text())
 for mode in range(3):
  outcomes=[]
  for r,op in zip(rows,request['operations']):
   assert op['curve']==definition(r['input'])and op['start']==r['low']and op['end']==r['high']
   out=r['outputs'][mode];assert out['correct']
   outcomes.append(dict(status='success',result=dict(id=op['id'],elapsed_ns=0,value=value(out['curve']))))
  audit=dict(protocol_version=1,engine='viboceros',engine_version='usd-brep-native-curve-segment-probe',iterations=1,outcomes=outcomes)
  report=compare_audit_response(audit,observation,1e-10,1e-12,request=request)
  Path('/tmp/viboceros-curve-segment-limits-sdk-'+str(mode)+'-audit.json').write_text(json.dumps(audit,indent=2)+'\n')
  Path('/tmp/viboceros-curve-segment-limits-sdk-'+str(mode)+'-report.json').write_text(json.dumps(report.as_dict(),indent=2)+'\n')
  print(json.dumps(dict(mode=mode,cases=len(report.operations),matched=report.matched,native_failed=report.native_failed,changed_ids=[o.id for o in report.operations if not o.passed])),flush=True)
