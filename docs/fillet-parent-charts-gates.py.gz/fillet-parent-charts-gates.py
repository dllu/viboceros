import os,subprocess,json,time,sys
from pathlib import Path
p='/tmp/viboceros-fillet-charts-';env=dict(os.environ,CMAKE_BUILD_PARALLEL_LEVEL='10',CARGO_BUILD_JOBS='8')
commands=[
 ('geometry',['cargo','test','--release','-p','viboceros-geometry','--lib']),
 ('fillet-oracle',['cargo','test','--release','-p','viboceros-oracle','--features','native-smlib','--lib','surface_fillet','--','--nocapture']),
 ('command',['cargo','test','--release','-p','viboceros-command','--features','native-smlib','--lib']),
 ('ui',['cargo','test','--release','-p','viboceros','--features','native-smlib','--bin','viboceros','fillet_surface']),
 ('clippy',['cargo','clippy','--workspace','--all-targets','--all-features','--','-D','warnings']),
 ('portable-check',['cargo','check','--workspace','--all-targets']),
 ('fmt',['cargo','fmt','--all','--','--check']),
 ('oracle-build',['cargo','build','--release','-p','viboceros-oracle','--features','native-smlib']),
]
if len(sys.argv)>1:
 names=[name for name,args in commands];commands=commands[names.index(sys.argv[1]):]
for name,args in commands:
 start=time.monotonic()
 with open(p+name+'.log','w')as log:r=subprocess.run(args,stdout=log,stderr=subprocess.STDOUT,env=env)
 Path(p+name+'-runtime.json').write_text(json.dumps(dict(command=args,status=r.returncode,seconds=time.monotonic()-start))+'\n');print(name,r.returncode,flush=True)
 if r.returncode:raise SystemExit(r.returncode)
