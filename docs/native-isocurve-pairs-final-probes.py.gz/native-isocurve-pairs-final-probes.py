from pathlib import Path
import subprocess
root=Path('/home/dllu/proj/viboceros')
builds=list((root/'target/debug/build').glob('viboceros-smlib-*/out/build/viboceros_smlib_isocurve_pair_probe'))
regular=max(builds,key=lambda p:p.stat().st_mtime).parent
with Path('/tmp/viboceros-isocurve-pair-final-probe-build.log').open('w') as f:
 code=subprocess.run(['cmake','--build',str(regular),'--target','viboceros_smlib_isocurve_pair_probe','viboceros_smlib_isocurve_pair_baseline','-j10'],stdout=f,stderr=subprocess.STDOUT).returncode
 if code==0:
  code=subprocess.run(['cmake','--build','/tmp/viboceros-isocurve-pair-asan','--target','viboceros_smlib_isocurve_pair_probe','-j10'],stdout=f,stderr=subprocess.STDOUT).returncode
Path('/tmp/viboceros-isocurve-pair-final-probe-build.status').write_text(str(code)+'\n')
if code:raise SystemExit(code)
with Path('/tmp/viboceros-isocurve-pair-baseline.jsonl').open('w') as f,Path('/tmp/viboceros-isocurve-pair-baseline.stderr').open('w') as e:
 code=subprocess.run([str(regular/'viboceros_smlib_isocurve_pair_baseline')],stdout=f,stderr=e).returncode
Path('/tmp/viboceros-isocurve-pair-baseline.status').write_text(str(code)+'\n')
assert code==1
subprocess.run(['python3','/tmp/viboceros-isocurve-pair-run-probes.py'],check=True)
