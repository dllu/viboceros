use serde_json::{Value, json};
use viboceros_geometry::{Brep, NurbsSurface, Point3, Tolerance, WeightedPoint3};
use viboceros_smlib::Shape;

fn source(value: &Value) -> Brep {
    let surface = &value["surface"];
    let controls = surface["control_points"].as_array().unwrap().iter().map(|c| {
        let p = &c["point"];
        WeightedPoint3::try_new(Point3::try_new(p[0].as_f64().unwrap(),
            p[1].as_f64().unwrap(), p[2].as_f64().unwrap()).unwrap(), c["weight"].as_f64().unwrap()).unwrap()
    }).collect();
    let knots = |key| surface[key].as_array().unwrap().iter().map(|v|v.as_f64().unwrap()).collect();
    let surface = NurbsSurface::try_new_rational(surface["degree_u"].as_u64().unwrap() as usize,
        surface["degree_v"].as_u64().unwrap() as usize,
        surface["control_point_count_u"].as_u64().unwrap() as usize,
        surface["control_point_count_v"].as_u64().unwrap() as usize,
        controls, knots("knots_u"), knots("knots_v")).unwrap();
    let b=&value["trim_bounds"];
    Brep::try_rectangular_surface_face(surface,
        b[0][0].as_f64().unwrap()..=b[0][1].as_f64().unwrap(),
        b[1][0].as_f64().unwrap()..=b[1][1].as_f64().unwrap(),
        Tolerance::DEFAULT).unwrap()
}

fn main() {
    let modeling = Tolerance::try_new(0.001, 1e-12, 1e-10).unwrap();
    let request: Value = serde_json::from_str(&std::fs::read_to_string(
        "/home/dllu/proj/viboceros/tools/rhino_oracle/fixtures/join_isocurve_certificates.json").unwrap()).unwrap();
    for op in request["operations"].as_array().unwrap() {
        let id=op["id"].as_str().unwrap();
        if !id.ends_with("-Join-pre") {continue;}
        let inputs = op["sources"].as_array().unwrap().iter()
            .map(|s| source(&s["brep"]["source"])).collect();
        let input=Brep::try_combine(inputs,Tolerance::DEFAULT).unwrap();
        for normalized in [false,true] {
            let imported=if normalized {Shape::from_sheet_with_normalized_domains(&input,modeling)}
                else {Shape::from_brep(&input,modeling)};
            let outcome=match imported {
                Err(e)=>json!({"phase":"import","error":e.to_string()}),
                Ok(shape)=>match shape.stitch(0.0018) {
                    Err(e)=>json!({"phase":"stitch","error":e.to_string()}),
                    Ok(result)=>match result.shape.to_brep(modeling) {
                        Err(e)=>json!({"phase":"export","error":e.to_string()}),
                        Ok(b)=>json!({"phase":"success","faces":b.faces().len(),"edges":b.edges().len()}),
                    }
                }
            };
            println!("{}",json!({"id":id,"normalized":normalized,"outcome":outcome}));
        }
    }
}
