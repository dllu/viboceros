import subprocess
from pathlib import Path
p='/tmp/viboceros-surface-fillet-';build=Path('target/debug/build/viboceros-smlib-e982af202de3f65b/out/build')
with open(p+'baseline-build.log','w')as log:
 r=subprocess.run(['cmake','--build',str(build),'--target','viboceros_smlib_surface_fillet_baseline','-j10'],stdout=log,stderr=subprocess.STDOUT)
Path(p+'baseline-build.status').write_text(str(r.returncode)+'\n');assert r.returncode==0
with open(p+'baseline.jsonl','w')as log,open(p+'baseline.stderr','w')as err:
 r=subprocess.run([str(build/'viboceros_smlib_surface_fillet_baseline')],stdout=log,stderr=err,timeout=120)
Path(p+'baseline.status').write_text(str(r.returncode)+'\n');print('baseline',r.returncode);assert r.returncode==1
