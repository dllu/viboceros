import json,gzip,math,subprocess,time
from pathlib import Path
from tools.rhino_oracle.client import OracleClient
from tools.rhino_oracle.audit import compare_audit_response
p='/tmp/viboceros-fillet-parents-';client=OracleClient(native_smlib=True)
read=lambda path:json.loads(Path(path).read_text())
def save(name,value):Path(p+name+'.json').write_text(json.dumps(value,indent=2)+'\n')
def values(audit):
 assert all(r['status']=='success'for r in audit['outcomes']),audit
 return {r['result']['id']:r['result']['value']for r in audit['outcomes']}
def gap(a,b,key):return max(abs(x-y)for q,r in zip(a[key],b[key])for x,y in zip(q,r))
def distance_gap(a,b,queries):return max(abs(math.dist(q,x)-math.dist(q,y))for q,x,y in zip(queries,a['closest_points'],b['closest_points']))
request=read('tools/rhino_oracle/fixtures/surface_fillet_parents.json');sdk=read('tools/rhino_oracle/observations/surface_fillet_parents.json');start=time.monotonic();actual=client.run_viboceros_audit(request,timeout=600.);save('candidate-audit',actual)
raw=compare_audit_response(actual,sdk,1e-8,1e-12,request=request);save('candidate-raw-report',raw.as_dict());native=values(actual);reference={r['id']:r['value']for r in sdk['results']};records=[]
for op in request['operations']:
 a=native[op['id']];e=reference[op['id']];assert a['source_unchanged']and e['source_unchanged']and len(a['outputs'])==len(e['outputs'])==1
 fillet_bounds=gap(a['outputs'][0],e['outputs'][0],'bounds');fillet_distance=distance_gap(a['outputs'][0],e['outputs'][0],op['queries']);assert fillet_bounds<=1e-8 and fillet_distance<=1e-8
 parents=[]
 for i,(ag,eg)in enumerate(zip(a['parents'],e['parents'])):
  assert len(ag)==len(eg),(op['id'],i,len(ag),len(eg));unused=set(range(len(eg)));pairs=[]
  for aa in ag:
   j=min(unused,key=lambda j:gap(aa,eg[j],'bounds'));unused.remove(j);ee=eg[j]
   bounds=gap(aa,ee,'bounds');distance=distance_gap(aa,ee,op['queries']);assert bounds<=1e-8 and distance<=1e-8,(op['id'],i,bounds,distance)
   assert aa['valid']and ee['valid']and aa['face_count']==ee['face_count']==1 and aa['edge_count']==ee['edge_count']==4
   pairs.append(dict(sdk_index=j,maximum_bounds_difference=bounds,maximum_closest_distance_difference=distance,maximum_closest_coordinate_difference=gap(aa,ee,'closest_points'),native_area=aa['area'],sdk_area=ee['area']))
  if ag:
   area=sum(x['area']for x in ag)
   expected=(42.5 if op['trim']else 100.)if op['id'].startswith('planes-')else 5.*math.pi/2*(4.25 if op['trim']else 10.)
   assert abs(area-expected)<=1e-8,(op['id'],i,area,expected)
  parents.append(pairs)
 records.append(dict(id=op['id'],fillet_maximum_bounds_difference=fillet_bounds,fillet_maximum_closest_distance_difference=fillet_distance,fillet_maximum_closest_coordinate_difference=gap(a['outputs'][0],e['outputs'][0],'closest_points'),parent_counts=list(map(len,a['parents'])),parents=parents))
assert len(records)==32
# Preserve the complete existing fillet-only contracts, including their known limits.
old=[]
for fixture,label,previous in [('surface_fillet_picks.json','original-picks','docs/native-surface-fillet-picks-candidate-audit.json.gz'),('surface_fillet.json','original-six','docs/native-surface-fillet-picks-original-six-audit.json.gz')]:
 req=read('tools/rhino_oracle/fixtures/'+fixture);out=client.run_viboceros_audit(req,timeout=600.);save(label+'-audit',out);base=json.loads(gzip.decompress(Path(previous).read_bytes()));av=values(out);bv=values(base);changes=[]
 for id,v in av.items():
  a=v['outputs'][0];b=bv[id]['outputs'][0];assert gap(a,b,'bounds')<=1e-8 and gap(a,b,'closest_points')<=1e-8,(id,'fillet-only regression')
  changes.append(dict(id=id,complete_value_unchanged=v==bv[id],maximum_point_difference=gap(a,b,'closest_points'),maximum_bounds_difference=gap(a,b,'bounds')))
 old.append(dict(fixture=fixture,cases=len(av),complete_value_matches=sum(x['complete_value_unchanged']for x in changes),changes=changes))
closed=read(p+'closed-request.json');out=client.run_viboceros_audit(closed,timeout=600.);save('closed-candidate-audit',out);base=read(p+'closed-baseline-audit.json');assert out['outcomes']==base['outcomes']and out['outcomes'][0]['status']=='failure'
summary=dict(recipes=32,absolute_epsilon=1e-8,relative_epsilon=1e-12,semantics_matches=32,raw_complete_matches=raw.matched,raw_complete_mismatches=raw.as_dict()['mismatched'],records=records,original_contracts=old,closed_contact_failure_unchanged=True,seconds=time.monotonic()-start,scope='All fresh recipes execute both the public SDK and native parent-result overloads. Match parent regions by bounds only for geometric qualification; retain original complete ordering and all coefficient/area/query differences in the raw audit. Integrated Rust tests additionally check bidirectional interior/boundary memberships using a coefficient-checked rectangular region helper; it does not qualify arbitrary trim loops. Literal closest-point coordinate differences can exceed epsilon. Full FilletSrf command/UI, existing trimmed parents, closed certificate work, disconnected-component choice and curved extension matching remain unfinished.')
save('comparison',summary);print(json.dumps(summary),flush=True)
