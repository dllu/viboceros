import json,subprocess,shlex
from pathlib import Path
prefix='/tmp/viboceros-point-interpolation-'
build=Path(Path(prefix+'build-path').read_text())
command=['/usr/bin/c++','-std=c++17','-O2','-DNOMINMAX','-DSM_GRAPHICS_CALLBACKS=1','-DVIBOCEROS_CURVE_INTERSECTION_DISTANCE_PATCH=1','-I'+str(build/'usd-brep-patched'),'-isystem','third_party/usd-brep/source/SMLib/inc','tools/usd_brep/rebuild_interpolation_probe.cpp',str(build/'libSMLib.a'),'-ltbb','-ltbbmalloc','-o',prefix+'witness']
Path(prefix+'witness-command.txt').write_text(shlex.join(command)+'\n')
r=subprocess.run(command,capture_output=True,text=True);Path(prefix+'witness-build.log').write_text(r.stdout+r.stderr);assert r.returncode==0
r=subprocess.run([prefix+'witness'],capture_output=True,text=True);Path(prefix+'witness.json').write_text(r.stdout);assert r.returncode==0 and not r.stderr
r=json.loads(r.stdout);assert max(abs(a-b)for a,b in zip(r['expected_endpoints'],r['fitted_endpoint_limits']))<=1e-12
assert max(abs(a-b)for a,b in zip(r['expected_controls'],r['fitted_controls']))<=1e-12
print(json.dumps(r),flush=True)
