import json,math
from pathlib import Path
from tools.rhino_oracle.client import OracleClient
from tools.rhino_oracle.audit import compare_audit_response
prefix='/tmp/viboceros-surface-fillet-'
request=json.loads(Path('tools/rhino_oracle/fixtures/surface_fillet.json').read_text())
reference=json.loads(Path('tools/rhino_oracle/observations/surface_fillet.json').read_text())
native=OracleClient(native_smlib=True).run_viboceros_audit(request,timeout=1800.)
Path(prefix+'native-final-audit.json').write_text(json.dumps(native,indent=2)+'\n')
raw=compare_audit_response(native,reference,1e-8,1e-12,request=request)
Path(prefix+'raw-report.json').write_text(json.dumps(raw.as_dict(),indent=2)+'\n')
references={r['id']:r['value']for r in reference['results']};comparisons=[];failures=[];points=0;point_error=0;bounds_error=0
for row in native['outcomes']:
 if row['status']=='failure':failures.append(row);continue
 identifier=row['result']['id'];a=row['result']['value'];e=references[identifier]
 assert a['source_unchanged']and e['source_unchanged']and len(a['outputs'])==len(e['outputs'])==1
 a,e=a['outputs'][0],e['outputs'][0];assert a['valid']and e['valid']and not a['is_solid']and not e['is_solid']
 assert a['face_count']==e['face_count']==1
 delta=max(abs(x-y)for p,q in zip(a['closest_points'],e['closest_points'])for x,y in zip(p,q))
 box=max(abs(x-y)for p,q in zip(a['bounds'],e['bounds'])for x,y in zip(p,q))
 points+=len(a['closest_points']);point_error=max(point_error,delta);bounds_error=max(bounds_error,box)
 assert delta<=1e-8 and box<=1e-8
 length=10 if identifier.startswith('planes-0')else 4 if identifier=='planes-3-False'else 7
 expected=math.pi/2*length if identifier.startswith('planes')else math.pi/2*(3*math.pi-1)
 comparisons.append(dict(id=identifier,maximum_point_coordinate_difference=delta,maximum_bounds_coordinate_difference=box,native_area=a['area'],sdk_area=e['area'],analytic_area=expected,native_area_error=abs(a['area']-expected),sdk_area_error=abs(e['area']-expected),geometry_policy='Complete raw definitions are retained; no comparison-time geometry or attribute normalization.'))
assert len(comparisons)==5 and points==20 and len(failures)==1 and failures[0]['id']=='cylinder-True'
assert raw.matched==0 and raw.native_failed==1
report=dict(executed=6,api_successes=5,execution_failures=failures,sampled_matches=5,paired_closest_points=points,point_epsilon=1e-8,maximum_point_coordinate_difference=point_error,maximum_bounds_coordinate_difference=bounds_error,comparisons=comparisons,complete_raw_matches=raw.matched,complete_raw_mismatches=5,complete_raw_execution_errors=raw.native_failed,scope='Five qualified producer recipes compare sampled closest points and tight bounds. Areas remain diagnostics against an independent analytic value. Complete serialized NURBS/topology records differ between constructors and all raw mismatches remain retained. Curved Extend=Yes is an actual native failure and a required follow-up. No continuous global Rhino geometry or performance claim.')
Path(prefix+'comparison.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({k:v for k,v in report.items()if k!='comparisons'}),flush=True)
