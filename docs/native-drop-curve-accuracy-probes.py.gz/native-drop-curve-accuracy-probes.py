import os,subprocess,json
from pathlib import Path
p='/tmp/viboceros-drop-accuracy-';root=Path.cwd()
for label,build,sanitize in [('normal',Path('target/debug/build/viboceros-smlib-e982af202de3f65b/out/build'),False),('asan',Path('/tmp/viboceros-isocurve-pair-asan'),True)]:
 with open(p+label+'-build.log','w')as log:
  r=subprocess.run(['cmake','-S','crates/viboceros-smlib/native','-B',str(build),'-DUSD_BREP_ROOT='+str(root/'third_party/usd-brep'),'-DCMAKE_BUILD_TYPE=Release','-DVIBOCEROS_SMLIB_ASAN='+('ON'if sanitize else'OFF')],stdout=log,stderr=subprocess.STDOUT)
  if r.returncode==0:r=subprocess.run(['cmake','--build',str(build),'--target','viboceros_smlib_drop_curve_probe',*(['viboceros_smlib_drop_curve_baseline']if not sanitize else[]),'-j10'],stdout=log,stderr=subprocess.STDOUT)
 Path(p+label+'-build.status').write_text(str(r.returncode)+'\n');print(label+'-build',r.returncode,flush=True)
 if r.returncode:raise SystemExit(r.returncode)
 targets=[(label,'viboceros_smlib_drop_curve_probe')]+([('baseline','viboceros_smlib_drop_curve_baseline')]if not sanitize else[])
 for name,target in targets:
  with open(p+name+'.jsonl','w')as out,open(p+name+'.stderr','w')as err:
   r=subprocess.run([str(build/target)],stdout=out,stderr=err,timeout=120,env=dict(os.environ,ASAN_OPTIONS='detect_leaks=0:halt_on_error=1'))
  Path(p+name+'.status').write_text(str(r.returncode)+'\n')
  rows=[json.loads(l)for l in Path(p+name+'.jsonl').read_text().splitlines()]
  print(name,r.returncode,len(rows),sum(x['passed']for x in rows),flush=True)
  if len(rows)!=270 or r.returncode!=(1 if name=='baseline'else 0):raise SystemExit(1)
 if sanitize:
  with open(p+'asan-flags.txt','w')as log:
   for name in ['SMLib','SM_API','viboceros_smlib','viboceros_smlib_drop_curve_probe']:
    flags=(build/'CMakeFiles'/(name+'.dir')/'flags.make').read_text();assert '-fsanitize=address'in flags;log.write(name+'\n'+flags+'\n')
