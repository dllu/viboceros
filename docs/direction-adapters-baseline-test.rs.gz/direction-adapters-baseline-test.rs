use viboceros_command::{CommandRegistry, construction_plane};
use viboceros_document::{Document, Geometry};
use viboceros_geometry::{
    Circle3, CurveRef, Frame3, LineSegment, MeshFace, NurbsSurface, Point3, Tolerance,
    TriangleMesh, Vector3,
};

fn setup(exponent: i32) -> (f64, Tolerance, Frame3) {
    let scale = 2_f64.powi(exponent);
    let tolerance = Tolerance::try_new(1e-7 * scale, 1e-12, 1e-9).unwrap();
    let frame = Frame3::try_from_normal(
        Point3::try_new(0., 0., 0.).unwrap(),
        Vector3::try_new(2., 3., 6.).unwrap(),
        Tolerance::NUMERICAL_VALIDATION,
    )
    .unwrap();
    (scale, tolerance, frame)
}

fn token(point: Point3) -> String {
    let [x, y, z] = point.to_array();
    format!("{x},{y},{z}")
}

fn frame_agrees(actual: Frame3, expected: Frame3, scale: f64) {
    assert!(actual.origin().distance_to(expected.origin()).unwrap() / scale < 1e-12);
    for (a, b) in actual.axes().into_iter().zip(expected.axes()) {
        assert!(a.as_vector().dot(b.as_vector()).unwrap() > 1. - 1e-12);
    }
}

fn check_primitive(geometry: &Geometry, kind: &str, frame: Frame3, scale: f64, tolerance: Tolerance) {
    let point = |point: Point3, mesh: bool| {
        let [x, y, z] = frame.coordinates_of(point).unwrap().map(|x| x / scale);
        let radius = x.hypot(y);
        let epsilon = 1e-10;
        match kind {
            "cylinder" | "cone" | "frustum" => {
                assert!(z >= -epsilon && z <= 3. + epsilon, "{kind}: z={z}");
                let expected = match kind { "cone" => 2. * (1. - z / 3.), "frustum" => 2. - z / 3., _ => 2. };
                let cap = mesh && (z.abs() < epsilon || (z - 3.).abs() < epsilon);
                assert!(if cap { radius <= expected + epsilon } else { (radius - expected).abs() < epsilon }, "{kind}: r={radius} expected={expected}, z={z}");
            }
            "sphere" => assert!((radius.hypot(z) - 2.).abs() < epsilon),
            "torus" => assert!(((radius - 3.).hypot(z) - 1.).abs() < epsilon),
            _ => unreachable!(),
        }
    };
    match geometry {
        Geometry::NurbsSurface(surface) => {
            for u in [0., 0.17, 0.49, 0.81, 1.] {
                for v in [0., 0.17, 0.49, 0.81, 1.] {
                    point(surface.evaluate(surface.parameter_at_u(u).unwrap(), surface.parameter_at_v(v).unwrap()).unwrap(), false);
                }
            }
        }
        Geometry::Mesh(mesh) => {
            assert!(mesh.topology().is_closed());
            for &vertex in mesh.vertices() { point(vertex, true); }
        }
        Geometry::Brep(brep) => {
            assert!(brep.is_solid());
            let expected = match kind {
                "cylinder" => 12. * std::f64::consts::PI,
                "tube" => 9. * std::f64::consts::PI,
                "pyramid" => 8.,
                "truncated-pyramid" => 14.,
                _ => panic!("unexpected solid {kind}"),
            };
            let volume = brep.signed_volume(tolerance).unwrap() / scale / scale / scale;
            assert!((volume - expected).abs() < 1e-6, "{kind}: volume={volume} expected={expected}");
        }
        _ => panic!("primitive geometry"),
    }
}

#[test]
fn explicit_primitive_directions_preserve_geometry_across_axis_magnitudes_and_model_units() {
    let registry = CommandRegistry::with_builtins();
    let mut failures = Vec::new();
    let mut checked = 0;
    for exponent in [-20, 0, 20, 40, 80] {
        let (scale, tolerance, frame) = setup(exponent);
        for picked_radius in [false, true] {
            let radius = |value: f64| if picked_radius {
                token(frame.point_at([value * scale, 0., 0.]).unwrap())
            } else { (value * scale).to_string() };
            let r = radius(2.);
            let major = radius(3.);
            for (kind, recipe) in [
                ("cylinder", format!("Cylinder 0,0,0 {r} {} Solid=Yes", 3. * scale)),
                ("cone", format!("Cone 0,0,0 {r} {}", 3. * scale)),
                ("frustum", format!("TruncatedCone 0,0,0 {r} {} {}", 3. * scale, scale)),
                ("tube", format!("Tube 0,0,0 {r} {} {}", scale, 3. * scale)),
                ("torus", format!("Torus 0,0,0 {major} {scale}")),
                ("cylinder", format!("MeshCylinder 0,0,0 {r} {} Solid=Yes", 3. * scale)),
                ("cone", format!("MeshCone 0,0,0 {r} {} Solid=Yes", 3. * scale)),
                ("frustum", format!("MeshTruncatedCone 0,0,0 {r} {} {} Solid=Yes", 3. * scale, scale)),
                ("sphere", format!("MeshSphere 0,0,0 {r}")),
                ("torus", format!("MeshTorus 0,0,0 {major} {scale}")),
                ("pyramid", format!("Pyramid 4 0,0,0 {r} {} Solid=Yes", 3. * scale)),
                ("truncated-pyramid", format!("TruncatedPyramid 4 0,0,0 {r} {} {} Solid=Yes", 3. * scale, scale)),
            ] {
                let mut reference = None;
                for direction_exponent in [-200, 0, 200] {
                    checked += 1;
                    let factor = 2_f64.powi(direction_exponent);
                    let command = format!("{recipe} Axis={},{},{}", 2. * factor, 3. * factor, 6. * factor);
                    let mut document = Document::default();
                    document.set_tolerance(tolerance);
                    document.clear_history().unwrap();
                    match registry.execute(&mut document, &command) {
                        Ok(_) => {
                            assert_eq!(document.objects().len(), 1);
                            let before = document.objects().cloned().collect::<Vec<_>>();
                            let geometry = before[0].geometry();
                            check_primitive(geometry, kind, frame, scale, tolerance);
                            if let Some(reference) = &reference {
                                assert!(geometry == reference, "axis magnitude changed {recipe} at scale 2^{exponent}");
                            } else { reference = Some(geometry.clone()); }
                            document.undo().unwrap();
                            assert_eq!(document.objects().len(), 0);
                            document.redo().unwrap();
                            assert_eq!(document.objects().cloned().collect::<Vec<_>>(), before);
                        }
                        Err(error) => failures.push(format!("scale=2^{exponent} axis=2^{direction_exponent} picked={picked_radius} {recipe}: {error:?}")),
                    }
                }
            }
        }
    }
    eprintln!("DIRECTION_ADAPTERS primitives={checked} failures={}", failures.len());
    assert_eq!(checked, 360);
    assert!(failures.is_empty(), "{}", failures.join("\n"));
}

#[test]
fn construction_planes_keep_unit_axes_and_ignore_surface_parameter_units() {
    let mut failures = Vec::new();
    let mut checked = 0;
    for exponent in [-20, 0, 20, 40, 80] {
        let (scale, tolerance, frame) = setup(exponent);
        let point = |x, y, z| frame.point_at([x * scale, y * scale, z * scale]).unwrap();
        let surface = NurbsSurface::try_bilinear([point(0., 0., 0.), point(2., 0., 0.), point(2., 3., 0.), point(0., 3., 0.)]).unwrap();
        let circle = Circle3::try_from_frame(frame.origin(), 2. * scale, frame.x_axis(), frame.z_axis(), tolerance).unwrap();
        let line = LineSegment::try_new(point(0., 0., 0.), point(0., 0., 3.), tolerance).unwrap();
        let mesh = TriangleMesh::try_new_faces(vec![point(0., 0., 0.), point(2., 0., 0.), point(2., 3., 0.), point(0., 3., 0.)], vec![MeshFace::Quad([0, 1, 2, 3])], tolerance).unwrap();
        for (name, result, expected) in [
            ("vertical", construction_plane::vertical(frame, frame.origin(), point(2., 0., 5.), tolerance).map_err(|e| e.to_string()), None),
            ("circle", construction_plane::frame_from_object(&Geometry::Circle(circle), tolerance).map_err(|e| e.to_string()), Some(frame)),
            ("line", construction_plane::frame_from_object(&Geometry::Line(line), tolerance).map_err(|e| e.to_string()), None),
            ("perpendicular", construction_plane::curve_perpendicular_frame(CurveRef::Line(&line), None, tolerance).map_err(|e| e.to_string()), None),
            ("mesh", construction_plane::frame_from_mesh_face(&mesh, 0, tolerance).map_err(|e| e.to_string()), None),
            ("rotate", construction_plane::rotated(frame, frame.origin(), point(0., 0., 3.), 90., tolerance).map_err(|e| e.to_string()), None),
            ("rotate-reference", construction_plane::rotated_by_reference_points(frame, frame.origin(), point(0., 0., 3.), point(2., 0., 0.), point(0., 2., 0.), tolerance).map_err(|e| e.to_string()), None),
        ] {
            checked += 1;
            match result {
                Ok(actual) => {
                    if let Some(expected) = expected { frame_agrees(actual, expected, scale); }
                    let axes = actual.axes().map(|x| x.as_vector());
                    assert!(axes[0].cross(axes[1]).unwrap().dot(axes[2]).unwrap() > 1. - 1e-12, "{name}");
                    if name.starts_with("rotate") {
                        assert!(axes[0].dot(frame.y_axis().as_vector()).unwrap() > 1. - 1e-12);
                        assert!(axes[1].dot(frame.x_axis().opposite().as_vector()).unwrap() > 1. - 1e-12);
                    }
                    if name == "perpendicular" {
                        assert!(axes[2].dot(frame.z_axis().as_vector()).unwrap() > 1. - 1e-12);
                    }
                }
                Err(error) => failures.push(format!("scale=2^{exponent} {name}: {error}")),
            }
        }
        for parameter_exponent in [-200, 0, 200] {
            let width = 2_f64.powi(parameter_exponent);
            let source = surface.try_reparameterized(0. ..=width, 0. ..=width).unwrap();
            let before = source.clone();
            for (name, result) in [
                ("surface-object", construction_plane::frame_from_object(&Geometry::NurbsSurface(source.clone()), tolerance)),
                ("surface-default", construction_plane::surface_frame(&source, false, None, None, tolerance)),
            ] {
                checked += 1;
                match result {
                    Ok(actual) => frame_agrees(actual, frame.with_origin(point(1., 1.5, 0.)), scale),
                    Err(error) => failures.push(format!("scale=2^{exponent} parameters=2^{parameter_exponent} {name}: {error:?}")),
                }
            }
            assert_eq!(source, before);
        }
    }
    eprintln!("DIRECTION_ADAPTERS construction_planes={checked} failures={}", failures.len());
    assert_eq!(checked, 65);
    assert!(failures.is_empty(), "{}", failures.join("\n"));
}
