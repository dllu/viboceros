import gzip,hashlib,json,math,re,subprocess
from pathlib import Path
from tools.verify_provenance import verify
prefix='/tmp/viboceros-fillet-picks-';artifacts={}
def read(name):return json.loads(Path(prefix+name+'.json').read_text())
def retain(path,label=None):
 path=Path(path);data=path.read_bytes();label=label or path.name.removeprefix('viboceros-fillet-picks-')
 dest=Path('docs/native-surface-fillet-picks-'+label+'.gz');dest.write_bytes(gzip.compress(data,mtime=0));artifacts[str(dest)]=hashlib.sha256(dest.read_bytes()).hexdigest()
 return dict(retained=str(dest),uncompressed_sha256=hashlib.sha256(data).hexdigest())
def rows(name):return [json.loads(s)for s in Path(prefix+name+'.jsonl').read_text().splitlines()]
commands={
 'geometry':'cargo test --release -p viboceros-geometry --no-fail-fast -- --nocapture',
 'bridge':'cargo test --release -p viboceros-smlib --features native --no-fail-fast -- --nocapture',
 'command':'cargo test --release -p viboceros-command --features native-smlib --no-fail-fast -- --nocapture',
 'fillet-oracle':'cargo test --release -p viboceros-oracle --features native-smlib --lib surface_fillet -- --nocapture',
 'clippy':'cargo clippy --workspace --all-targets --all-features -- -D warnings',
 'fmt':'cargo fmt --all -- --check',
 'oracle-build':'cargo build --release -p viboceros-oracle --features native-smlib',
 'python':'python3 -m unittest tools.rhino_oracle.test_surface_fillet_probe'}
gates=[]
for name,command in commands.items():
 assert Path(prefix+name+'.status').read_text().strip()=='0',name
 text=Path(prefix+name+'.log').read_text();counts=re.findall(r'test result: (?:ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored;',text)
 entry=dict(name=name,command=command,exit_code=0,log=retain(prefix+name+'.log'))
 if counts:
  totals=list(map(sum,zip(*[map(int,r)for r in counts])));entry.update(zip(['passed','failed','ignored'],totals));assert entry['failed']==0
 gates.append(entry)
for name in ['native-build','native-fillet','asan-build','asan-fillet']:
 assert Path(prefix+name+'.status').read_text().strip()=='0',name
normal=rows('native-fillet');asan=rows('asan-fillet');assert len(normal)==len(asan)==66 and all(r['passed']for r in normal+asan)
comparison=read('comparison');assert comparison['candidate_sampled_image_matches']==16
before=rows('query');after=rows('query-budget');assert len(before)==len(after)==16
maxgap=lambda rr,key:max(r[key]for r in rr)
sdk_gap=lambda rr:max(abs(x-y)for r in rr for x,y in zip(r['point'],r['sdk']))
precision=dict(cases=4,query_accuracies=[1e-8,1e-9,1e-10,1e-11],old_maximum_analytic_distance=maxgap(before,'analytic_gap'),candidate_maximum_analytic_distance=maxgap(after,'analytic_gap'),old_maximum_sdk_coordinate_difference=sdk_gap(before),candidate_maximum_sdk_coordinate_difference=sdk_gap(after),scope='Controlled temporary native wrapper override reserves one sixteenth of caller accuracy after validating the original request. Same Rust query driver and public inputs; tightening only the projection solver does not remove the old construction error. This diagnoses one torus family, not global C1 accuracy.')
assert precision['old_maximum_analytic_distance']>4e-8 and precision['candidate_maximum_analytic_distance']<1e-8
basis=read('basis-analysis');assert basis['maximum_coordinate_bound']<1e-12
g2=[json.loads(line)for line in Path('/tmp/viboceros-fillet-g2-prototype.jsonl').read_text().splitlines()]
assert len(g2)==14 and all(r['status']==0 for r in g2)
g2_errors=[]
for row in g2:
 bottom=[p for p in row['vertices']if abs(p[2])<=1e-8];top=[p for p in row['vertices']if abs(p[2]-1)<=1e-8];assert len(bottom)==len(top)==2
 error=max(*(abs(math.hypot(p[0],p[1])-6)for p in bottom),*(abs(math.hypot(p[0],p[1])-5)for p in top))
 g2_errors.append(dict(normalized=row['normalized'],factor=row['factor'],maximum_vertex_radius_error=error))
assert max(r['maximum_vertex_radius_error']for r in g2_errors)>4

record=dict(date='2026-10-18',baseline_commit='d59f692febecb247d503e7bb21f9061b931289ae',
 upstream_commit=subprocess.check_output(['git','-C','third_party/usd-brep','rev-parse','HEAD'],text=True).strip(),
 change='Prepare signed surface fillet offsets from bounded closest normals to the other original UV pick, using existing conditioned source preparation. Native oracle uses those picks unless an explicit diagnostic side override is supplied. Reserve internal construction precision for fitted rail/loft normals without changing caller acceptance. Fix the C ABI probe to evaluate its actual stored endpoints.',
 completed_runs=gates,
 sdk_comparison=comparison,
 old_executable=read('baseline-binary'),
 independent_accuracy_diagnostic=precision,
 closest_point_qualification=read('sdk-projection-diagnostic'),
 native_fillet_matrix=dict(normal_passed=66,asan_passed=66,normal_maximum_geometry_error=max(r.get('maximum_geometry_error',0)for r in normal),asan_maximum_geometry_error=max(r.get('maximum_geometry_error',0)for r in asan),normal=retain(prefix+'native-fillet.jsonl'),asan=retain(prefix+'asan-fillet.jsonl'),scope='56 full geometry and lifetime cases, ten invalid requests; original 1e-8 analytic radius/extent checks. Inputs and private parents die before export; exported definitions outlive the native result.'),
 probe_failure=dict(initial_exit_code=2,cause='Probe interpolated the last edge sample to 15.000000000000004 although the stored upper endpoint and active knot limit are 15.000000000000002. Native Parameter outside NURBS domain rejection is correct. Final probe uses the exact stored endpoints; no curve domain or acceptance tolerance changed.',diagnostic=retain(prefix+'invariant-stderr.log')),
 sdk_capture=dict(recipes=16,completed=True,runtime=read('sdk-runtime'),initial_postcapture_check='Initial expected-sides assertion was incorrect for a negative-X pick next to a bounded first-quadrant cylinder. Full SDK capture completed before this diagnostic assertion. Both original expected-sides hypothesis and failure log remain retained; qualification uses the bounded projection result.'),
 extension_followup=dict(production_policy_changed=False,basis_input_equivalence=basis,scope='16 fresh SDK calls: 14 basis/chart recipes and two tolerance variants. Degree elevation preserves observed extension endpoints; knot insertion changes them despite complete same-parameter input polynomial bounds below 6.4e-14 in decimal JSON. The remote chart returns no fillet. Loose tolerance changes shape/extent. Complete responses are retained without normalization.',rejected_g2=dict(cases=14,status_successes=14,vertex_radius_results=g2_errors,scope='Separate NL_G2 offset continuation returned status zero but violated analytic circle radii. Successful construction status is insufficient; this experiment is not enabled.')),
 limitations=['FilletSrf UI/command, source trimming, joining, attributes/history and disconnected-component choice remain unfinished.', 'Curved Extend=Yes retains its known large native/SDK extent mismatch. These changes do not qualify the extension policy.', 'Sampled surface image membership, closest distances and tight bounds do not certify continuous global Rhino agreement or complete NURBS/topology/area protocol parity. Literal SDK closest-point coordinates retain differences above the model epsilon, diagnosed independently as tangential projection differences; SDK fitted-normal effects and query stopping are not distinguished. All raw protocol differences remain in the audit.', 'A smaller internal construction target is an empirical precision reserve, not a global normal-error bound. Conditioning/resource limits and general throughput remain unqualified.', 'AddressSanitizer instruments the complete native libraries and C ABI probe; leak detection is disabled. Rust gates run normally. Upstream repo.sh/prog_test, USD, Python-binding and GUI harnesses were not run.'])
# Retain full new captures, audits, diagnostics and driver sources. Exclude binaries/objects.
for pattern in ['viboceros-fillet-picks-*','viboceros-fillet-extension-basis-sdk*','viboceros-fillet-g2-prototype*']:
 for path in sorted(Path('/tmp').glob(pattern)):
  if path.suffix not in ['.json','.jsonl','.log','.py','.cpp','.rs']:continue
  if path.name.endswith(('provenance-records.json','record.log','stage.log')):continue
  retain(path,path.name.removeprefix('viboceros-fillet-picks-') if path.name.startswith('viboceros-fillet-picks-') else path.name.removeprefix('viboceros-fillet-'))
retain('/tmp/viboceros-fillet-continuation-probe.cpp','continuation-driver.cpp')
source_paths=['README.md','docs/native-surface-fillets.md','docs/native-surface-fillet-picks.md','crates/viboceros-smlib/native/surface_fillet.cpp','crates/viboceros-smlib/src/native/surface_fillet.rs','crates/viboceros-smlib/src/native/surface_fillet/picks.rs','crates/viboceros-smlib/tests/surface_fillet_picks.rs','crates/viboceros-oracle/src/surface_fillet.rs','crates/viboceros-oracle/src/surface_fillet_images.rs','tools/usd_brep/surface_fillet_probe.cpp','tools/rhino_oracle/test_surface_fillet_probe.py','tools/rhino_oracle/fixtures/surface_fillet_picks.json','tools/rhino_oracle/observations/surface_fillet_picks.json','tools/verify_provenance.py','third_party/usd-brep/source/SMLib/src/SmOffsetSurface.cpp','crates/viboceros-smlib/native/CMakeLists.txt','crates/viboceros-smlib/build.rs','tools/rhino_oracle/client.py','tools/rhino_oracle/rhino_worker.py','tools/rhino_oracle/surface_fillet_probe.py','tools/rhino_oracle/run_headless.sh','tools/rhino_oracle/fixtures/surface_fillet.json','tools/rhino_oracle/observations/surface_fillet.json']
record['source_sha256']={p:hashlib.sha256(Path(p).read_bytes()).hexdigest()for p in source_paths};record['source_git_sha256']={'d59f692febecb247d503e7bb21f9061b931289ae:docs/native-circular-fillet-rails-validation.json':hashlib.sha256(subprocess.check_output(['git','show','d59f692febecb247d503e7bb21f9061b931289ae:docs/native-circular-fillet-rails-validation.json'])).hexdigest()};record['artifact_sha256']=artifacts
out=Path('docs/native-surface-fillet-picks-validation.json');out.write_text(json.dumps(record,indent=2)+'\n');print(json.dumps(dict(record=str(out),verified_sha256_entries=verify(record),gates=gates,artifacts=len(artifacts)),indent=2),flush=True)
