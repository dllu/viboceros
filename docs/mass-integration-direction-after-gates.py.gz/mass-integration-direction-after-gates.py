import os,subprocess,time
from pathlib import Path
p='/tmp/viboceros-trim-axis-';env=dict(os.environ,CMAKE_BUILD_PARALLEL_LEVEL='10',CARGO_BUILD_JOBS='8',PYTHONPATH='.')
for _ in range(360):
 path=Path(p+'oracle-build.status')
 if path.exists():assert int(path.read_text())==0;break
 for name in ['geometry','bridge','command','fillet-oracle','clippy','fmt']:
  status=Path(p+name+'.status')
  if status.exists()and int(status.read_text()):raise RuntimeError(name)
 time.sleep(5)
else:raise TimeoutError('Existing gate runner did not reach its terminal build result')
# The frozen fitted-sheet regression was added after the earlier bridge run.
# Rerun that package and final lint/format checks with the added test and data.
for name,args in [
 ('bridge',['cargo','test','--release','-p','viboceros-smlib','--features','native','--no-fail-fast','--','--nocapture']),
 ('clippy',['cargo','clippy','--workspace','--all-targets','--all-features','--','-D','warnings']),
 ('fmt',['cargo','fmt','--all','--','--check'])]:
 for suffix in ['log','status']:
  original=Path(p+name+'.'+suffix)
  if original.exists():original.rename(p+name+'-initial.'+suffix)
 with open(p+name+'.log','w')as log:r=subprocess.run(args,stdout=log,stderr=subprocess.STDOUT,env=env)
 Path(p+name+'.status').write_text(str(r.returncode)+'\n');print(name,r.returncode,flush=True)
 if r.returncode:raise SystemExit(r.returncode)
with open(p+'compare.log','w')as log:r=subprocess.run(['python3',p+'compare.py'],stdout=log,stderr=subprocess.STDOUT,env=env)
Path(p+'compare.status').write_text(str(r.returncode)+'\n');print('comparisons',r.returncode,flush=True)
if r.returncode:raise SystemExit(r.returncode)
