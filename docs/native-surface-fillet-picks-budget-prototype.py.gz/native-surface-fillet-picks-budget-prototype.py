import subprocess
from pathlib import Path
root=Path.cwd();b=root/'target/release/build/viboceros-smlib-d4f77638f5302455/out/build';prefix='/tmp/viboceros-fillet-picks-budget'
s=Path('crates/viboceros-smlib/native/surface_fillet.cpp').read_text();needle='    const VbNurbsData *definitions[2] = {&first, &second};';assert s.count(needle)==1
s=s.replace(needle,'    accuracy = std::max(accuracy / 16., std::nextafter(SM_EFF_ZERO, INFINITY));\n'+needle)
s=s.replace('#include <cmath>','#include <cmath>\n#include <algorithm>')
Path(prefix+'.cpp').write_text(s)
flags=['c++','-std=c++17','-O1','-DNDEBUG','-DNOMINMAX','-DSM_GRAPHICS_CALLBACKS=1','-DVIBOCEROS_CURVE_INTERSECTION_DISTANCE_PATCH=1','-w','-I',str(root/'crates/viboceros-smlib/native'),'-I',str(b/'usd-brep-patched'),'-I',str(root/'third_party/usd-brep/source/SM_API/inc'),'-I',str(root/'third_party/usd-brep/source/SMLib/inc'),'-include',str(root/'third_party/usd-brep/source/SMLib/inc/StdAfx.h')]
subprocess.run(flags+['-c',prefix+'.cpp','-o',prefix+'.o'],check=True)
cc=Path(prefix+'-cc');cc.write_text('#!/bin/sh\nexec cc '+prefix+'.o "$@"\n');cc.chmod(0o755)
p=Path('/tmp/viboceros-fillet-picks-query.py');runner=p.read_text().replace("'-C','codegen-units=1'", "'-C','codegen-units=1','-C','linker=/tmp/viboceros-fillet-picks-budget-cc'").replace("'/tmp/viboceros-fillet-picks-query'", "'/tmp/viboceros-fillet-picks-query-budget'").replace("'/tmp/viboceros-fillet-picks-query.jsonl'", "'/tmp/viboceros-fillet-picks-query-budget.jsonl'")
Path(prefix+'-runner.py').write_text(runner)
subprocess.run(['python3',prefix+'-runner.py'],check=True)
