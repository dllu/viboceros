import hashlib,json,subprocess
from pathlib import Path
from tools.verify_provenance import verify
record_path='docs/native-surface-fillet-parents-validation.json'
record=json.loads(Path(record_path).read_text());checked=verify(record)
for name in json.loads(Path('/tmp/viboceros-fillet-parents-provenance-records.json').read_text()):checked+=verify(json.loads(Path(name).read_text()))
protected={'AGENTS.md':'2964326e30febe2cf7436b4944624992a3173170bb121b58d94fe666d716c92d','package.json':'ca3d163bab055381827226140568f3bef7eaac187cebd76878e0b63e9e442356','package-lock.json':'03c030a449ce215347eb2450f3293cb86958b23a358a7fca693979d6f8dcaa63'}
for name,want in protected.items():assert hashlib.sha256(Path(name).read_bytes()).hexdigest()==want,name
assert subprocess.check_output(['git','-C','third_party/usd-brep','status','--short'],text=True)==''
allowed=set(record['source_sha256'])|set(record['artifact_sha256'])|{record_path}|set(json.loads(Path('/tmp/viboceros-fillet-parents-provenance-records.json').read_text()))
actual=set(subprocess.check_output(['git','diff','HEAD','--name-only'],text=True).splitlines())|set(subprocess.check_output(['git','ls-files','--others','--exclude-standard'],text=True).splitlines())
assert actual-set(protected)<=allowed,actual-set(protected)-allowed
stage=sorted(actual-set(protected))
subprocess.run(['git','add','--',*stage],check=True)
assert set(subprocess.check_output(['git','diff','--cached','--name-only'],text=True).splitlines())==set(stage)
subprocess.run(['git','diff','--cached','--check'],check=True)
print(json.dumps(dict(verified_sha256_entries=checked,staged_files=len(stage),protected_files_unchanged=True,upstream_checkout_clean=True)),flush=True)
