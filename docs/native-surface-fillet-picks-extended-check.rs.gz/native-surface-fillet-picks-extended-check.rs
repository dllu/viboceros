use viboceros_geometry::{NurbsSurface,Point3,WeightedPoint3,Tolerance};
use viboceros_smlib::{SurfaceFilletOptions,fillet_surfaces};
use serde_json::{Value,json};
fn main(){
 let request:Value=serde_json::from_slice(&std::fs::read("tools/rhino_oracle/fixtures/surface_fillet.json").unwrap()).unwrap();
 let sdk:Value=serde_json::from_slice(&std::fs::read("tools/rhino_oracle/observations/surface_fillet.json").unwrap()).unwrap();
 let tol=Tolerance::try_new(1e-8,1e-12,1e-8).unwrap();
 for op in request["operations"].as_array().unwrap(){
  if op["id"]!="cylinder-True"{continue;}
  let surfaces=op["surfaces"].as_array().unwrap().iter().map(|s|{
   let points=s["control_points"].as_array().unwrap().iter().map(|p|WeightedPoint3::try_new(Point3::try_new(p["point"][0].as_f64().unwrap(),p["point"][1].as_f64().unwrap(),p["point"][2].as_f64().unwrap()).unwrap(),p["weight"].as_f64().unwrap()).unwrap()).collect();
   let knots=|key:&str|s[key].as_array().unwrap().iter().map(|k|k.as_f64().unwrap()).collect();
   NurbsSurface::try_new_rational(s["degree_u"].as_u64().unwrap()as usize,s["degree_v"].as_u64().unwrap()as usize,s["control_point_count_u"].as_u64().unwrap()as usize,s["control_point_count_v"].as_u64().unwrap()as usize,points,knots("knots_u"),knots("knots_v")).unwrap()
  }).collect::<Vec<_>>();
  let picks=std::array::from_fn(|i|std::array::from_fn(|j|op["picks"][i][j].as_f64().unwrap()));
  let options=SurfaceFilletOptions::try_from_picks(&surfaces[0],&surfaces[1],picks,1.0,true,tol).unwrap();
  let b=fillet_surfaces(&surfaces[0],&surfaces[1],options,tol).unwrap().unwrap();
  println!("{}",json!({"faces":b.faces().len(),"vertices":b.vertices().iter().map(|v|v.point().to_array()).collect::<Vec<_>>() }));
 }
}
