import os,subprocess
from pathlib import Path
p='/tmp/viboceros-fillet-picks-';env=dict(os.environ,CMAKE_BUILD_PARALLEL_LEVEL='10',CARGO_BUILD_JOBS='8')
commands=[
('bridge',['cargo','test','--release','-p','viboceros-smlib','--features','native','--no-fail-fast','--','--nocapture']),
('fillet-oracle',['cargo','test','--release','-p','viboceros-oracle','--features','native-smlib','--lib','surface_fillet','--','--nocapture']),
('clippy',['cargo','clippy','--workspace','--all-targets','--all-features','--','-D','warnings']),
('fmt',['cargo','fmt','--all','--','--check']),
('oracle-build',['cargo','build','--release','-p','viboceros-oracle','--features','native-smlib']),
('python',['python3','-m','unittest','tools.rhino_oracle.test_surface_fillet_probe'])]
for name,command in commands:
 with open(p+name+'.log','w')as log:r=subprocess.run(command,stdout=log,stderr=subprocess.STDOUT,env=env)
 Path(p+name+'.status').write_text(str(r.returncode)+'\n');print(name,r.returncode,flush=True)
 if r.returncode:raise SystemExit(r.returncode)
