import json,os,subprocess,time,sys
from pathlib import Path
p='/tmp/viboceros-reparameterize-input-'
env=dict(os.environ,CARGO_BUILD_JOBS='8',CMAKE_BUILD_PARALLEL_LEVEL='10')
commands=[('ui-full',['cargo','test','-p','viboceros','--bin','viboceros']),('command-focused',['cargo','test','-p','viboceros-command','--lib','reparameterize']),('portable-replay',['cargo','test','-p','viboceros-command','--test','reparameterize_faces']),('native-replay',['cargo','test','-p','viboceros-command','--features','native-smlib','--test','reparameterize_faces'])]
if len(sys.argv)>1:commands=commands[[n for n,args in commands].index(sys.argv[1]):]
for name,args in commands:
 t=time.monotonic()
 with open(p+name+'.log','w')as out:r=subprocess.run(args,env=env,stdout=out,stderr=subprocess.STDOUT)
 Path(p+name+'-runtime.json').write_text(json.dumps(dict(command=args,status=r.returncode,seconds=time.monotonic()-t))+'\n')
 print(name,r.returncode,flush=True)
 if r.returncode:raise SystemExit(r.returncode)
