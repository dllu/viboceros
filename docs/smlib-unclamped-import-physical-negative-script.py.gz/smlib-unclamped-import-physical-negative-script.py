"""The independent witness must reject a changed retained Rhino control point."""
import copy
import json
from pathlib import Path
import runpy
from unittest.mock import patch

target = Path('tools/rhino_oracle/observations/join_curved_certificates.json')
original = Path.read_text
native = json.loads(target.read_text())
changed = copy.deepcopy(native)
row = next(r for r in changed['results'] if r['id'] == 'unclamped-Join-pre')
output = next(o for o in row['value']['objects'] if o['source'] is None)
output['brep']['surfaces'][0]['control_points'][0]['point'][0] += 0.01

def read(path, *args, **kwargs):
    return json.dumps(changed) if path == target else original(path, *args, **kwargs)

with patch.object(Path, 'read_text', read):
    try:
        runpy.run_path('/tmp/viboceros-unclamped-physical.py')
    except AssertionError as error:
        assert str(error) == 'unclamped-Join-pre', error
    else:
        raise AssertionError('changed reference geometry was accepted')
assert json.loads(target.read_text()) == native
print('Changed reference control point was rejected; original capture stayed unchanged')
