import gzip,hashlib,json,math,re,subprocess
from pathlib import Path
from tools.verify_provenance import verify
prefix='/tmp/viboceros-fillet-charts-'
artifacts={}
def sha(data):return hashlib.sha256(data).hexdigest()
def retain(name):
 p=Path(prefix+name);out=Path('docs/fillet-parent-charts-'+name+'.gz')
 out.write_bytes(gzip.compress(p.read_bytes(),mtime=0));artifacts[str(out)]=sha(out.read_bytes());return str(out)
runs=[]
for name in ['geometry','fillet-oracle','command','ui','clippy','portable-check','fmt','oracle-build']:
 r=json.loads(Path(prefix+name+'-runtime.json').read_text());assert r['status']==0,name
 r.update(name=name,log=retain(name+'.log'));retain(name+'-runtime.json')
 counts=re.findall(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored;',Path(prefix+name+'.log').read_text())
 if counts:r.update(zip(['passed','failed','ignored'],map(sum,zip(*[map(int,x)for x in counts]))));assert r['failed']==0
 runs.append(r)
bridge=json.loads(Path(prefix+'bridge-focused-runtime.json').read_text());assert bridge['status']==0
assert '13 passed; 0 failed;' in Path(prefix+'bridge-focused.log').read_text()
bridge.update(name='native-bridge',passed=13,failed=0,log=retain('bridge-focused.log'));retain('bridge-focused-runtime.json');runs.append(bridge)
for name in ['gates.py','finish.py','preserve-provenance.py','sdk.py','sdk-runtime.json','baseline.py','baseline-binary.json','baseline-runtime.json','baseline-request.json','baseline-audit.json','candidate-audit.json','audit.py','audit.log','comparison.json','raw-report.json','tight-sdk.py','tight-sdk.log','record.py','stage.py']:
 retain(name)
for level in ['10','12','14']:
 for suffix in ['request.json','response.json','runtime.json']:retain('tight'+level+'-'+suffix)
for label in ['original-six','original-picks']:
 for version in ['baseline','candidate']:retain(label+'-'+version+'-audit.json')
comparison=json.loads(Path(prefix+'comparison.json').read_text())
assert comparison['same_request_sdk_geometry_matches']==24 and len(comparison['literal_sdk_geometry_failures'])==8
runs.append(dict(name='before-after-protocol-audit',command=['env','PYTHONPATH=.','python3','/tmp/viboceros-fillet-charts-audit.py'],status=0,seconds=comparison['seconds'],log='docs/fillet-parent-charts-audit.log.gz',scope=comparison['scope']))
for level in ['10','12','14']:
 r=json.loads(Path(prefix+'tight'+level+'-response.json').read_text())
 raw=json.loads(Path('tools/rhino_oracle/observations/surface_fillet_charts.json').read_text())
 values={x['id']:x['value']for x in raw['results']}
 assert len(r['results'])==8
 for row in r['results']:assert row['value']==values[row['id']]
radius_witnesses=[]
request=json.loads(Path('tools/rhino_oracle/fixtures/surface_fillet_charts.json').read_text())
reference=json.loads(Path('tools/rhino_oracle/observations/surface_fillet_charts.json').read_text())
for op,row in zip(request['operations'],reference['results']):
 if not op['id'].endswith('anisotropic') or (op['surfaces'][1]['degree_u']==1 and op['surfaces'][1]['degree_v']==1):continue
 radius=op['radius'];samples=row['value']['outputs'][0]['geometry']['faces'][0]['samples']
 # Minimum across every possible signed radius-five cylinder / z=0 plane
 # rolling-ball tube. The Rust oracle test verifies those input assumptions.
 error=min(max(abs(math.hypot(math.hypot(p[0],p[1])-major,p[2]-z)-radius)for p in samples)for major in [5-radius,5+radius]for z in [-radius,radius])
 assert error>1e-4
 radius_witnesses.append(dict(id=op['id'],sampled_radius_error_lower_bound=error))
assert len(radius_witnesses)==8
paths=set(subprocess.check_output(['git','diff','HEAD','--name-only'],text=True).splitlines())
paths.update(str(p)for root in ['crates/viboceros-geometry/src/brep/reparameterize','crates/viboceros-command/src/fillet_surface']for p in Path(root).glob('*.rs'))
paths.update(['crates/viboceros-geometry/src/brep/reparameterize.rs','crates/viboceros-oracle/src/surface_fillet_conditioning.rs','docs/fillet-parent-charts.md','tools/rhino_oracle/fixtures/surface_fillet_charts.json','tools/rhino_oracle/observations/surface_fillet_charts.json','Cargo.toml','Cargo.lock','crates/viboceros-smlib/Cargo.toml','crates/viboceros-smlib/native/surface_fillet.cpp','tools/rhino_oracle/observations/surface_fillet_parents.json','tools/rhino_oracle/fixtures/surface_fillet_parents.json'])
paths.discard('AGENTS.md')
record=dict(date='2026-10-18',compiler=subprocess.check_output(['rustc','--version'],text=True).strip(),baseline_commit='2d049746b4717fdbfea76c2b000f277253cb59e4',native_upstream_commit=subprocess.check_output(['git','-C','third_party/usd-brep','rev-parse','HEAD'],text=True).strip(),change='Preserve original parent surface UV charts through native FilletSrf trim/split; restore full rectangular-face support with correct interior isocurve labels; retain charts through preview, joining, history and 3dm.',completed_runs=runs,reference=dict(sdk='Rhino 8.32.26160.13001',fresh_recipes=32,trimmed_or_split_parent_bodies=72,all_original_domain_endpoints_match=True,same_request_geometric_matches=24,sampled_sdk_radius_witnesses=radius_witnesses,literal_sdk_geometry_failures=comparison['literal_sdk_geometry_failures'],canonical_input_geometry_matches=32,tighter_sdk_controls=dict(recipes_per_tolerance=8,tolerances=[1e-10,1e-12,1e-14],complete_values_identical_to_original=True),capture_scope='Public RhinoCommon SDK through the owned headless oracle. Raw observations are unchanged except JSON whitespace. Eight inaccurate anisotropic curved fits remain explicit literal SDK geometry failures. Canonical references have exactly equal normalized input NURBS and the same physical picks; independent radius witnesses verify the failures.'),protocol_regressions=dict(raw_full_protocol_matches=comparison['raw_matches'],raw_full_protocol_mismatches=comparison['raw_mismatches'],existing_parent_complete_values_unchanged=comparison['old_parent_complete_values_unchanged'],fillet_only_contracts=comparison['fillet_only_contracts'],fresh_case_fillet_complete_values_unchanged=32,spatial_parent_vertices_edges_and_surface_control_points_unchanged=True,baseline_executable_scope=json.loads(Path(prefix+'baseline-binary.json').read_text())['source_scope']),coverage=['Shared spatial edges, rational holes, seams, poles, reversed faces, large chart offsets, anisotropic UV ranges, invalid or duplicate requests, and declined insufficient coordinate precision.','Existing extreme spatial scale and signed-weight-gauge native parent controls; no component or model spatial tolerance widening.','All 64 old/new parent recipes replay through the command; full underlying support restored for clipped reversed faces.','Joined non-unit parent charts survive 3dm readback; interactive previews, acceptance, undo and redo retain charts.'],limitations=['The eight raw SDK geometry mismatches remain failures; accurate canonical comparisons do not establish same-request SDK geometry parity for those cases.','Raw full-protocol definitions, topology and metadata differ; bounds, closest distances, sampled regions and analytic witnesses establish the stated geometric scope, not continuous global Rhino equality.','Curved Extend=Yes, arbitrary trimmed fillet sources, polysurface-face editing and the existing closed-cylinder certificate limit remain pending.','No C++ or FFI implementation changed, and no new ASan or general performance qualification is claimed.'],source_sha256={p:sha(Path(p).read_bytes())for p in sorted(paths)},artifact_sha256=artifacts)
path=Path('docs/fillet-parent-charts-validation.json');path.write_text(json.dumps(record,indent=2)+'\n');print(json.dumps(dict(record=str(path),verified_entries=verify(record),runs=runs),indent=2))
