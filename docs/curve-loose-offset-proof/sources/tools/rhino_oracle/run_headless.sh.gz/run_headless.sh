#!/usr/bin/env bash
set -euo pipefail

if (( $# < 2 )); then
    echo "usage: $0 {compare|rhino|viboceros} REQUEST [oracle options...] | exec COMMAND [args...]" >&2
    exit 2
fi

for dependency in xvfb-run Xvfb i3 python3; do
    if ! command -v "$dependency" >/dev/null 2>&1; then
        echo "headless Rhino oracle requires '$dependency'" >&2
        exit 2
    fi
done

ORACLE_REPO_ROOT=$(cd "$(dirname "${BASH_SOURCE[0]}")/../.." && pwd)
ORACLE_I3_CONFIG="$ORACLE_REPO_ROOT/tools/rhino_oracle/i3-headless.conf"
ORACLE_I3_LOG="${TMPDIR:-/tmp}/viboceros-rhino-oracle-i3-$$.log"
export ORACLE_I3_CONFIG ORACLE_I3_LOG
cd "$ORACLE_REPO_ROOT"

# libwayland can connect to wayland-0 even without WAYLAND_DISPLAY. Give all
# child clients a private runtime directory as well as their private X display.
ORACLE_RUNTIME_DIR=$(mktemp -d "${TMPDIR:-/tmp}/viboceros-oracle-runtime.XXXXXXXX")
export ORACLE_RUNTIME_DIR
trap 'rm -rf -- "$ORACLE_RUNTIME_DIR"' EXIT

xvfb-run -a -s '-screen 0 1920x1080x24' bash -c '
    unset WAYLAND_DISPLAY WAYLAND_SOCKET SWAYSOCK I3SOCK
    export XDG_RUNTIME_DIR="$ORACLE_RUNTIME_DIR"
    export VIBOCEROS_ORACLE_HEADLESS="$DISPLAY"
    # Compositor-specific libraries can mix incompatible xkbcommon versions
    # with the system i3 binary. Let the window manager use its own libraries.
    env -u LD_LIBRARY_PATH -u LD_PRELOAD i3 -a -c "$ORACLE_I3_CONFIG" >"$ORACLE_I3_LOG" 2>&1 &
    if [[ $1 == exec ]]; then
        shift
        exec "$@"
    fi
    exec python3 -m tools.rhino_oracle "$@"
' viboceros-rhino-oracle "$@"
