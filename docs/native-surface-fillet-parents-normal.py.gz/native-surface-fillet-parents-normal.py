import subprocess,time,json
from pathlib import Path
p='/tmp/viboceros-fillet-parents-';b=Path('target/release/build/viboceros-smlib-d4f77638f5302455/out/build')
for name,source in [('normal-parents','tools/usd_brep/surface_fillet_parents_probe.cpp'),('normal-original','tools/usd_brep/surface_fillet_probe.cpp')]:
 args=['c++','-std=c++17','-O2','-DNDEBUG','-Wall','-Wextra','-Werror','-I','crates/viboceros-smlib/native',source,str(b/'libviboceros_smlib.a'),str(b/'libSM_API.a'),str(b/'libSMLib.a'),'-ltbb','-ltbbmalloc','-o',p+name];start=time.monotonic()
 with open(p+name+'-build.log','w')as log:r=subprocess.run(args,stdout=log,stderr=log)
 Path(p+name+'-build.status').write_text(str(r.returncode)+'\n');print(name,'build',r.returncode,flush=True)
 if r.returncode:raise SystemExit(r.returncode)
 with open(p+name+'.jsonl','w')as out,open(p+name+'.log','w')as log:r=subprocess.run([p+name],stdout=out,stderr=log)
 Path(p+name+'.status').write_text(str(r.returncode)+'\n');Path(p+name+'-runtime.json').write_text(json.dumps(dict(build_command=args,status=r.returncode,seconds=time.monotonic()-start))+'\n');print(name,r.returncode,flush=True)
 if r.returncode:raise SystemExit(r.returncode)
