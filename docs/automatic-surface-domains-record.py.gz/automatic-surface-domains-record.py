import gzip,hashlib,json,re,subprocess
from pathlib import Path
from tools.verify_provenance import verify
p='/tmp/viboceros-auto-surface-';artifacts={}
def sha(data):return hashlib.sha256(data).hexdigest()
def retain(name):
 path=Path('docs/automatic-surface-domains-'+name+'.gz');path.write_bytes(gzip.compress(Path(p+name).read_bytes(),mtime=0));artifacts[str(path)]=sha(path.read_bytes());return str(path)
runs=[]
for name in ['geometry','portable-replay','native-replay','native-command','portable-focused','post-cleanup-portable-replay','post-cleanup-native-replay','post-cleanup-portable-focused','clippy','portable-check','fmt','python']:
 r=json.loads(Path(p+name+'-runtime.json').read_text());assert r['status']==0,name
 r.update(name=name,log=retain(name+'.log'));retain(name+'-runtime.json')
 if name in ['portable-replay','native-replay','native-command','portable-focused']:r['command_helper_version']='before iterator-only cleanup; exact source retained as artifact'
 counts=re.findall(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored;',Path(p+name+'.log').read_text())
 if counts:r.update(zip(['passed','failed','ignored'],map(sum,zip(*[map(int,c)for c in counts]))));assert r['failed']==0
 runs.append(r)
for name in ['tested-before-iterator-cleanup.rs','clippy-before-cleanup.log','post-cleanup-gates.py','sdk.py','sdk.log','sdk-main.log','split-admission-diagnostic.json','split-admission-probe.py','split-admission-source.3dm','pole-diagnostic.log','gates.py','preserve-provenance.py','audit.log','comparison.json','record.py','stage.py','finish.py']:
 retain(name)
for label in ['main','tight','loose']:
 for suffix in ['request.json','runtime.json']:retain(label+'-'+suffix)
 raw=json.loads(Path(p+label+'-response.json').read_text());saved=json.loads(Path('tools/rhino_oracle/observations/reparameterize_automatic_'+label+'.json').read_text());assert raw==saved
 original=json.loads(Path(p+label+'-request.json').read_text());portable=json.loads(Path('tools/rhino_oracle/fixtures/reparameterize_automatic_'+label+'.json').read_text())
 for a,b in zip(original['operations'],portable['operations']):
  assert Path(a['artifact_path'])==Path(b['artifact_path']).resolve()
  assert {k:v for k,v in a.items()if k!='artifact_path'}=={k:v for k,v in b.items()if k!='artifact_path'}
 assert len(raw['results'])==(20 if label=='main'else 2)
 for row in raw['results']:
  v=row['value'];assert v['success']
  for state in ['before','after','undo','redo']:assert v[state]['geometry']['valid']
  for state in ['after','undo','redo']:
   for key in ['name','object_text','geometry_text','groups','selected']:assert v[state][key]==v['before'][key]
  assert v['undo']['geometry']==v['before']['geometry'] and v['redo']['geometry']==v['after']['geometry']
audit=json.loads(Path(p+'audit-runtime.json').read_text());assert audit['status']==0
audit.update(name='domain-policy-audit',log='docs/automatic-surface-domains-audit.log.gz');runs.append(audit);retain('audit-runtime.json')
comparison=json.loads(Path(p+'comparison.json').read_text());assert comparison['automatic_cases']==34 and comparison['candidate_domain_failures']==0
paths=set(subprocess.check_output(['git','diff','HEAD','--name-only'],text=True).splitlines());paths.discard('AGENTS.md')
paths.update(str(f)for f in Path('tools/rhino_oracle/fixtures/reparameterize_automatic').glob('*.3dm'))
paths.update(['docs/automatic-surface-domains.md','tools/rhino_oracle/reparameterize_automatic_cases.py','Cargo.toml','Cargo.lock','crates/viboceros-geometry/src/integration/cash_karp.rs','tools/rhino_oracle/observations/reparameterize_faces.json','tools/rhino_oracle/fixtures/reparameterize_faces.json'])
for label in ['main','tight','loose']:
 paths.add('tools/rhino_oracle/observations/reparameterize_automatic_'+label+'.json');paths.add('tools/rhino_oracle/fixtures/reparameterize_automatic_'+label+'.json')
record=dict(date='2026-10-18',baseline_commit='8bb4b9fa2d7a7185976adb1f9cb6a0ca50c23d03',compiler=subprocess.check_output(['rustc','--version'],text=True).strip(),opennurbs_commit=subprocess.check_output(['git','-C','third_party/opennurbs','rev-parse','HEAD'],text=True).strip(),change='Match Automatic surface domains using eleven boundary-inclusive isocurves, collapse recognition and the existing Cash-Karp length estimate. Add opt-in rational-line quadrature while retaining precise queries and the previous checkpoint policy.',completed_runs=runs,reference=dict(engine='Rhino 8.32.26160.13001',existing_commands=30,fresh_main_commands=20,document_tolerance_controls=4,source_files=24,domains='Literal domains pass at the caller epsilon capped at 1e-8; model geometry uses caller epsilon. No normalization of raw observations or widening of acceptance tolerance.',admission='The main capture uses public no-kink object insertion to preserve the supplied source graph. Initial generic insertion split the unclamped source; the failed observation, shared input and then-current probe are retained. Tight/loose controls used the preceding probe on regular sources whose admission preserved their face count; that probe version is retained.',request_paths='The portable requests differ from the executed requests only in replacing absolute artifact destinations with repo-relative paths.'),policy_comparison=comparison,source_scope='The baseline comparison evaluates the unchanged public estimated_size formula on the same loaded sources; the baseline Git call sites establish that it was the prior command policy. It is not a retained old-executable runtime comparison.',coverage=['The original explicit/trimmed/polysurface cases now require literal Automatic domain agreement as well as geometry, topology, attributes, groups, geometry text, history and 3dm readback.','Fresh cases include weighted bilinear and quadratic patches, unclamped and split knots, rational changes of parameter, degree elevation, cones, sphere transposition, affine/anisotropic UV ranges, spatial scale, translation and common weight gauge.','Raw single-surface targets match face-target results; zero-width requests preserve redo, and an interior collapsed sample remains supported.','New quadrature and boundary-coincidence controls retain precise length/checkpoint behavior, large parameter origins, signed gauges and strict exact-collapse classification.'],limitations=['Inference and replay qualify the recorded inputs, not private Rhino implementation identity, continuous global Rhino equality, arbitrary conditioning or general performance.','Numerical quadrature estimates have bounded resource use and estimated local error, not a rigorous continuous error certificate.','Source/trim acceptance tolerances and general estimated_size remain independent; no C++/FFI changes or new ASan claim.','Viewport face picking, block-instance copying and curved FilletSrf extension remain separate unfinished work.'],validation_order='Release suites passed before an iterator-only Clippy cleanup in the command helper. That exact helper and the lint failure are retained. Final-source portable/native command replays, focused portable units, domain audit, Clippy, workspace check, format and Python checks pass afterward.',source_sha256={f:sha(Path(f).read_bytes())for f in sorted(paths)},artifact_sha256=artifacts)
path=Path('docs/automatic-surface-domains-validation.json');path.write_text(json.dumps(record,indent=2)+'\n');print(json.dumps(dict(record=str(path),verified_entries=verify(record),runs=runs),indent=2))
