import json,subprocess
from pathlib import Path
p='/tmp/viboceros-drop-accuracy-'
b=Path('target/debug/build/viboceros-smlib-e982af202de3f65b/out/build')
command=['c++','-std=c++17','-O2','-DNDEBUG','-I','crates/viboceros-smlib/native','/tmp/viboceros-fillet-trims-diagnostic.cpp',str(b/'libviboceros_smlib.a'),str(b/'libSM_API.a'),str(b/'libSMLib.a'),'-ltbb','-ltbbmalloc','-o',p+'fillet-trims']
with open(p+'fillet-trims-build.log','w')as log:r=subprocess.run(command,stdout=log,stderr=subprocess.STDOUT)
assert r.returncode==0
with open(p+'fillet-trims.jsonl','w')as out,open(p+'fillet-trims.stderr','w')as err:r=subprocess.run([p+'fillet-trims'],stdout=out,stderr=err,timeout=180)
Path(p+'fillet-trims.status').write_text(str(r.returncode)+'\n');assert r.returncode==0
s=Path('/tmp/viboceros-fillet-trims-stations.py').read_text().replace('/tmp/viboceros-fillet-trims-diagnostic.jsonl',p+'fillet-trims.jsonl').replace('/tmp/viboceros-fillet-trims-stations-analysis.json',p+'fillet-trims-analysis.json')
Path(p+'fillet-trims-inspect.py').write_text(s)
with open(p+'fillet-trims-analysis.log','w')as log:r=subprocess.run(['python3',p+'fillet-trims-inspect.py'],stdout=log,stderr=subprocess.STDOUT)
assert r.returncode==0
old=[json.loads(x)for x in Path('/tmp/viboceros-fillet-trims-diagnostic.jsonl').read_text().splitlines()]
new=[json.loads(x)for x in Path(p+'fillet-trims.jsonl').read_text().splitlines()]
a=json.loads(Path(p+'fillet-trims-analysis.json').read_text());old_a=json.loads(Path('/tmp/viboceros-fillet-trims-stations-analysis.json').read_text());summary=[]
for x,y,old_stats,stats in zip(old,new,old_a,a):
 assert x['status']==y['status']==0 and x['exported']==y['exported']==0
 curves=lambda r:[{'curve':e['curve'],'interval':e['interval']}for e in r['edges']]
 topology=lambda r:[(t['edge'],t['reversed'])for t in r['trims']]
 assert x['vertices']==y['vertices']and x['surfaces']==y['surfaces']and curves(x)==curves(y)and topology(x)==topology(y)
 caps=[]
 for old_t,t in zip(old_stats['records'],stats['records']):
  if t['edge']in[1,3]:caps.append(dict(edge=t['edge'],previous_closest_witness_gap=old_t['closest_gap'],repaired_closest_witness_gap=t['closest_gap'],repaired_synced_max=t['synchronized_maximum_error'],caller_budget=1e-8))
 summary.append(dict(normalized=x['normalized'],extend=x['extend'],defining_geometry_unchanged=True,connectivity_and_use_orientation_unchanged=True,cap_witnesses=caps,scope='Closest locus distances are evaluated independently at the worst synchronized station on each trim. This is a diagnostic witness, not a global bound on closest locus distance. Native tolerance metadata changes are retained in raw snapshots; comparison uses original caller budget.'))
Path(p+'fillet-trims-summary.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps(summary),flush=True)
