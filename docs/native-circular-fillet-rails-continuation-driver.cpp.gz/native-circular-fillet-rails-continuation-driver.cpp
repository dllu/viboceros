#define main retained_probe_main
#include "/home/dllu/proj/viboceros/tools/usd_brep/surface_fillet_probe.cpp"
#undef main
int main() {
 std::cout<<std::setprecision(17)<<std::boolalpha;
 for(bool normalized:{false,true})for(double factor:{0.,.01,.05,.1,.125,.5,1.}) {
  auto a=plane(false,0,10),b=cylinder();a.points={-10,-10,0,1,10,-10,0,1,-10,10,0,1,10,10,0,1};
  const double scale=normalized?std::sqrt(800.):1.;const double origin=normalized?-10.:0.;
  for(auto *source:{&a,&b})for(size_t i=0;i<source->points.size();i+=4) {
   source->points[i]=(source->points[i]-origin)/scale;
   source->points[i+1]=(source->points[i+1]-origin)/scale;
   source->points[i+2]/=scale;
  }
  auto av=a.view(),bv=b.view();VbSolid *raw=nullptr;char error[2048]={};int sides[2]={1,1};
  int status=vb_surface_fillet(&av,&bv,1/scale,sides,1,factor,1e-8/scale,&raw,error,sizeof error);
  std::unique_ptr<VbSolid,decltype(&vb_solid_free)> owner(raw,&vb_solid_free);
  std::cout<<"{\"normalized\":"<<normalized<<",\"factor\":"<<factor<<",\"status\":"<<status<<",\"error\":\""<<error<<"\"";
  if(owner) {
   VbBrep *out=nullptr;int exported=vb_shape_brep(owner.get(),2.5e-9/scale,&out,error,sizeof error);
   std::unique_ptr<VbBrep,decltype(&vb_brep_free)> data(out,&vb_brep_free);
   std::cout<<",\"exported\":"<<exported;
   if(data) {VbBrepView view{};check(vb_brep_view(data.get(),&view)==0);
    std::cout<<",\"vertices\":[";for(size_t i=0;i<view.vertex_count;++i){if(i)std::cout<<',';double p[3]={view.vertices[i].point[0]*scale+origin,view.vertices[i].point[1]*scale+origin,view.vertices[i].point[2]*scale};array(p,3);}std::cout<<"],\"surface_counts\":[";
    for(size_t i=0;i<view.face_count;++i){if(i)std::cout<<',';std::cout<<'['<<view.faces[i].surface.count[0]<<','<<view.faces[i].surface.count[1]<<']';}std::cout<<']';
   }
  }
  std::cout<<"}\n";
 }
}
