import json
from pathlib import Path
from tools.rhino_oracle.client import OracleClient
from tools.rhino_oracle.audit import compare_audit_response
p='/tmp/viboceros-drop-accuracy-'
read=lambda name:json.loads(Path(name).read_text())
write=lambda name,value:Path(p+name+'.json').write_text(json.dumps(value,indent=2)+'\n')
client=OracleClient(native_smlib=True)
request=read('tools/rhino_oracle/fixtures/curve_contacts_tolerance.json')
sdk=read('tools/rhino_oracle/observations/curve_contacts_tolerance.json')
native=client.run_viboceros_audit(request,timeout=600.)
write('contact-audit',native)
report=compare_audit_response(native,sdk,1e-8,1e-12,request=request)
write('contact-report',report.as_dict());assert report.passed and report.matched==5 and report.native_failed==0
request=read('tools/rhino_oracle/fixtures/surface_fillet.json')
sdk=read('tools/rhino_oracle/observations/surface_fillet.json')
native=client.run_viboceros_audit(request,timeout=600.)
write('fillet-audit',native)
report=compare_audit_response(native,sdk,1e-8,1e-12,request=request)
write('fillet-raw-report',report.as_dict())
expected={r['id']:r['value']for r in sdk['results']}
failures=[];compared=0;points=0;point_error=0.;bound_error=0.;by_recipe=[]
for outcome in native['outcomes']:
 if outcome['status']=='failure':failures.append(outcome);continue
 row=outcome['result'];a=row['value'];b=expected[row['id']]
 assert a['source_unchanged']and b['source_unchanged']
 assert len(a['outputs'])==len(b['outputs'])==1
 a,b=a['outputs'][0],b['outputs'][0];assert a['valid']and b['valid']
 assert len(a['closest_points'])==len(b['closest_points'])==4
 pe=max(abs(x-y)for q,r in zip(a['closest_points'],b['closest_points'])for x,y in zip(q,r))
 be=max(abs(x-y)for q,r in zip(a['bounds'],b['bounds'])for x,y in zip(q,r))
 point_error=max(point_error,pe);bound_error=max(bound_error,be);by_recipe.append(dict(id=row['id'],maximum_point_difference=pe,maximum_bounds_difference=be))
 points+=4;compared+=1
assert compared>=5 and points>=20
for row in by_recipe:
 if row['id']!='cylinder-True':assert row['maximum_point_difference']<=1e-8 and row['maximum_bounds_difference']<=1e-8
summary=dict(contact_complete_matches=5,fillet_followup=dict(executed=6,sampled_successes=compared,paired_closest_points=points,maximum_point_difference=point_error,maximum_bounds_difference=bound_error,by_recipe=by_recipe,complete_raw_matches=report.matched,complete_raw_mismatches=report.as_dict()['mismatched'],failures=failures,scope='Complete captures and actual failures retained. Successful samples do not prove continuous global Rhino parity; no raw NURBS/topology differences were normalized away.'))
write('comparison',summary);print(json.dumps(summary),flush=True)
