import json,os,subprocess,time
from pathlib import Path
p='/tmp/viboceros-fillet-charts-';args=['cargo','test','--release','-p','viboceros-smlib','--features','native','--test','surface_fillet_picks'];start=time.monotonic()
with open(p+'bridge-focused.log','w')as log:
 r=subprocess.run(args,stdout=log,stderr=subprocess.STDOUT,env=dict(os.environ,CMAKE_BUILD_PARALLEL_LEVEL='10',CARGO_BUILD_JOBS='8'))
Path(p+'bridge-focused-runtime.json').write_text(json.dumps(dict(command=args,status=r.returncode,seconds=time.monotonic()-start))+'\n')
if r.returncode:raise SystemExit(r.returncode)
with open(p+'audit.log','w')as log:
 r=subprocess.run(['python3',p+'audit.py'],stdout=log,stderr=subprocess.STDOUT,env=dict(os.environ,PYTHONPATH='.'))
raise SystemExit(r.returncode)
