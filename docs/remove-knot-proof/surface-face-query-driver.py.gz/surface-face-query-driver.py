import json,shutil
from pathlib import Path
from tools.rhino_oracle.client import OracleClient
original=shutil.copyfile
patch='''def _surface_closest_point(operation, iterations):
    surface = _nurbs_surface_from_definition(operation["surface"])
    brep = Rhino.Geometry.Brep.CreateFromSurface(surface)
    file = Rhino.FileIO.File3dm.Read("Z:\\\\home\\\\dllu\\\\proj\\\\viboceros\\\\tools\\\\rhino_oracle\\\\fixtures\\\\remove_knot_command\\\\"+operation['id']+".3dm")
    try:
        geometry=list(file.Objects)[0].Geometry
        values={}
        for label,target in [('nurbs',surface),('constructed_face',brep.Faces[0]),('source_face',geometry.Faces[0])]:
            out=[]
            for point in operation['points']:
                p=_point(point);found,u,v=target.ClosestPoint(p)
                out.append(dict(found=bool(found),parameters=[u,v],point=_xyz(target.PointAt(u,v)),distance=target.PointAt(u,v).DistanceTo(p)))
            values[label]=out
        return values,0
    finally:
        file.Dispose();brep.Dispose();surface.Dispose()
'''
def copy(source,destination,*args,**kw):
    result=original(source,destination,*args,**kw)
    if Path(destination).name=='rhino_worker.py':
        p=Path(destination);s=p.read_text();a=s.index('def _surface_closest_point(');b=s.index('def _evaluate_uv_macro(',a);p.write_text(s[:a]+patch+'\n\n'+s[b:])
    return result
shutil.copyfile=copy
capture=json.loads(Path('tools/rhino_oracle/observations/remove_knot_command.json').read_text());ops=[]
for name in('periodic_surface_V_U','periodic_surface_U_V'):
 v=next(r['value']for r in capture['results']if r['id']==name);s=v['before'][0]['geometry']['surfaces'][0]
 surface=dict(degree_u=s['degree'][0],degree_v=s['degree'][1],control_point_count_u=s['control_count'][0],control_point_count_v=s['control_count'][1],knots_u=s['knots_u'],knots_v=s['knots_v'],control_points=s['control_points'])
 ops.append(dict(op='surface_closest_point',id=name,surface=surface,points=v['picks']))
q=dict(protocol_version=1,iterations=1,tolerance=dict(absolute=1e-6,relative=1e-12,angular=1e-6),operations=ops)
r=OracleClient(settings_scheme='VibocerosOracleRemoveKnotFace20261019').run_rhino(q,timeout=240.)
Path('/tmp/viboceros-remove-knot-face-query.json').write_text(json.dumps(r,indent=2));print([(x['id'],x['value'])for x in r['results']])
