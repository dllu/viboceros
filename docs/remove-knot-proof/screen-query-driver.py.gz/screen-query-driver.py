import json,shutil,tempfile
from pathlib import Path
from tools.rhino_oracle.client import OracleClient
original=shutil.copyfile
insert='''        if op['id']=='top':R.RhinoApp.RunScript('_SetView _World _Top',False)
        vp=doc.Views.ActiveView.ActiveViewport
        def pixel(p):
            q=vp.WorldToClient(p);return [q.X,q.Y]
        s=target.ToNurbsSurface()
        try:
            state['screen']=dict(name=vp.Name,perspective=bool(vp.IsPerspectiveProjection),camera=host['_xyz'](vp.CameraLocation),target=host['_xyz'](vp.CameraTarget),pick=pixel(G.Point3d(*state['picks'][0])),lines=[])
            for t in sorted(set(float(k)for k in s.KnotsV if s.Domain(1).Min<k<s.Domain(1).Max)):
                state['screen']['lines'].append(dict(parameter=t,points=[pixel(s.PointAt(s.Domain(0).ParameterAt(i/32.),t))for i in range(33)]))
        finally:s.Dispose()
'''
def copy(source,destination,*args,**kw):
    result=original(source,destination,*args,**kw)
    if Path(destination).name=='remove_knot_command_probe.py':
        p=Path(destination);s=p.read_text().replace("        return R.RhinoApp.RunScript(state['macro'],echo)",insert+"        return R.RhinoApp.RunScript(state['macro'],echo)")
        s=s.replace("value.update(recipe=op,", "value.update(screen=state.get('screen'),recipe=op,")
        p.write_text(s)
    return result
shutil.copyfile=copy
from tools.rhino_oracle.generate_remove_knot_command import request
base=next(o for o in request()['operations']if o['id']=='periodic_surface_V_U')
with tempfile.TemporaryDirectory(prefix='viboceros-remove-screen-')as folder:
 ops=[dict(base,id=name,artifact_path=str(Path(folder)/(name+'.3dm')))for name in('default','top')]
 q=dict(protocol_version=1,iterations=1,tolerance=dict(absolute=1e-6,relative=1e-12,angular=1e-6),operations=ops)
 r=OracleClient(settings_scheme='VibocerosOracleRemoveKnotScreen20261019').run_rhino(q,timeout=240.)
 Path('/tmp/viboceros-remove-knot-screen-query.json').write_text(json.dumps(r,indent=2))
 for row in r['results']:
  v=row['value'];print(row['id'],v['screen'],v['after'][0]['geometry']['surfaces'][0]['knots_v'])
