import gzip,json,subprocess,time
from pathlib import Path
p='/tmp/viboceros-fillet-charts-';start=time.monotonic();request=json.loads(Path('tools/rhino_oracle/fixtures/surface_fillet_parents.json').read_text());new=json.loads(Path('tools/rhino_oracle/fixtures/surface_fillet_charts.json').read_text());request['operations']+=new['operations'];Path(p+'baseline-request.json').write_text(json.dumps(request,indent=2)+'\n')
subprocess.run([p+'baseline-oracle','--audit',p+'baseline-request.json',p+'baseline-audit.json'],check=True,timeout=600.)
out=json.loads(Path(p+'baseline-audit.json').read_text());assert len(out['outcomes'])==64 and all(r['status']=='success'for r in out['outcomes'])
expected=json.loads(gzip.decompress(Path('docs/native-surface-fillet-parents-candidate-audit.json.gz').read_bytes()))
values={r['result']['id']:r['result']['value']for r in out['outcomes']};old={r['result']['id']:r['result']['value']for r in expected['outcomes']};assert all(values[k]==v for k,v in old.items())
Path(p+'baseline-runtime.json').write_text(json.dumps(dict(seconds=time.monotonic()-start,old_complete_values_matched=len(old),new_chart_cases=len(new['operations'])))+'\n');print('baseline old values matched:',len(old),'new chart cases:',len(new['operations']),flush=True)
