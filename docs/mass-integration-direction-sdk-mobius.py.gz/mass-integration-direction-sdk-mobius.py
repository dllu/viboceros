import copy,json,time
from pathlib import Path
from tools.rhino_oracle.client import OracleClient
base=json.loads(Path('/tmp/viboceros-fillet-extension-shape-sdk-request.json').read_text());ops=[]
for op in base['operations']:
 if op['id'].startswith('mobius-'):
  op=copy.deepcopy(op);k=float(op['id'].split('-')[1]);original=op['picks'][1][0]
  op['picks'][1][0]=original/(k-(k-1)*original);op['id']+='-fixed-physical-pick';ops.append(op)
base['operations']=ops
p='/tmp/viboceros-fillet-extension-mobius-sdk-';Path(p+'request.json').write_text(json.dumps(base,indent=2)+'\n')
start=time.monotonic();r=OracleClient(settings_scheme='VibocerosOracleFilletMobius20261018').run_rhino(base,timeout=300.)
Path(p+'response.json').write_text(json.dumps(r,indent=2)+'\n')
Path(p+'runtime.json').write_text(json.dumps(dict(elapsed_seconds=time.monotonic()-start,recipes=len(ops)),indent=2)+'\n')
for row in r['results']:print(row['id'],[o['geometry']['vertices']for o in row['value']['outputs']],flush=True)
