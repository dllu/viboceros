import json,math
from pathlib import Path
from tools.rhino_oracle.client import OracleClient
observed=json.loads(Path('tools/rhino_oracle/observations/surface_patch_geometry.json').read_text())
native=json.loads(Path('/tmp/viboceros-surface-patch-sdk-2-audit.json').read_text())
reference={r['id']:r['value']for r in observed['results']}
outputs={r['result']['id']:r['result']['value']for r in native['outcomes']}
request=dict(protocol_version=1,iterations=1,operations=[])
ids=['native-patch-3-0','native-patch-3-1']
for identifier in ids:
 for label,value in [('cpp',outputs[identifier]),('sdk',reference[identifier])]:
  definition=dict(degree_u=value['degree'][0],degree_v=value['degree'][1],
   control_point_count_u=value['control_count'][0],control_point_count_v=value['control_count'][1],
   control_points=value['control_points'],knots_u=value['knots_u'],knots_v=value['knots_v'])
  for i in range(9):
   for j in range(9):
    u=value['domain_u'][0]+(value['domain_u'][1]-value['domain_u'][0])*i/8
    v=value['domain_v'][0]+(value['domain_v'][1]-value['domain_v'][0])*j/8
    request['operations'].append(dict(op='nurbs_surface_evaluate',id=label+'-'+identifier+'-'+str(i)+'-'+str(j),u=u,v=v,**definition))
Path('/tmp/viboceros-surface-patch-equivalence-request.json').write_text(json.dumps(request,indent=2)+'\n')
response=OracleClient(settings_scheme='VibocerosOraclePatchEquivalent20261018').run_rhino(request,timeout=180.)
Path('/tmp/viboceros-surface-patch-equivalence-rhino.json').write_text(json.dumps(response,indent=2)+'\n')
values={r['id']:r['value']for r in response['results']}
summary=[]
for identifier in ids:
 errors={key:0. for key in ['point','derivative_u','derivative_v','normal']}
 for i in range(9):
  for j in range(9):
   suffix=identifier+'-'+str(i)+'-'+str(j)
   a,b=values['cpp-'+suffix],values['sdk-'+suffix]
   for key in errors:
    assert len(a[key])==len(b[key])==3
    for x,y in zip(a[key],b[key]):
     assert math.isfinite(x)and math.isfinite(y)
     errors[key]=max(errors[key],abs(x-y))
 summary.append(dict(id=identifier,samples=81,max_absolute_differences=errors,passed=max(errors.values())<=1e-10))
report=dict(engine='rhino',sdk_evaluations=len(response['results']),comparison_pairs=162,
            absolute_epsilon=1e-10,normalization='None. Both retained surface definitions are evaluated by Rhino at identical parameter stations.',results=summary)
Path('/tmp/viboceros-surface-patch-equivalence-report.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report),flush=True)
assert all(r['passed']for r in summary)
