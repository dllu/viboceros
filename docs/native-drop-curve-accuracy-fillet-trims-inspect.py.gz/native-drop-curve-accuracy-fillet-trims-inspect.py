import bisect,json,math
from pathlib import Path

def basis(degree,count,knots,t):
 if count==1:return [(0,1.)]
 lo,hi=knots[degree],knots[count]
 if t<lo-1e-12*(hi-lo)or t>hi+1e-12*(hi-lo):raise ValueError(('outside surface',t,lo,hi))
 t=min(max(t,lo),hi);span=min(max(bisect.bisect_right(knots,t)-1,degree),count-1)
 n=[1.]+[0.]*degree;left=[0.]*(degree+1);right=left.copy()
 for j in range(1,degree+1):
  left[j]=t-knots[span+1-j];right[j]=knots[span+j]-t;saved=0.
  for r in range(j):
   denominator=right[r+1]+left[j-r];temp=n[r]/denominator if denominator else 0.
   n[r]=saved+right[r+1]*temp;saved=left[j-r]*temp
  n[j]=saved
 return [(span-degree+i,w)for i,w in enumerate(n)]
def evaluate(c,u,v=0.):
 bu=basis(c['degree'][0],c['count'][0],c['knots'][0],u)
 bv=basis(c['degree'][1],c['count'][1],c['knots'][1],v)
 p=c['points_xyzw'];result=[0.]*4
 for i,a in bu:
  for j,b in bv:
   k=4*(j*c['count'][0]+i);w=a*b*p[k+3]
   for axis in range(3):result[axis]+=w*p[k+axis]
   result[3]+=w
 return tuple(x/result[3]for x in result[:3])
def domain(c):return [c['knots'][0][c['degree'][0]],c['knots'][0][c['count'][0]]]
def closest(edge,point):
 c=edge['curve'];lo,hi=edge['interval'];stations=sorted({lo,hi,*[x for x in c['knots'][0]if lo<x<hi]})
 stations=sorted(stations+[(a+b)/2 for a,b in zip(stations,stations[1:])])
 f=lambda t:math.dist(point,evaluate(c,t))
 i=min(range(len(stations)),key=lambda i:f(stations[i]));a=stations[max(i-1,0)];b=stations[min(i+1,len(stations)-1)]
 q=(math.sqrt(5)-1)/2;c0=b-q*(b-a);d=a+q*(b-a)
 for _ in range(80):
  if f(c0)<f(d):b=d;d=c0;c0=b-q*(b-a)
  else:a=c0;c0=d;d=a+q*(b-a)
 t=min([a,b,(a+b)/2,stations[i]],key=f)
 return t,f(t),evaluate(c,t)
rows=[json.loads(x)for x in Path('/tmp/viboceros-drop-accuracy-fillet-trims.jsonl').read_text().splitlines()];report=[]
for row in rows:
 print('case',row['normalized'],row['extend'],'status',row['status'],row.get('exported'))
 if row.get('exported')!=0:continue
 s=row['surfaces'][0];scale=row['scale'];origin=-10 if row['normalized']else 0
 world=lambda p:(p[0]*scale+origin,p[1]*scale+origin,p[2]*scale)
 print('surface degree/count',s['degree'],s['count'])
 records=[]
 for trim in row['trims']:
  edge=row['edges'][trim['edge']];uv=trim['curve'];lo,hi=domain(uv);samples=[]
  stations={lo,hi};knots=sorted({x for x in uv['knots'][0]if lo<=x<=hi})
  for a,b in zip(knots,knots[1:]):
   for i in range(9):
    for f in [i/8,.5*(1-math.cos(math.pi*i/8))]:stations.add(a*(1-f)+b*f)
  for t in sorted(stations):
   f=(t-lo)/(hi-lo);p=evaluate(uv,t);lift=evaluate(s,p[0],p[1]);e=evaluate(edge['curve'],edge['interval'][0]+(edge['interval'][1]-edge['interval'][0])*f)
   samples.append((math.dist(lift,e),f,p,lift))
  worst=max(samples);param,gap,q=closest(edge,worst[3]);p=world(worst[3]);q=world(q)
  item=dict(edge=trim['edge'],reversed=trim['reversed'],allowed=edge['tolerance']*scale,synchronized_maximum_error=worst[0]*scale,witness_fraction=worst[1],uv=worst[2],lifted=p,closest=q,closest_parameter=param,closest_gap=gap*scale,torus_residual=abs(math.hypot(math.hypot(p[0],p[1])-6,p[2]-1)-1))
  records.append(item);print(json.dumps(item))
 report.append(dict(normalized=row['normalized'],extend=row['extend'],records=records))
Path('/tmp/viboceros-drop-accuracy-fillet-trims-analysis.json').write_text(json.dumps(report,indent=2)+'\n')
