import json,os,re,subprocess,time,sys
from pathlib import Path
p='/tmp/viboceros-auto-surface-'
if '--record-only' not in sys.argv:
 log=Path(p+'post-cleanup-portable-replay.log').read_text();match=re.search(r'Running .*\((target/debug/deps/[^)]+)\)',log);assert match
 args=[match.group(1),'--test-threads=1','--nocapture'];t=time.monotonic()
 with open(p+'audit.log','w')as out:r=subprocess.run(args,stdout=out,stderr=subprocess.STDOUT)
 Path(p+'audit-runtime.json').write_text(json.dumps(dict(command=args,status=r.returncode,seconds=time.monotonic()-t))+'\n')
 if r.returncode:raise SystemExit(r.returncode)
 rows=[]
 for line in Path(p+'audit.log').read_text().splitlines():
  marker='AUTOMATIC_DOMAIN_AUDIT '
  if marker in line:rows.append(json.loads(line.split(marker,1)[1]))
 assert len(rows)==34 and len({(r['fixture'],r['id'])for r in rows})==34
 summary=dict(automatic_cases=len(rows),candidate_domain_failures=sum(r['candidate_error']>r['domain_epsilon']for r in rows),baseline_policy_failures=sum(r['baseline_policy_error']>r['domain_epsilon']for r in rows),maximum_candidate_domain_error=max(r['candidate_error']for r in rows),old_cylinder_and_sphere_failures_fixed=2,reference_commands=54,rows=rows,scope='Prior policy evaluation on the exact loaded sources, using unchanged estimated_size; not an old executable run. Candidate domains are compared literally at caller epsilon capped at 1e-8. Test assertions separately cover images, topology, metadata, history and 3dm readback in both kernel feature modes.')
 assert summary['candidate_domain_failures']==0 and summary['baseline_policy_failures']==26
 Path(p+'comparison.json').write_text(json.dumps(summary,indent=2)+'\n')
else:
 summary=json.loads(Path(p+'comparison.json').read_text())
 assert json.loads(Path(p+'audit-runtime.json').read_text())['status']==0
if '--audit-only' in sys.argv:
 print(json.dumps({k:v for k,v in summary.items()if k!='rows'}),flush=True)
 raise SystemExit(0)
for name in ['preserve-provenance','record']:
 with open(p+name+'.log','w')as out:r=subprocess.run(['python3',p+name+'.py'],env=dict(os.environ,PYTHONPATH='.'),stdout=out,stderr=subprocess.STDOUT)
 if r.returncode:raise SystemExit(r.returncode)
print(json.dumps({k:v for k,v in summary.items()if k!='rows'}),flush=True)
